# Lab Week 14
## 实验内容：Peterson 算法
把 Lecture08 示例 alg.8-1~8-3 拓展到多个读线程和多个写线程,应用 Peterson 算法原理设计实现共享内存互斥。
## 实验原理：Peterson 算法简介
+ N个线程的Peterson算法:
    + The process Pi reaching level N-1 ( level(i)==N-1 ) will exit the for loop and enter his critical section.
    + Any process P i would upgrade its level lev to lev+1 (i.e., exit the while loop) either:
        + Some other process P j upgrades its level to the level of Pi(followed by level(j)==lev and waiting[lev]==j ) or:
        + The level of any other process is less than lev.
```
// Shared data:
int level[N];/* current level number of processes 0..N-1 */
int waiting[N-1]; /* the waiting process of each level.levels numbered 0..N-2 */
memset(level,(-1),sizeof(level));
memset(waiting,(-1),sizeof(waiting));

// code for process Pi
for (lev = 0; lev < N-1; ++lev) {
    level[i] = lev;
    waiting[lev] = i;
    while (waiting[lev] == i && (there exists k ≠ i, such that level[k] >= lev))
        sleep(1); /* busy waiting */
}
critical section of process i
level[i] = -1;/* allow other process of level n-2 to exit the while loop and enter his critical section */
remainder section of process i
```
## 相关调用
* 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
    * tidp:指向线程标识符的指针;
    * attr:设置线程属性;
    * start_rtn:线程运行函数的起始地址;
    * arg:运行函数的参数;
    * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
* 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
    * thread:被等待的线程ID;
    * retval:存储线程结束状态;
    * 返回值：若成功返回0，若失败返回-1。
* 退出线程：void  pthread_exit（void  * retval）;
    * retval:把一个空指针类型的值传给pthread_join的第二个参数;
    * 返回值：返回一个空指针类型的值。 
## 程序分析
+ 对于示例程序的修改主要有以下三点：
    + 将通过结构体中written成员控制读写子进程访问共享内存不冲突改为通过Peterson算法控制2N个读或写线程(读写线程各N个)访问共享内存不冲突，结构体中written成员仅表示共享内存中是否存在未读的消息，如果有就仅允许一个读线程读消息，否则就仅允许一个写线程写消息。
    + 示例程序中父进程fork一个读子进程和一个写子进程，此处改为main函数中生成N各读线程和N个写线程，线程的id(0～2N-1)在create时作为函数参数传入。
    + 添加了以下全局变量：
        ```
        int level[THREAD_MAX];/* current level number of processes 0..N-1 */
        int waiting[THREAD_MAX-1]; /* the waiting process of each level.levels numbered 0..N-2 */
        int N;//the number of read_threads and write_threads
        key_t key; /* of type int */
        ```
代码具体实现如下：
```
#define TEXT_SIZE 4*1024  /* = PAGE_SIZE, size of each message */
#define TEXT_NUM 1      /* maximal number of mesages */
    /* total size can not exceed current shmmax,
       or an 'invalid argument' error occurs when shmget */

/* a demo structure, modified as needed */
struct shared_struct {
    int written; /* flag = 0: buffer writable; others: readable */
    char mtext[TEXT_SIZE]; /* buffer for message reading and writing */
};

#define PERM S_IRUSR|S_IWUSR|IPC_CREAT

#define ERR_EXIT(m) \
    do { \
        perror(m); \
        exit(EXIT_FAILURE); \
    } while(0)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <pthread.h>

#define THREAD_MAX 500

int level[THREAD_MAX];/* current level number of processes 0..N-1 */
int waiting[THREAD_MAX-1]; /* the waiting process of each level.levels numbered 0..N-2 */
int N;//the number of read_threads and write_threads
key_t key; /* of type int */

void pthread_read(void* arg){
    void *shmptr = NULL;
    struct shared_struct *shared;
    int shmid;
    int* ID=(int*)arg;
    int id=*ID;
    printf("%*sreader-%d: IPC key = %x\n", 30, " ",id/2+1, key);
    
    shmid = shmget((key_t)key, TEXT_NUM*sizeof(struct shared_struct), 0666|PERM);
    if (shmid == -1) {
        ERR_EXIT("shread: shmget()");
    }

    shmptr = shmat(shmid, 0, 0);
    if(shmptr == (void *)-1) {
        ERR_EXIT("shread: shmat()");
    }
    printf("%*sreader-%d: shmid = %d\n", 30, " ",id/2+1, shmid);    
    printf("%*sreader-%d: shared memory attached at %p\n", 30, " ",id/2+1, shmptr);
    printf("%*sreader-%d process ready ...\n", 30, " ",id/2+1);
    
    shared = (struct shared_struct *)shmptr;
    
    while (1) {
        for (int lev = 0; lev < N*2-1; ++lev) {//Peterson算法code for process Pi
            level[id] = lev;
            waiting[lev] = id;
            int judge=1;
            while (waiting[lev] == id){
                int i;
                for(i=0;i<N*2;i++){//check if there exists k ≠ i, such that level[k] >= lev
                    if(level[i]>=lev&&i!=id){
                        judge=0;
                        break;
                    }
                }
                if(judge)break;
                judge=1;
                sleep(1); /* busy waiting */
            }      
        }
        if(shared->written == 1){//如果读到消息就输出
            printf("%*sreader-%d reads a writer wrote: %s\n", 30, " ",id/2+1, shared->mtext);
            shared->written = 0;
            if (strncmp(shared->mtext, "end", 3) == 0) {//读到end线程就退出
                level[id] = -1;/* allow other process of level n-2 to exit the while loop and enter his critical section */
                break;
            }    
        }
        level[id] = -1;/* allow other process of level n-2 to exit the while loop and enter his critical section */        
    } 
     
   if (shmdt(shmptr) == -1) {
        ERR_EXIT("shmread: shmdt()");
   }
 
    sleep(1);
    pthread_exit(NULL);
}
void pthread_write(void* arg){
    void *shmptr = NULL;
    struct shared_struct *shared = NULL;
    int shmid;

    char buffer[BUFSIZ + 1]; /* 8192bytes, saved from stdin */
    
    int* ID=(int*)arg;
    int id=*ID;

    printf("writer-%d: IPC key = %x\n",id/2+1, key);

    shmid = shmget((key_t)key, TEXT_NUM*sizeof(struct shared_struct), 0666|PERM);
    if (shmid == -1) {
        ERR_EXIT("shmwite: shmget()");
    }

    shmptr = shmat(shmid, 0, 0);
    if(shmptr == (void *)-1) {
        ERR_EXIT("shmwrite: shmat()");
    }
    printf("writer-%d: shmid = %d\n",id/2+1, shmid);
    printf("writer-%d: shared memory attached at %p\n",id/2+1, shmptr);
    printf("writer-%d precess ready ...\n",id/2+1);
    
    shared = (struct shared_struct *)shmptr;
    
    while (1) {
        for (int lev = 0; lev < N*2-1; ++lev) {//Peterson算法code for process Pi
            level[id] = lev;
            waiting[lev] = id;
            int judge=1;
            while (waiting[lev] == id){
                int i;
                for(i=0;i<N*2;i++){//check if there exists k ≠ i, such that level[k] >= lev
                    if(level[i]>=lev&&i!=id){
                        judge=0;
                        break;
                    }
                }
                if(judge)break;
                judge=1;
                sleep(1); /* busy waiting */
            }      
        }
        if(shared->written == 0) {
            printf("writer-%d,Enter some text: ",id/2+1);
            fgets(buffer, BUFSIZ, stdin);
            strncpy(shared->mtext, buffer, TEXT_SIZE);
            printf("writer-%d writes into shared buffer: %s\n",id/2+1,shared->mtext);
            shared->written = 1;  /* message prepared */
    
            if(strncmp(buffer, "end", 3) == 0) {
                level[id] = -1;/* allow other process of level n-2 to exit the while loop and enter his critical section */        
                break;
            }
        }
        level[id] = -1;/* allow other process of level n-2 to exit the while loop and enter his critical section */                
    }
       /* detach the shared memory */
    if(shmdt(shmptr) == -1) {
        ERR_EXIT("shmwrite: shmdt()");
    }

    sleep(1);
    pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
    memset(level,(-1),sizeof(level));
    memset(waiting,(-1),sizeof(waiting));
    struct stat fileattr;
    int shmid; /* shared memory ID */
    void *shmptr;
    struct shared_struct *shared; /* structured shm */
    char pathname[80], cmd_str[80];
    int shmsize, ret;

    shmsize = TEXT_NUM*sizeof(struct shared_struct);
    printf("max record number = %d, shm size = %d\n", TEXT_NUM, shmsize);

    if(argc <2) {
        printf("Usage: ./a.out pathname\n");
        return EXIT_FAILURE;
    }
    strcpy(pathname, argv[1]);

    if(stat(pathname, &fileattr) == -1) {
        ret = creat(pathname, O_RDWR);
        if (ret == -1) {
            ERR_EXIT("creat()");
        }
        printf("shared file object created\n");
    }
 
    key = ftok(pathname, 0x27); /* 0x27 a project ID 0x0001 - 0xffff, 8 least bits used */
    if(key == -1) {
        ERR_EXIT("shmcon: ftok()");
    }
    printf("key generated: IPC key = %x\n", key); /* can set any nonzero key without ftok()*/

    shmid = shmget((key_t)key, shmsize, 0666|PERM);
    if(shmid == -1) {
        ERR_EXIT("shmcon: shmget()");
    }
    printf("shmcon: shmid = %d\n", shmid);

    shmptr = shmat(shmid, 0, 0); /* returns the virtual base address mapping to the shared memory, *shmaddr=0 decided by kernel */

    if(shmptr == (void *)-1) {
        ERR_EXIT("shmcon: shmat()");
    }
    printf("shmcon: shared Memory attached at %p\n", shmptr);
    
    shared = (struct shared_struct *)shmptr;
    shared->written = 0;

    sprintf(cmd_str, "ipcs -m | grep '%d'\n", shmid); 
    printf("\n------ Shared Memory Segments ------\n");
    system(cmd_str);
	
    if(shmdt(shmptr) == -1) {
        ERR_EXIT("shmcon: shmdt()");
    }

    printf("\n------ Shared Memory Segments ------\n");
    system(cmd_str);

    printf("I will create N threads to read and N thread to write,0<=N<=500,N=");
    scanf("%d",&N);

    pthread_t threads[2*N];
    int id[2*N];
    int i;
    for(i=0;i<N*2;i++){
        id[i]=i;
    }
    for(i=0;i<N*2;i++){//创建N个写线程和N个读线程
        if(i%2==0){
            pthread_create(&(threads[i]),NULL,&pthread_write,&(id[i]));
        }
        else{
            pthread_create(&(threads[i]),NULL,&pthread_read,&(id[i]));
        }
    }
    for(i=0; i<N*2;i++) {//等待所有读写线程结束
		pthread_join(threads[i], NULL);
	}

    sleep(1);
    printf("All threads to read or write exits.\n");
    if (shmctl(shmid, IPC_RMID, 0) == -1) {
        ERR_EXIT("shmcon: shmctl(IPC_RMID)");
    }
    else {
        printf("shmcon: shmid = %d removed \n", shmid);
        printf("\n------ Shared Memory Segments ------\n");
        system(cmd_str);
        printf("nothing found ...\n"); 
    }
    exit(EXIT_SUCCESS);
}
```
## 运行结果
**编译源代码**

![](0.png)

**读写进程各3个**

![](1.png)

**读写进程各5个**

![](2.1.png)

![](2.2.png)

**读写进程各10个**

![](3.1.png)

![](3.2.png)

![](3.3.png)