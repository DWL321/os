# Lab Week 13 线程池设计报告
## 实验原理
**线程池**由管理者线程、线程数组、任务队列组成，允许一个线程可以多次复用，且每次复用的线程内部的处理的任务可以不相同，将创建与销毁的开销省去而不必来一个请求开一个线程。

**管理者线程**负责创建并管理线程池，包括创建新线程、销毁线程池、添加任务。

**线程数组**实际上是在线程池初始化时开辟的一段存放一堆线程tid的空间，在逻辑上形成一个池，里面放置着提前创建的线程，这段空间中包含了正在工作的线程和等待工作的线程(空闲线程)。

**任务队列**的存在形式与线程数组相似，在线程池初始化时根据传入的任务队列长度开辟空间；当main函数添加新任务时，将任务放入任务队列并通知空闲线程来取。不同之处在于任务队列有明显的先后顺序，先进先出；而线程数组中的线程则是一个竞争关系去拿到互斥锁争取任务。
## 设计思路
实验中设计了两个结构体分别定义了任务和线程池，其中任务队列由循环队列构建
```
typedef struct Threadpool_task{
	void (*function)(void *);
	void *argument;
} threadpool_task;

typedef struct Threadpool {
	pthread_mutex_t lock;     //互斥锁
	pthread_cond_t notify;    //条件变量
	pthread_t *threads;       //线程数组的起始指针
	threadpool_task *queue;   //任务队列数组的起始指针
	int thread_count;         //线程数量
	int task_count;			  //任务队列中任务数量
	int task_head;			  //任务循环队列里的第一个任务
	int task_tail;			  //任务循环队列下次添加任务的位置
	int queue_size;           //任务队列长度
	int shutdown;             //线程池当前状态是否关闭
	int started;              //正在运行的线程数
} threadpool;
```
设计以下三个函数为线程池的对外接口，主线程通过在main函数调用这三个函数成为管理者线程
```
threadpool* threadpool_create(int thread_count, int queue_size);//创建线程池
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);//添加需要执行的任务
int threadpool_destroy(threadpool* pool);//销毁存在的线程池并释放线程池所申请的内存资源
```
以下为线程池内部辅助函数
```
static void *threadpool_run(void *thread_pool); //线程池每个线程所执行的函数
```
编写测试程序，首先按输入的参数创建线程池，然后依次添加n个分别计算从1维到n维的向量(第n维的向量为[1,2,3,...,n])乘以它自身的转置的任务到任务队列中，等待所有计算任务完成且结果输出后摧毁线程池。
## 重要函数
* Pthread API：
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
    * 退出线程：void  pthread_exit（void  * retval）;
        * retval:把一个空指针类型的值传给pthread_join的第二个参数;
        * 返回值：返回一个空指针类型的值。 
    * 以动态方式创建互斥锁: int pthread_mutex_init(pthread_mutex_t * &mutex,const pthread_mutexattr_t * &attr);
        * mutex:要创建的互斥锁；
        * attr:互斥锁属性
        * 成功返回0。
    * 互斥锁上锁：int pthread_mutex_lock(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0,锁住由mutex指定的互斥锁。如果mutex已经被锁住，调用这个函数的线程阻塞直到mutex可用为止，函数返回的时候参数mutex指定的互斥锁变成锁住状态， 同时该函数的调用线程成为该互斥锁的拥有者。
    * 互斥锁解锁:int pthread_mutex_unlock(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0。
    * 线程无条件挂起等待条件变量成立：int pthread_cond_wait(pthread_cond_t * &cond,pthread_mutex_t * &mutex)   
        * cond:条件变量；
        * mutex:互斥锁；
        * 成功返回0,在更新条件等待队列以前，mutex保持锁定状态，并在线程挂起进入等待前解锁,在条件满足从而离开pthread_cond_wait()之前，mutex将被重新加锁，以与进入pthread_cond_wait()前的加锁动作对应。   
    * 以动态方式创建条件变量：int pthread_cond_init(pthread_cond_t * &cond,pthread_condattr_t * &cond_attr);
        * cond:要创建的条件变量；
        * cond_attr:条件变量属性
        * 成功返回0。
    * 激活一个等待该条件的线程，存在多个等待线程时按入队顺序激活其中一个：int pthread_cond_signal(pthread_cond_t * &cond);
        * cond:条件变量；
        * 成功返回0。
    * 激活所有等待该条件的线程：int pthread_cond_broadcast(pthread_cond_t * &cond);
        * cond:条件变量；
        * 成功返回0。
    * 摧毁互斥锁：int pthread_mutex_destroy(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0。
    * 摧毁条件变量：int pthread_cond_destroy(pthread_cond_t * &cond);
        * cond:条件变量；
        * 成功返回0。
* 自定义线程池对外接口及内部函数：
    * 创建线程池：threadpool* threadpool_create(int thread_count, int queue_size);
        * thread_count:线程池中用来执行任务的线程数；
        * queue_size：任务队列最大长度；
        * 返回值：成功返回线程池结构体地址，失败返回0。
    * 添加需要执行的任务：int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);
        * pool:线程池指针
        * fun:要执行的任务函数
        * arg:任务函数的参数
        * 返回值：成功返回0，失败返回-1。
    * 销毁存在的线程池并释放线程池所申请的内存资源：int threadpool_destroy(threadpool* pool);
        * pool:线程池指针
        * 返回值：成功返回0，失败返回-1。
    * 线程池每个线程所执行的函数：static void *threadpool_run(void *thread_pool); 
        * pool:线程池指针
        * 返回值：成功返回0，失败返回-1。
## 具体实现
注：由于matrix只能提交一个文件所以`threadpool.h`和`test.c`合并提交了。
线程池的结构体定义及功能函数写在`threadpool.h`文件中
```
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h> 
#include <stdio.h>

typedef struct Threadpool_task{
	void (*function)(void *);
	void *argument;
} threadpool_task;

typedef struct Threadpool {
	pthread_mutex_t lock;     //互斥锁
	pthread_cond_t notify;    //条件变量
	pthread_t *threads;       //线程数组的起始指针
	threadpool_task *queue;   //任务队列数组的起始指针
	int thread_count;         //线程数量
	int task_count;			  //任务队列中任务数量
	int task_head;			  //任务循环队列里的第一个任务
	int task_tail;			  //任务循环队列下次添加任务的位置
	int queue_size;           //任务队列长度
	int shutdown;             //线程池当前状态是否关闭
	int started;              //正在运行的线程数
} threadpool;

static void *threadpool_run(void *thread_pool); //线程池每个线程所执行的函数
threadpool* threadpool_create(int thread_count, int queue_size);//创建线程池
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);//添加需要执行的任务
int threadpool_destroy(threadpool* pool);//销毁存在的线程池并释放线程池所申请的内存资源

static void *threadpool_run(void *thread_pool){
	printf("A thread in pool starts.\n");
	threadpool* pool = (threadpool*)thread_pool;
	while(!pool->shutdown){
		pthread_mutex_lock(&(pool->lock));//取得互斥锁
		while((!pool->shutdown)&&(pool->task_count==0)) {//若线程池没有关闭且任务队列为空则阻塞
            pthread_cond_wait(&(pool->notify),&(pool->lock));
        }

		if(pool->shutdown){//如果线程池关闭就退出
			break;
		}

		//取出任务队列里最先进入的任务
		threadpool_task task;
		task.function=pool->queue[pool->task_head].function;
		task.argument=pool->queue[pool->task_head].argument;
		pool->task_head=(pool->task_head+1)%pool->queue_size;
		pool->task_count--;

		pthread_mutex_unlock(&(pool->lock));//释放互斥锁

		(*(task.function))(task.argument);//执行任务
	}
	pool->started--;
	printf("A thread in pool exits.\n");
	pthread_mutex_unlock(&(pool->lock));
    pthread_exit(NULL);
}
threadpool* threadpool_create(int thread_count, int queue_size){
	if(thread_count <= 0|| queue_size <= 0) {
        return 0;
    }
	threadpool* pool=(threadpool*)malloc(sizeof(threadpool));
	if(pool==0){
		return 0;
	}
	pthread_mutex_init(&(pool->lock), NULL);//初始化互斥锁
	pthread_cond_init(&(pool->notify), NULL);//初始化条件变量
	pool->threads = (pthread_t*)malloc(sizeof(pthread_t)*thread_count);//申请线程数组所需的内存
	pool->queue = (threadpool_task*)malloc(sizeof(threadpool_task)*queue_size);//申请任务队列所需的内存
	if(pool->threads==0||pool->queue==0){
		return 0;
	}
	//初始化其他参数
	pool->thread_count=0;
	pool->task_head=0;
	pool->task_tail=0;
	pool->task_count=0;
    pool->queue_size=queue_size;
    pool->shutdown=0;
	pool->started = 0;
	int i;
	for(i=0;i<thread_count;i++) {//创建thread_count个线程并开始运行
        if(pthread_create(&(pool->threads[i]),NULL,threadpool_run,(void*)pool)!=0){
            threadpool_destroy(pool);
            return 0;
        }
        pool->thread_count++;
        pool->started++;
    }

    return pool;
}
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg){
	if(pthread_mutex_lock(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool->task_count==pool->queue_size||pool->shutdown==1){//判断任务队列满没满或线程池是否关闭
		pthread_mutex_unlock(&pool->lock);
		return -1;
	}
	//向任务循环队列里添加一个新任务
	pool->queue[pool->task_tail].function=fun;
	pool->queue[pool->task_tail].argument=arg;
	pool->task_tail=(pool->task_tail+1)%pool->queue_size;
	pool->task_count++;
	if(pthread_mutex_unlock(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	pthread_cond_signal(&(pool->notify));//发出有任务添加进来的信号，若存在因为任务队列空阻塞的线程就唤醒一个
	return 0;
}
int threadpool_destroy(threadpool* pool){
	if(pthread_mutex_lock(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool==0){//判断这个线程池是否已经摧毁过了
		return 0;
	}
	if(pool->shutdown){//判断线程池是否关闭
		return -1;
	}
	pool->shutdown=1;//关闭线程池
	pthread_cond_broadcast(&(pool->notify));//唤醒线程池里所有因条件变量阻塞的线程
	if(pthread_mutex_unlock(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	int i;
	for(i=0; i<pool->thread_count;i++) {//等待所有线程结束
		pthread_join(pool->threads[i], NULL);
	}

	while(pool->started)sleep(5);
	free(pool->threads);//释放线程数组
	free(pool->queue);//释放任务队列
	pthread_mutex_lock(&(pool->lock));//取得互斥锁所有权
	pthread_mutex_destroy(&(pool->lock));//摧毁互斥锁
	pthread_cond_destroy(&(pool->notify));//摧毁条件变量
    free(pool);//释放线程池
	pool=0;
	return 0;
}
```
测试程序及其对线程池接口的调用写在`test.c`文件中
```
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include "threadpool.h"

int done = 0;
pthread_mutex_t lock;

void run(void *arg){
    int* num=(int*)arg;
    int n=*num;
    int i;
    int result=0;
    for(i=1;i<=n;i++){
        result+=i*i;
    }
    pthread_mutex_lock(&lock);
    done++;
    printf("n=%d,result=%d,%d tasks have done\n",n,result,done);
    pthread_mutex_unlock(&lock);
}

int main()
{
    printf("请输入线程数量：");
    int thread_count;
    scanf("%d",&thread_count);
    printf("请输入任务队列里最多任务数：");
    int queue_size;
    scanf("%d",&queue_size);
    printf("请输入向量的最大维数：");
    int n;
    scanf("%d",&n);
    printf("使用线程数为%d任务队列最大长度为%d的线程池计算从1维到%d维的向量乘以它的转置\n",thread_count,queue_size,n);
    printf("注：第n维的向量为[1,2,3,...,n]\n");

    pthread_mutex_init(&lock, NULL);//初始化互斥锁
    threadpool* pool=threadpool_create(thread_count,queue_size);//创建线程池
    if(pool==0){
        printf("线程池创建失败\n");
        return 0;
    }
    int task[n+1];//防止线程获得向量阶数的时候出现冲突
    int i;
    for(i=1;i<=n;i++){
        task[i]=i;
    }
    i=1;
    while(i<=n){//将所有任务添加到任务队列里
        while(pool->shutdown==0&&threadpool_add(pool,&run,&task[i])!=0){//如果添加失败就等1秒，直到成功添加第i个任务
            sleep(1);
        }
        i++;
    }
    while(done<n){//等待所有任务完成
        sleep(5);
    }
    sleep(1);
    printf("All tasks have done!\n");
    if(threadpool_destroy(pool)!=0){//销毁线程池
        printf("线程池摧毁失败\n");
    }
    return 0;
}
```
## 测试用例
编译运行

![](1.png)

**样例一**：使用线程数为3任务队列最大长度为5的线程池计算从1维到10维的向量乘以它的转置

![](2.png)

**样例二**：使用线程数为5任务队列最大长度为8的线程池计算从1维到15维的向量乘以它的转置

![](3.png)

**样例三**：使用线程数为6任务队列最大长度为9的线程池计算从1维到20维的向量乘以它的转置

![](4.png)