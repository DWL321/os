#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/shm.h>

#include "alg.8-0-shmdata.h"

int main(int argc, char *argv[])
{
    void *shmptr = NULL;
    struct shared_struct *shared;
    int shmid;
    key_t key;
 
    sscanf(argv[1], "%x", &key);
    printf("%*sshmread: IPC key = %x\n", 30, " ", key);
    
    shmid = shmget((key_t)key, TEXT_NUM*sizeof(struct shared_struct), 0666|PERM);
    if (shmid == -1) {
        ERR_EXIT("shread: shmget()");
    }

    shmptr = shmat(shmid, 0, 0);
    if(shmptr == (void *)-1) {
        ERR_EXIT("shread: shmat()");
    }
    printf("%*sshmread: shmid = %d\n", 30, " ", shmid);    
    printf("%*sshmread: shared memory attached at %p\n", 30, " ", shmptr);
    printf("%*sshmread process ready ...\n", 30, " ");
    
    shared = (struct shared_struct *)shmptr;
    
    while (1) {
        while (shared->head == shared->tail||shared->written==0) {
            shared->written=0;
            sleep(1); /* 队列为空, waiting ... */
        }
        if (strncmp(shared->students[shared->head].id, "-1", 2) == 0) {
            break;
        }
        printf("%*s新输入的学生id: %s\n", 30, " ", shared->students[shared->head].id);
        printf("%*s新输入的学生姓名: %s\n", 30, " ", shared->students[shared->head].name);
        shared->head = (shared->head+1)%MAX_STUDENT_NUM;
    } 
     
   if (shmdt(shmptr) == -1) {
        ERR_EXIT("shmread: shmdt()");
   }
 
    sleep(1); 
    exit(EXIT_SUCCESS);
}
