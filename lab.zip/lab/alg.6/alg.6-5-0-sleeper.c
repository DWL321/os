/* gcc -o alg.6-5-0-sleeper.o alg.6-5-0-sleeper.c */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char* argv[])
{
    int secnd = 5;//设置睡眠时间为5秒

    if (argc > 1) {//如果有参数
        secnd = atoi(argv[1]);//把秒数改为参数字符串第二个字符对应的数字
        if ( secnd <= 0 || secnd > 10)//如果秒数不合法或过长，改为5秒
            secnd = 5;
    }

    //输出此进程的pid，它的父进程的pid
    printf("\nsleeper pid = %d, ppid = %d\nsleeper is taking a nap for %d seconds\n", getpid(), getppid(), secnd); /* ppid - its parent pro id */

    sleep(secnd);//此进程挂起secnd秒
    printf("\nsleeper wakes up and returns\n");//此进程醒来

    return 0;
}