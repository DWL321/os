#include <stdio.h>
#include <stdlib.h>
#define UINT32_SHR_OR(a,n)      ((a)|((a)>>(n)))//右移n位  

#define UINT32_MASK(a)          (UINT32_SHR_OR(UINT32_SHR_OR(UINT32_SHR_OR(UINT32_SHR_OR(UINT32_SHR_OR(a,1),2),4),8),16))    
//大于a的一个最小的2^k
#define UINT32_REMAINDER(a)     ((a)&(UINT32_MASK(a)>>1))
#define UINT32_ROUND_DOWN(a)    (UINT32_REMAINDER(a)?((a)-UINT32_REMAINDER(a)):(a))//小于a的最大的2^k

int main()
{
    int a;
    scanf("%d",&a);
    while (a>0)
    {
        printf("%d\n%d\n%d\n%d\n%d\n\n",UINT32_SHR_OR(a,3),UINT32_MASK(a),UINT32_REMAINDER(a),UINT32_ROUND_DOWN(a),UINT32_ROUND_DOWN(a));
        scanf("%d",&a);
    }
    return 0;
}