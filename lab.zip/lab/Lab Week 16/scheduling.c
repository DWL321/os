#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <time.h>
#define NUM_THREADS 20

typedef struct CONTROLRE
{
    int id;              //线程编号
    pthread_t thread;   //线程tid
    int arrive;          //到达时间
    int wct;             //完成时间
    int burst;           //占用CPU时间
    int priority;        //优先级
    int state;           //调度状态：0-运行、1-就绪、2-终止
    sem_t control;       //调度信号量
    int wait;            //等待时间
}controler;

void *run(void *arg);//线程执行的函数
double average_wait_time(controler* con);//计算任务平均等待时间

int main(int argc, char *argv[]){
    controler con[NUM_THREADS];
    controler standand[NUM_THREADS];

    srand((int)time(0));
    //管理链队列初始化
    int i;
    for(i=0;i<NUM_THREADS;i++){
        con[i].id=i+1;
        con[i].arrive=rand()%(100*NUM_THREADS);
        con[i].wct=con[i].arrive+100000;
        con[i].burst=rand()%200;
        con[i].priority=rand()%99+1;
        con[i].state=1;
        standand[i]=con[i];
        sem_init(&(con[i].control), 0, 0);//初始化调度信号量
        sem_init(&(standand[i].control), 0, 0);//初始化调度信号量
    }

    //FCFS
    printf("FCFS\n");
    for(i=0;i<NUM_THREADS;i++){//创建多线程
        pthread_create(&(con[i].thread),NULL,&run,(void*)&con[i]);
    }
    sleep(1);
    
    for(i=0;i<NUM_THREADS-1;i++){//将所有线程按到达时间排序
        int j;
        for(j=1;j<NUM_THREADS-i;j++){
            if(con[j-1].arrive>con[j].arrive){
                controler t=con[j-1];
                con[j-1]=con[j];
                con[j]=t;
            }
        }
    }
    int now=0;
    int select=0;
    while(select<NUM_THREADS){//若还有线程未检查就继续调度
        int arrive=con[select].arrive;
        if(!(con[select].state==1&&con[select].wct>=now+con[select].burst)){//检测当前线程是否是调度状态为就绪且在截至时间前能完成的线程
            if(con[select].state==1){//终止在截至时间之前不能完成的已到达线程
                con[select].state=2;
                if(con[select].arrive<now)con[select].wait=now-con[select].arrive;
                else con[select].wait=0;
            }
            select++;
            continue;
        }

        //更新当前时间并计算此线程的等待时间
        if(now<=arrive){
            now=arrive;
            con[select].wait=0;
        }
        else{
            con[select].wait=now-arrive;
        }
        
        printf("now is %d\n",now);
        sem_post(&(con[select].control));//启动选中的线程
        usleep(100);
        sem_wait(&(con[select].control));//等待此线程运行结束
        
        now+=con[select].burst;//更新当前时间
        select++;
    }

    for(i=0;i<NUM_THREADS;i++){//唤醒所有未运行就被终止的线程
        sem_post(&(con[i].control));
    }
    for(i=0;i<NUM_THREADS;i++){//等待线程终止
        pthread_join(con[i].thread,NULL);
    }
    printf("FCFS average wait time:%lf\n",average_wait_time(con));
    printf("============================================================================\n\n");
    
    //SJF
    printf("SJF\n");
    for(i=0;i<NUM_THREADS;i++){//复原管理链队列
        con[i].id=standand[i].id;
        con[i].arrive=standand[i].arrive;
        con[i].wct=standand[i].wct;
        con[i].burst=standand[i].burst;
        con[i].priority=standand[i].priority;
        con[i].state=1;
        sem_destroy(&(con[i].control));
        sem_init(&(con[i].control), 0, 0);//初始化调度信号量
    }
    for(i=0;i<NUM_THREADS;i++){//创建多线程
        pthread_create(&(con[i].thread),NULL,&run,(void*)&con[i]);
    }
    sleep(1);

    for(i=0;i<NUM_THREADS-1;i++){//将所有线程按到达时间排序
        int j;
        for(j=1;j<NUM_THREADS-i;j++){
            if(con[j-1].arrive>con[j].arrive){
                controler t=con[j-1];
                con[j-1]=con[j];
                con[j]=t;
            }
        }
    }

    now=0;
    int first=0;//当前最早到达的未运行且在截至时间前能完成的线程
    while(first<NUM_THREADS){//若还有调度状态为就绪且在截至时间前能完成的线程就继续调度
        int arrive=con[first].arrive;//本次调度线程的到达时间
        int select=first;//本次要调度的线程
        if(now<con[first].arrive)now=con[first].arrive;//更新当前时间保证有线程就绪

        for(i=first;i<NUM_THREADS;i++){//寻找调度状态为就绪且在截至时间前能完成的已到达线程中占用CPU时间最短的线程
            if(con[i].state==1&&con[i].wct<now+con[i].burst&&con[i].arrive<=now){//终止在截至时间之前不能完成的已到达线程
                con[i].state=2;
                if(con[i].arrive<now)con[i].wait=now-con[i].arrive;
                else con[i].wait=0;
            }
            else if(con[i].state==1&&con[i].burst<con[select].burst&&con[i].arrive<=now&&con[i].wct>=now+con[i].burst){
                arrive=con[i].arrive;
                select=i;
            }
        }

        //计算此线程的等待时间
        if(now==arrive){
            con[select].wait=0;
        }
        else{
            con[select].wait=now-arrive;
        }
        
        printf("now is %d\n",now);
        sem_post(&(con[select].control));//启动选中的线程
        usleep(100);
        sem_wait(&(con[select].control));//等待此线程运行结束
        
        now+=con[select].burst;//更新当前时间

        for(;first<NUM_THREADS;first++){//寻找当前最早到达的就绪线程
            if(con[first].state==1)
                break;
        }
    }

    for(i=0;i<NUM_THREADS;i++){//唤醒所有未运行就被终止的线程
        sem_post(&(con[i].control));
    }
    for(i=0;i<NUM_THREADS;i++){//等待线程终止
        pthread_join(con[i].thread,NULL);
    }
    printf("SJF average wait time:%lf\n\n",average_wait_time(con));
    printf("============================================================================\n\n");

    //Priority
    printf("Priority\n");
    for(i=0;i<NUM_THREADS;i++){//复原管理链队列
        con[i].id=standand[i].id;
        con[i].arrive=standand[i].arrive;
        con[i].wct=standand[i].wct;
        con[i].burst=standand[i].burst;
        con[i].priority=standand[i].priority;
        con[i].state=1;
        sem_destroy(&(con[i].control));
        sem_init(&(con[i].control), 0, 0);//初始化调度信号量
    }
    for(i=0;i<NUM_THREADS;i++){//创建多线程
        pthread_create(&(con[i].thread),NULL,&run,(void*)&con[i]);
    }
    sleep(1);

    for(i=0;i<NUM_THREADS-1;i++){//将所有线程按到达时间排序
        int j;
        for(j=1;j<NUM_THREADS-i;j++){
            if(con[j-1].arrive>con[j].arrive){
                controler t=con[j-1];
                con[j-1]=con[j];
                con[j]=t;
            }
        }
    }

    now=0;
    first=0;//当前最早到达的未运行且在截至时间前能完成的线程
    while(first<NUM_THREADS){//若还有调度状态为就绪且在截至时间前能完成的线程就继续调度
        int arrive=con[first].arrive;//本次调度线程的到达时间
        int select=first;//本次要调度的线程
        if(now<con[first].arrive)now=con[first].arrive;//更新当前时间保证有线程就绪

        for(i=first;i<NUM_THREADS;i++){//寻找调度状态为就绪且在截至时间前能完成的已到达线程中优先级最高的线程
            if(con[i].state==1&&con[i].wct<now+con[i].burst&&con[i].arrive<=now){//终止在截至时间之前不能完成的已到达线程
                con[i].state=2;
                if(con[i].arrive<now)con[i].wait=now-con[i].arrive;
                else con[i].wait=0;
            }
            else if(con[i].state==1&&con[i].priority>con[select].priority&&con[i].arrive<=now&&con[i].wct>=now+con[i].burst){
                arrive=con[i].arrive;
                select=i;
            }
        }

        //计算此线程的等待时间
        if(now==arrive){
            con[select].wait=0;
        }
        else{
            con[select].wait=now-arrive;
        }
        
        printf("now is %d\n",now);
        sem_post(&(con[select].control));//启动选中的线程
        usleep(100);
        sem_wait(&(con[select].control));//等待此线程运行结束
        
        now+=con[select].burst;//更新当前时间

        for(;first<NUM_THREADS;first++){//寻找当前最早到达的就绪线程
            if(con[first].state==1)
                break;
        }
    }

    for(i=0;i<NUM_THREADS;i++){//唤醒所有未运行就被终止的线程
        sem_post(&(con[i].control));
    }

    for(i=0;i<NUM_THREADS;i++){//等待线程终止
        pthread_join(con[i].thread,NULL);
    }
    printf("Priority average wait time:%lf\n\n",average_wait_time(con));
    
    //摧毁互斥信号量
    for(i=0;i<NUM_THREADS;i++){
        sem_destroy(&(con[i].control));
        sem_destroy(&(standand[i].control));
    }
    return 0;
}
void *run(void *arg){
    controler* con=(controler*)arg;
    sem_wait(&(con->control));

    if(con->state==1){//因为截止时间之前无法完成而被终止的线程直接退出
        con->state=0;//线程开始运行
        printf("-----------------------------------------------------\n");
        printf("thread-%d starts!\n",con->id);
        printf("tid of thread-%d :%lx\n",con->id,pthread_self());
        printf("arrive time of thread-%d :%d\n",con->id,con->arrive);
        printf("wct of thread-%d :%d\n",con->id,con->wct);
        printf("cpu burst time of thread-%d :%d\n",con->id,con->burst);
        printf("priority of thread-%d :%d\n",con->id,con->priority);
        printf("wait time of thread-%d :%d\n",con->id,con->wait);
        printf("thread-%d exits!\n",con->id);
        printf("-----------------------------------------------------\n");
        con->state=2;//线程终止
    }
    
    sem_post(&(con->control));
}
double average_wait_time(controler* con){
    int sum=0;
    int i;
    for(i=0;i<NUM_THREADS;i++)
        sum+=con[i].wait;
    return sum*1.0/NUM_THREADS;
}