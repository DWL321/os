#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <fcntl.h>

#define PERM S_IRUSR|S_IWUSR|IPC_CREAT

#define ERR_EXIT(m) \
    do { \
        perror(m); \
        exit(EXIT_FAILURE); \
    } while(0)

int main(int argc, char *argv[])
{
    struct stat fileattr;
    key_t key; /* of type int */
    int shmid; /* shared memory ID */
    char pathname[80];
    long long shmsize=getpagesize();//每次申请一个增加一个内存页空间大小的共享内存
    int ret;
    strcpy(pathname, argv[1]);
    if(stat(pathname, &fileattr) == -1) {
        ret = creat(pathname, O_RDWR);
        if (ret == -1) {
            ERR_EXIT("creat()");
        }
        printf("shared file object created\n");
    }
 
    key = ftok(pathname, 0x27); /* 0x27 a project ID 0x0001 - 0xffff, 8 least bits used */
    if(key == -1) {
        ERR_EXIT("shmcon: ftok()");
    }
    while (1)
    {
        shmid = shmget((key_t)key, shmsize, 0666|PERM);
        if(shmid == -1) {
            printf("共享内存上限为%lld字节\n",shmsize-=getpagesize());//本次申请失败说明上一次申请的共享内存大小就是上限
            ERR_EXIT("shmcon: shmget()");
        }
        if (shmctl(shmid, IPC_RMID, 0) == -1) {//断开共享内存连接
            ERR_EXIT("shmcon: shmctl(IPC_RMID)");
        }  
        shmsize+=getpagesize(); 
    }
    exit(EXIT_SUCCESS);
}
