# Project01实验报告
## 练习内容
### 练习1：理解通过make生成执行文件的过程
#### 1.操作系统镜像文件ucore.img是如何一步一步生成的？(需要比较详细地解释Makefile中每一条相关命令和命令参数的含义，以及说明命令导致的结果)
执行`$ make "V="`查看make执行了哪些命令

![](assets/1.1.png)

![](assets/1.2.png)

**生成ucore.img**

阅读makefile代码，可以发现生成ucore.img的代码如下：
```
UCOREIMG	:= $(call totarget,ucore.img)

$(UCOREIMG): $(kernel) $(bootblock)
	$(V)dd if=/dev/zero of=$@ count=10000
	$(V)dd if=$(bootblock) of=$@ conv=notrunc
	$(V)dd if=$(kernel) of=$@ seek=1 conv=notrunc

$(call create_target,ucore.img)
```
对应执行的命令为：

![](assets/1.5.png)

首先创建大小为10000个块的ucore.img，初始化为0，每个块为512字节(sign.c定义的)，把bootblock中的内容写到第一个块，从第二个块开始写kernel中的内容。所以生成ucore.img前要生成bootblock和kernel。

**生成kernel**

阅读makefile代码，可以发现生成kernel的代码如下：
```
kernel = $(call totarget,kernel)

$(kernel): tools/kernel.ld

$(kernel): $(KOBJS)
	@echo + ld $@
	$(V)$(LD) $(LDFLAGS) -T tools/kernel.ld -o $@ $(KOBJS)
	@$(OBJDUMP) -S $@ > $(call asmfile,kernel)
	@$(OBJDUMP) -t $@ | $(SED) '1,/SYMBOL TABLE/d; s/ .* / /; /^$$/d' > $(call symfile,kernel)

$(call create_target,kernel)
```
对应执行的命令为：

![](assets/1.3.png)

参数解释：

* `-m elf_i386`:编译为32位程序；

* `-nostdlib`:不连接系统标准启动文件和标准库文件，只把指定的文件传递给连接器；

* `-T tools/kernel.ld`:使用指定的链接脚本tools/kernel.ld；

* `-o`:指定输出文件的名称。

可以看到，要生成kernel，需要用GCC编译器将kern目录下所有的.c文件和.S文件全部编译生成.o文件，再把它们连接为一个可执行文件或库文件kernel。需要连接的.o文件如下：
```
obj/kern/init/init.o 
obj/kern/libs/stdio.o 
obj/kern/libs/readline.o 
obj/kern/debug/panic.o 
obj/kern/debug/kdebug.o 
obj/kern/debug/kmonitor.o 
obj/kern/driver/clock.o 
obj/kern/driver/console.o 
obj/kern/driver/picirq.o 
obj/kern/driver/intr.o 
obj/kern/trap/trap.o 
obj/kern/trap/vectors.o 
obj/kern/trap/trapentry.o 
obj/kern/mm/pmm.o  
obj/libs/string.o
obj/libs/printfmt.o 
```
**生成bootblock**

阅读makefile代码，可以发现生成bootblock的代码如下：
```
bootfiles = $(call listf_cc,boot)
$(foreach f,$(bootfiles),$(call cc_compile,$(f),$(CC),$(CFLAGS) -Os -nostdinc))

bootblock = $(call totarget,bootblock)

$(bootblock): $(call toobj,$(bootfiles)) | $(call totarget,sign)
	@echo + ld $@
	$(V)$(LD) $(LDFLAGS) -N -e start -Ttext 0x7C00 $^ -o $(call toobj,bootblock)
	@$(OBJDUMP) -S $(call objfile,bootblock) > $(call asmfile,bootblock)
	@$(OBJCOPY) -S -O binary $(call objfile,bootblock) $(call outfile,bootblock)
	@$(call totarget,sign) $(call outfile,bootblock) $(bootblock)

$(call create_target,bootblock)
```
对应执行的命令为：

![](assets/1.4.png)

参数解释：

* `-N`:指定读取/写入文本和数据段；

* `-e start`:使用指定的符号start作为程序的初始执行点；

* `-Ttext 0x7C00`:使用指定的地址0x7C00作为文本段的起始点。

可以看到，要生成bootblock，需要用GCC编译器将boot目录下的bootasm.S和bootmain.c编译生成.o文件，再把它们连接为一个可执行文件或库文件bootblock。由bootasm.S生成bootasm.o和由bootmain.c生成bootmain.o的命令如下：

![](assets/1.6.png)

参数解释：

* `-march=i686`:gcc/g++编译器通过-march指定cpu架构，指定该选项之后编译器将不会生成兼容的指令集，而是该架构支持的特定指令集，可以取得一部分优化的效果，此处根据i686架构对代码进行指令的优化；

* `-fno-builtin`:不承认所有不是以builtin为开头的内建函数;

* `-fno-PIC`:生成non-PIC代码；

* `-Wall`:生成所有的警告；

* `-ggdb`:尽可能的生成gdb的可以使用的调试信息；

* `-m32`:生成适用于32位环境的代码;

* `-gstabs`:以stabs格式声称调试信息,但是不包括gdb调试信息；

* `-nostdinc`:使编译器不在系统缺省的头文件目录里面找头文件,一般和-I联合使用,明确限定头文件的位置；

* `-fno-stack-protector`:停止使用stack-protector功能(保护函数中通过alloca()分配缓存以及存在大于8字节的缓存)。

* `-Os`:是使用了所有-O2的优化选项，但又不缩减代码尺寸的方法;

* `-c`:编译、汇编到目标代码（也就是计算机可识别的二进制）。


**综上所述**

生成ucore.img的过程为

* 编译所有生成bin/kernel所需的文件

* 链接生成bin/kernel

* 编译bootasm.S和bootmain.c

* 生成obj/bootblock.o

* 生成ucore.img
#### 2.一个被系统认为是符合规范的硬盘主引导扇区的特征是什么？
* 磁盘主引导扇区大小为512字节

* 多余的空间填0

* 第510个（倒数第二个）字节是0x55，

* 第511个（倒数第一个）字节是0xAA。

* 由不超过466字节的启动代码和不超过64字节的硬盘分区表加上两个字节的结束符组成
### 练习2：使用qemu执行并调试lab1中的软件
* 从CPU加电后执行的第一条指令开始，单步跟踪BIOS的执行。

修改 lab1/tools/gdbinit,内容为:
```
set architecture i8086//设定i8086为系统默认结构
target remote :1234//设定与qemu模拟器链接的1234端口号
```
在 lab1目录下，执行
```
make debug
```
在看到gdb的调试界面(gdb)后，在gdb调试界面下执行如下命令单步跟踪BIOS
```
si
```
在gdb界面下，可通过如下命令来看BIOS的代码
```
x /2i $pc  //显示当前eip处的汇编指令
```
得到如下截图

![](assets/2.1.png)

* 在初始化位置0x7c00设置实地址断点,测试断点正常。

修改 lab1/tools/gdbinit,内容为:
```
set architecture i8086//设定i8086为系统默认结构
target remote :1234//设定与qemu模拟器链接的1234端口号
b *0x7c00  //在0x7c00处设置断点。此地址是bootloader入口点地址，可看boot/bootasm.S的start地址处
continue//继续执行
x /4i $pc  //显示当前eip处的汇编指令,显示4条
```
在 lab1目录下，执行
```
make debug
```
在gdb界面下，可通过如下命令来看寄存器的值
```
print $cs  //显示当前cs寄存器的值
print $eip //显示当前eip寄存器的值
```
得到如下截图

![](assets/2.2.png)

由cs:ip=0:0x7c00可以知道，此时停止在了0x7c00处，也就是说断点设置正常

* 从0x7c00开始跟踪代码运行,将单步跟踪反汇编得到的代码与bootasm.S和 bootblock.asm进行比较。

直接比较bootasm.S和 bootblock.asm发现这两个文件的代码是一样的，但是bootasm.S不含bootmain部分的代码，根据实验指导书设置了hook-stop之后，用nexti命令(单步一条机器指令，不进入函数)单步调试程序，截图如下：

![](assets/2.3.1.png)

![](assets/2.3.2.png)

这部分代码与bootasm.S中的内容完全一样(相同指令名称不同，但是和bootblock.asm中的名称是一样的)，之后调用了bootmain，截图如下

![](assets/2.3.3.png)

之后还有有些循环的代码没有截出来，但是和bootblock.asm中的内容都是一样的。

* 自己找一个bootloader或内核中的代码位置，设置断点并进行测试。

在内核中pic_init函数处设置断点，首先修改lab1/tools/gdbinit,内容为:
```
fiel bin/kernel
target remote :1234
b pic_init
continue
x /i $pc
```
在 lab1目录下，执行
```
make debug
```
截图如下：

![](assets/2.4.0.png)

在gdb界面下输入如下命令
```
layout split  //Displays source, disassembly and command windows.
```
得到如下截图

![](assets/2.4.1.png)

可以看到成功在pic_init函数的入口处设置了断点，使用next命令单步调试，截图如下:

![](assets/2.4.2.png)

程序可以正常调试
### 练习3：分析bootloader进入保护模式的过程
**首先通过查阅资料了解实模式、保护模式、分段机制三个概念：**

* 实模式：在bootloader接手BIOS的工作后，当前的PC系统处于实模式（16位模式）运行状态，在这种状态下软件可访问的物理内存空间不能超过1MB，且无法发挥Intel 80386以上级别的32位CPU的4GB内存管理能力。实模式将整个物理内存看成分段的区域，程序代码和数据位于不同区域，操作系统和用户程序并没有区别对待，而且每一个指针都是指向实际的物理地址。这 样，用户程序的一个指针如果指向了操作系统区域或其他用户程序区域，并修改了内容，那么其后果就很可能是灾难性的。通过修改A20地址线可以完成从实模式到保护模式的转换。有关A20的进一步信息可参考附录“关于A20 Gate”。

*  保护模式：只有在保护模式下，80386的全部32根地址线有效，可寻址高达4G字节的线性地址空间和物理地址空间，可访问64TB（有2^14个段，每个段 最大空间为2^32字节）的逻辑地址空间，可采用分段存储管理机制和分页存储管理机制。这不仅为存储共享和保护提供了硬件支持，而且为实现虚拟存储提供了硬件支持。通过提供4个特权级和完善的特权检查机制，既能实现资源共享又能保证代码数据的安全及任务的隔离。保护模式下，有两个段表：GDT（Global Descriptor Table）和LDT（Local Descriptor Table），每一张段表可以包含8192 (2^13)个描述符[1]，因而最多可以同时存在2 * 2^13 = 2^14个段。虽然保护模式下可以有这么多段，逻辑地址空间看起来很大，但实际上段并不能扩展物理地址空间，很大程度上各个段的地址空间是相互重叠的。目前所谓的64TB（2^(14+32)=2^46）逻辑地址空间是一个理论值，没有实际意义。在32位保护模式下，真正的物理空间仍然只有2^32字节那么大。

* 分段存储管理机制：只有在保护模式下才能使用分段存储管理机制。分段机制将内存划分成以起始地址和长度限制这两个二维参数表示的内存块，这些内存块就称之为段 （Segment）。编译器把源程序编译成执行程序时用到的代码段、数据段、堆和栈等概念在这里可以与段联系起来，二者在含义上是一致的。分段机制涉及4个关键内容：逻辑地址、段描述符（描述段的属性）、段描述符表（包含多个段描述符的“数组”）、段选择子（段寄存器，用于定位段描述符 表中表项的索引）。

**了解相关问题：**

* 为何开启A20，以及如何开启A20：开启A20是为了完成从实模式到保护模式的转换，使得CPU能够充分使用32位的寻址能力。打开A20 Gate的具体步骤大致如下（参考bootasm.S）：1.等待8042 Input buffer为空；2.发送Write 8042 Output Port （P2）命令到8042 Input buffer；3.等待8042 Input buffer为空；4.将8042 Output Port（P2）得到字节的第2位置1，然后写入8042 Input buffer；

* 如何初始化GDT表：一个简单的GDT表和其描述符已经静态储存在引导区中，代码`lgdt gdtdesc`将其直接载入

* 如何使能和进入保护模式：通过将 cr0 寄存器 PE 位置 1 便开启了保护模式。通过长跳转更新 cs 的基地址，设置段寄存器，并建立堆栈，转到保护模式完成，进入 boot 主方法。

**根据源码lab1/boot/bootasm.S文件分析bootloader进入保护模式的过程**
```
# start address should be 0:7c00, in real mode, the beginning address of the running bootloader
.globl start
start:
.code16                                             # Assemble for 16-bit mode
    cli                                             # Disable interrupts
    cld                                             # String operations increment

    # Set up the important data segment registers (DS, ES, SS).
    xorw %ax, %ax                                   # Segment number zero
    movw %ax, %ds                                   # -> Data Segment
    movw %ax, %es                                   # -> Extra Segment
    movw %ax, %ss                                   # -> Stack Segment
```
bootloader入口为start, 被BIOS加载到内存的0x7c00处，此时cs=0, eip=0x7c00，然后执行的操作分别为关闭中断、清除EFLAGS的DF位以及将ax, ds, es, ss寄存器初始化为0；

接下来开启A20:

1.等待8042 Input buffer为空:从0x64内存地址中（映射到8042的status register）中读取8042的状态，直到读取到的该字节第二位（input buffer是否有数据）为0，即input buffer中无数据；
```
    # Enable A20:
    #  For backwards compatibility with the earliest PCs, physical
    #  address line 20 is tied low, so that addresses higher than
    #  1MB wrap around to zero by default. This code undoes this.
seta20.1:
    inb $0x64, %al                                  # Wait for not busy(8042 input buffer empty).
    testb $0x2, %al
    jnz seta20.1
```
2.发送Write 8042 Output Port （P2）命令到8042 Input buffer：接下来往0x64写入0xd1命令，表示修改8042的P2 port；
```
    movb $0xd1, %al                                 # 0xd1 -> port 0x64
    outb %al, $0x64                                 # 0xd1 means: write data to 8042's P2 port
```
3.等待8042 Input buffer为空：从0x64内存地址中（映射到8042的status register）中读取8042的状态，直到读取到的该字节第二位（input buffer是否有数据）为0，即input buffer中无数据；
```
seta20.2:
    inb $0x64, %al                                  # Wait for not busy(8042 input buffer empty).
    testb $0x2, %al
    jnz seta20.2
```
4.将8042 Output Port（P2）得到字节的第2位置1，然后写入8042 Input buffer：接下来往0x60端口写入0xDF，表示将P2 port的第二个位（A20）选通置为1；
```
    movb $0xdf, %al                                 # 0xdf -> port 0x60
    outb %al, $0x60                                 # 0xdf = 11011111, means set P2's A20 bit(the 1 bit) to 1
```
至此，A20开启。

接下来需要设置GDT（全局描述符表）：

在bootasm.S中已经静态地描述了一个简单的GDT(在这个GDT中将代码段和数据段的base均设置为了0，而limit设置为了2^32-1即4G，使得逻辑地址等于线性地址，方便后续对于内存的操作)，如下所示:
```
# Bootstrap GDT
.p2align 2                                          # force 4 byte alignment
gdt:
    SEG_NULLASM                                     # null seg
    SEG_ASM(STA_X|STA_R, 0x0, 0xffffffff)           # code seg for bootloader and kernel
    SEG_ASM(STA_W, 0x0, 0xffffffff)                 # data seg for bootloader and kernel

gdtdesc:
    .word 0x17                                      # sizeof(gdt) - 1
    .long gdt                                       # address gdt
```
所以只需要使用如下命令载入这个GDT
```
    lgdt gdtdesc
```
然后将cr0寄存器的PE位置1，从实模式切换到保护模式：
```
    movl %cr0, %eax
    orl $CR0_PE_ON, %eax
    movl %eax, %cr0
```
然后使用一个长跳转指令，将cs修改为32位段寄存器，以及跳转到protcseg这一32位代码入口处，此时CPU进入32位模式：
```
    ljmp $PROT_MODE_CSEG, $protcseg
```
接下来执行的32位代码功能为：设置ds、es, fs, gs, ss这几个段寄存器，然后初始化栈的frame pointer和stack pointer，然后调用使用C语言编写的bootmain函数，进行操作系统内核的加载，至此，bootloader已经完成从实模式进入到保护模式。
```
.code32                                             # Assemble for 32-bit mode
protcseg:
    # Set up the protected-mode data segment registers
    movw $PROT_MODE_DSEG, %ax                       # Our data segment selector
    movw %ax, %ds                                   # -> DS: Data Segment
    movw %ax, %es                                   # -> ES: Extra Segment
    movw %ax, %fs                                   # -> FS
    movw %ax, %gs                                   # -> GS
    movw %ax, %ss                                   # -> SS: Stack Segment

    # Set up the stack pointer and call into C. The stack region is from 0--start(0x7c00)
    movl $0x0, %ebp
    movl $start, %esp
    call bootmain

    # If bootmain returns (it shouldn't), loop.
```
### 练习4：分析bootloader加载ELF格式的OS的过程
#### bootloader如何读取硬盘扇区的？
查询实验指导书，读一个扇区的流程大致如下：

* 等待磁盘准备好

* 发出读取扇区的命令

* 等待磁盘准备好

* 把磁盘扇区数据读到指定内存

boot/bootmain.c中的readsect函数代码实现如下
```
/* waitdisk - wait for disk ready */
static void
waitdisk(void) {//如果0x1F7的最高2位是01，跳出循环
    while ((inb(0x1F7) & 0xC0) != 0x40)
        /* do nothing */;
}

/* readsect - read a single sector at @secno into @dst */
static void
readsect(void *dst, uint32_t secno) {
    // wait for disk to be ready
    waitdisk();//连续不断地从0x1F7地址读取磁盘的状态，直到磁盘不忙为止

    outb(0x1F2, 1); // 往0X1F2地址中写入要读取的扇区数，由于此处需要读一个扇区，因此参数为1
    outb(0x1F3, secno & 0xFF);// 输入要读取的扇区编号
    outb(0x1F4, (secno >> 8) & 0xFF);// 输入用来存放读写柱面的低8位字节 
    outb(0x1F5, (secno >> 16) & 0xFF); // 输入用来存放读写柱面的高8位字节
    outb(0x1F6, ((secno >> 24) & 0xF) | 0xE0); // 输入用来存放要读/写的磁盘号及磁头号，第四位为0表示从主盘读取，其余位被强制置为1
    outb(0x1F7, 0x20); // 向磁盘发出读命令0x20

    // wait for disk to be ready
    waitdisk();//等待磁盘完成读取操作

    // read a sector
    insl(0x1F0, dst, SECTSIZE / 4);// 从数据端口0x1F0读取数据，除以4是因为此处是以4个字节为单位的，这个从指令是以l(long)结尾这点可以推测出来
}
```
bootloader读取磁盘扇区的过程如下：

* 连续不断地从0x1F7地址读取磁盘的状态，直到磁盘不忙；

* 往0x1F2到0X1F6中设置读取扇区需要的参数

* 往0x1F7端口发送读命令0X20；

* 等待磁盘完成读取操作；

* 从数据端口0X1F0读取出数据到指定内存中；

bootmain.c中还有另外一个与读取磁盘相关的函数readseg,readseg简单包装了readsect，能够从磁盘第二个扇区起（kernel起始位置）offset个位置处，读取count个字节到指定内存中，由于上述readsect函数只能就整个扇区进行读取，因此在readseg中，不完全包括了指定数据的首尾扇区内容也要一起读取进来。
```
static void
readseg(uintptr_t va, uint32_t count, uint32_t offset) {
	uintptr_t end_va = va + count;

	va -= offset % SECTSIZE;

	uint32_t secno = (offset / SECTSIZE) + 1; 
	// 加1因为0扇区被引导占用
	// ELF文件从1扇区开始

	for (; va < end_va; va += SECTSIZE, secno ++) {
		readsect((void *)va, secno);
	}
}
```
#### bootloader是如何加载ELF格式的OS？
对ELF的定义在libs/elf.h中：
```
/* file header */
struct elfhdr {
    uint32_t e_magic;     // must equal ELF_MAGIC
    uint8_t e_elf[12];
    uint16_t e_type;      // 1=relocatable, 2=executable, 3=shared object, 4=core image
    uint16_t e_machine;   // 3=x86, 4=68K, etc.
    uint32_t e_version;   // file version, always 1
    uint32_t e_entry;     // entry point if executable
    uint32_t e_phoff;     // file position of program header or 0
    uint32_t e_shoff;     // file position of section header or 0
    uint32_t e_flags;     // architecture-specific flags, usually 0
    uint16_t e_ehsize;    // size of this elf header
    uint16_t e_phentsize; // size of an entry in program header
    uint16_t e_phnum;     // number of entries in program header or 0
    uint16_t e_shentsize; // size of an entry in section header
    uint16_t e_shnum;     // number of entries in section header or 0
    uint16_t e_shstrndx;  // section number that contains section name strings
};

/* program section header */
struct proghdr {
    uint32_t p_type;   // loadable code or data, dynamic linking info,etc.
    uint32_t p_offset; // file offset of segment
    uint32_t p_va;     // virtual address to map segment
    uint32_t p_pa;     // physical address, not used
    uint32_t p_filesz; // size of segment in file
    uint32_t p_memsz;  // size of segment in memory (bigger if contains bss）
    uint32_t p_flags;  // read/write/execute bits
    uint32_t p_align;  // required alignment, invariably hardware page size
};
```
struct elfhdr中重要的参数有：

* e_magic:判断读出来的ELF格式的文件是否为正确的格式；

* e_entry:程序入口所对应的虚拟地址;

* e_phoff:program header表的位置偏移；

* e_phnum，是program header表中的入口数目。

struct proghdr中重要的参数有：

* type：段类型；

* offset： 段相对文件头的偏移值；

* va：段的第一个字节将被放到内存中的虚拟地址；

* memsz：段在内存映像中占用的字节数。

在boot/bootmain.c有如下宏定义
```
#define SECTSIZE        512
#define ELFHDR          ((struct elfhdr *)0x10000) 
```
根据elfhdr和proghdr的结构描述，bootloader就可以完成对ELF格式的ucore操作系统的加载过程,bootloader加载ELF格式的OS的代码位于boot/bootmain.c中的bootmain函数中:
```
/* bootmain - the entry of bootloader */
void
bootmain(void) {
    // 首先读取ELF的头部(从硬盘读了8个扇区数据到内存0x10000处)
    readseg((uintptr_t)ELFHDR, SECTSIZE * 8, 0);

    // 通过储存在头部的参数e_magic判断是否是合法的ELF文件
    if (ELFHDR->e_magic != ELF_MAGIC) {
        goto bad;
    }

    struct proghdr *ph, *eph;

    // ELF头部有描述ELF文件应加载到内存什么位置的描述表，
	// 先将描述表的头地址存在ph
    ph = (struct proghdr *)((uintptr_t)ELFHDR + ELFHDR->e_phoff);
    eph = ph + ELFHDR->e_phnum;

	// 按照描述表将ELF文件中数据载入内存
    for (; ph < eph; ph ++) {
        readseg(ph->p_va & 0xFFFFFF, ph->p_memsz, ph->p_offset);
    }

    // 根据ELF头部储存的入口信息，找到内核的入口,然后使用函数调用的方式跳转到该地址上去(不再返回)
    ((void (*)(void))(ELFHDR->e_entry & 0xFFFFFF))();

bad:
    outw(0x8A00, 0x8A00);
    outw(0x8A00, 0x8E00);

    /* do nothing */
    while (1);
}
```
bootloader加载ELF格式的OS流程如下：

* 读取 ELF 的头部；

* 判断 ELF 文件是否是合法；

* 将描述表的头地址存在 ph；

* 按照描述表将 ELF 文件中数据载入内存；

* 根据 ELF 头部储存的入口信息，找到内核的入口,然后使用函数调用的方式跳转到该地址上去(不再返回)。
### 练习5：实现函数调用堆栈跟踪函数 
#### 函数实现
根据注释对kdebug.c中函数print_stackframe实现如下：
```
void
print_stackframe(void) {
     /* LAB1 练习五*/
    uint32_t ebp = read_ebp();//(1) call read_ebp() to get the value of ebp. the type is (uint32_t);
    uint32_t eip = read_eip();//(2) call read_eip() to get the value of eip. the type is (uint32_t);
    for (int i = 0; i < STACKFRAME_DEPTH && ebp != 0; i++) {//(3) from 0 .. STACKFRAME_DEPTH
        cprintf("ebp:0x%08x eip:0x%08x ", ebp, eip);//(3.1) printf value of ebp, eip
        uint32_t* p = (uint32_t *) (ebp + 2);
        cprintf("args:0x%08x 0x%08x 0x%08x 0x%08x", p[0], p[1], p[2], p[3]);//(3.2) (uint32_t)calling arguments [0..4] = the contents in address (uint32_t)ebp +2 [0..4]
        cprintf("\n");//(3.3) cprintf("\n");
        print_debuginfo(eip - 1);//(3.4) call print_debuginfo(eip-1) to print the C calling function name and line number, etc.
        eip = *((uint32_t *) (ebp + 4));
        ebp = *((uint32_t *) ebp);//(3.5) popup a calling stackframe
        /*NOTICE: the calling funciton's return addr eip  = ss:[ebp+4]
        *         the calling funciton's ebp = ss:[ebp]
        */
    }
}
```
实现过程：

* 首先使用read_ebp和read_eip函数获取当前stack frame的base pointer以及call read_eip这条指令下一条指令的地址，存入ebp, eip两个临时变量中；

read_ebp函数定义在libs/x86.h中
```
static inline uint32_t
read_ebp(void) {
    uint32_t ebp;
    asm volatile ("movl %%ebp, %0" : "=r" (ebp));
    return ebp;
}
```
read_eip函数定义在kern/debug/kdebug.c中
```
static __noinline uint32_t
read_eip(void) {
    uint32_t eip;
    asm volatile("movl 4(%%ebp), %0" : "=r" (eip));
    return eip;
}
```
* 然后使用cprint函数打印出ebp, eip的数值；

* 然后打印出当前系统栈最上面的栈帧对应的函数可能的参数，即内存地址分别为ebp+8, ebp+12, ebp+16, ebp+20的四个参数；

* 使用print_debuginfo打印出当前函数的函数名和行号；

* 根据动态链查找当前函数的调用者(caller)的栈帧, 根据约定，caller的栈帧的base pointer存放在ebp指向的内存单元，将其更新到ebp临时变量中，同时将eip(代码中对应的变量为ra)更新为调用当前函数的指令的下一条指令所在位置（return address），其根据约定存放在ebp+4所在的内存单元中；

* 如果ebp非零并且没有达到规定的STACKFRAME DEPTH的上限，则跳转到第二步，继续循环打印栈上栈帧和对应函数的信息；

在 lab1目录下，执行
```
make qemu
```
截图如下：

![](assets/5.1.png)
#### 解释最后一行各个数值的含义
![](assets/5.2.png)

ebp=0x00007bf8是第一个被调用函数的栈帧的(base pointer)，eip=0x00007d74是在该栈帧对应函数中调用下一个栈帧对应函数的指令的下一条指令的地址(return address)，而args是传递给这第一个被调用的函数的参数。在反汇编出来的kernel.abootblock.asm中寻找0x7d74这个地址，可以发现这个地址上的指令恰好是bootmain函数中调用OS kernel入口函数的指令的下一条：

![](assets/5.3.png)

也就是说最后一行打印出来的是bootmain这个函数对应的栈帧信息，其中ebp表示该栈帧的base pointer，eip表示在该函数内调用栈上的下一个函数指令的返回地址，而后面的args则表示传递给bootmain函数的参数，但是由于bootmain函数不需要任何参数，因此这些打印出来的数值并没有太大的意义，后面的unkonw之后的0x00007d73则是bootmain函数内调用OS kernel入口函数的该指令的地址。
### 练习6：完善中断初始化和处理 
#### 中断描述符表（也可简称为保护模式下的中断向量表）中一个表项占多少字节？其中哪几位代表中断处理代码的入口？
阅读实验指导书可知，在kern/mm/mmu.h中的struct gatedesc数据结构有对中断描述符的具体定义：

```
/* Gate descriptors for interrupts and traps */
struct gatedesc {
    unsigned gd_off_15_0 : 16;        // low 16 bits of offset in segment
    unsigned gd_ss : 16;            // segment selector
    unsigned gd_args : 5;            // # args, 0 for interrupt/trap gates
    unsigned gd_rsv1 : 3;            // reserved(should be zero I guess)
    unsigned gd_type : 4;            // type(STS_{TG,IG32,TG32})
    unsigned gd_s : 1;                // must be 0 (system)
    unsigned gd_dpl : 2;            // descriptor(meaning new) privilege level
    unsigned gd_p : 1;                // Present
    unsigned gd_off_31_16 : 16;        // high bits of offset in segment
};
```
![](assets/6.1.1.png)

从中断向量到GDT中相应中断服务程序起始位置的定位方式:

![](assets/6.1.2.png)

可见中断描述符表一个表项占8字节，最开始2个字节和最末尾2个字节定义了offset，第16-31位定义了处理代码入口地址的段选择子，使用其在GDT中查找到相应段的base address，加上offset就是中断处理代码的入口。
#### 请编程完善kern/trap/trap.c中对中断向量表进行初始化的函数idt_init。在idt_init函数中，依次对所有中断入口进行初始化。使用mmu.h中的SETGATE宏，填充idt数组内容。每个中断的入口由tools/vectors.c生成，使用trap.c中声明的vectors数组即可
mmu.h中的SETGATE宏
```
/* *
 * Set up a normal interrupt/trap gate descriptor
 *   - istrap: 1 for a trap (= exception) gate, 0 for an interrupt gate
 *   - sel: Code segment selector for interrupt/trap handler
 *   - off: Offset in code segment for interrupt/trap handler
 *   - dpl: Descriptor Privilege Level - the privilege level required
 *          for software to invoke this interrupt/trap gate explicitly
 *          using an int instruction.
 * */
#define SETGATE(gate, istrap, sel, off, dpl) {            \
    (gate).gd_off_15_0 = (uint32_t)(off) & 0xffff;        \
    (gate).gd_ss = (sel);                                \
    (gate).gd_args = 0;                                    \
    (gate).gd_rsv1 = 0;                                    \
    (gate).gd_type = (istrap) ? STS_TG32 : STS_IG32;    \
    (gate).gd_s = 0;                                    \
    (gate).gd_dpl = (dpl);                                \
    (gate).gd_p = 1;                                    \
    (gate).gd_off_31_16 = (uint32_t)(off) >> 16;        \
}
```
参数解释：

* gate：为相应的 idt[]数组内容，处理函数的入口地址

* istrap：系统段设置为 1，中断门设置为 0

* sel：段选择子

* off：为 vectors[]数组内容

* dpl：设置特权级。这里中断都设置为内核级，即第 0 级

idt_init函数的实现如下：
```
void
idt_init(void) {
     /* LAB1 YOUR CODE : STEP 2 */
    extern uintptr_t __vectors[];  //保存在vectors.S中的256个中断处理例程的入口地址数组
    int i;
   //使用SETGATE宏，对中断描述符表中的每一个表项进行设置
    for (i = 0; i < 256; i ++) { //IDT表项的个数
    //在中断门描述符表中通过建立中断门描述符，其中存储了中断处理例程的代码段GD_KTEXT和偏移量__vectors[i]，特权级为DPL_KERNEL。这样通过查询idt[i]就可定位到中断服务例程的起始地址。
     SETGATE(idt[i], 0, GD_KTEXT, __vectors[i], DPL_KERNEL);
    }
     //建立好中断门描述符表后，通过指令lidt把中断门描述符表的起始地址装入IDTR寄存器中，从而完成中段描述符表的初始化工作。
    lidt(&idt_pd);
}
```
#### 请编程完善trap.c中的中断处理函数trap，在对时钟中断进行处理的部分填写trap函数中处理时钟中断的部分，使操作系统每遇到100次时钟中断后，调用print_ticks子程序，向屏幕上打印一行文字”100 ticks”
print_ticks在trap.c中定义如下：
```
static void print_ticks() {
    cprintf("%d ticks\n",TICK_NUM);
#ifdef DEBUG_GRADE
    cprintf("End of Test.\n");
    panic("EOT: kernel seems ok.");
#endif
}
```
trap函数的实现如下：
```
/* trap_dispatch - dispatch based on what type of trap occurred */
static void
trap_dispatch(struct trapframe *tf) {
    char c;

    switch (tf->tf_trapno) {
    case IRQ_OFFSET + IRQ_TIMER:
        /* LAB1 YOUR CODE : STEP 3 */
        /* handle the timer interrupt */
        /* (1) After a timer interrupt, you should record this event using a global variable (increase it), such as ticks in kern/driver/clock.c
         * (2) Every TICK_NUM cycle, you can print some info using a funciton, such as print_ticks().
         * (3) Too Simple? Yes, I think so!
         */
        ticks++;
        if(ticks==100){
            print_ticks();
            ticks=0;
        }
        break;
    case IRQ_OFFSET + IRQ_COM1:
        c = cons_getc();
        cprintf("serial [%03d] %c\n", c, c);
        break;
    case IRQ_OFFSET + IRQ_KBD:
        c = cons_getc();
        cprintf("kbd [%03d] %c\n", c, c);
        break;
    //LAB1 CHALLENGE 1 : YOUR CODE you should modify below codes.
    case T_SWITCH_TOU:
    case T_SWITCH_TOK:
        panic("T_SWITCH_** ??\n");
        break;
    case IRQ_OFFSET + IRQ_IDE1:
    case IRQ_OFFSET + IRQ_IDE2:
        /* do nothing */
        break;
    default:
        // in kernel, it must be a mistake
        if ((tf->tf_cs & 3) == 0) {
            print_trapframe(tf);
            panic("unexpected trap in kernel.\n");
        }
    }
}

/* *
 * trap - handles or dispatches an exception/interrupt. if and when trap() returns,
 * the code in kern/trap/trapentry.S restores the old CPU state saved in the
 * trapframe and then uses the iret instruction to return from the exception.
 * */
void
trap(struct trapframe *tf) {
    // dispatch based on what type of trap occurred
    trap_dispatch(tf);
}
```
即每遇到一次时钟中断ticks就加1，当ticks加到100时就调用print_ticks子程序向屏幕上打印一行文字”100 ticks”并把ticks归0。

执行截图如下：

![](assets/6.3.png)
### 扩展练习 Challenge 1
扩展proj4,增加syscall功能，即增加一用户态函数（可执行一特定系统调用：获得时钟计数值），当内核初始完毕后，可从内核态返回到用户态的函数，而用户态的函数又通过系统调用得到内核态的服务。
#### 内核态和用户态转换的相关知识点补充
* 从特权级的区别理解用户态和内核态：Intel x86架构的CPU一共有0~3四个特权级，0级最高，3级最低，硬件上在执行每条指令时都会对指令所具有的特权级做相应的检查。对于 Unix/Linux来说，只使用了0级特权级和3级特权级，在Unix/Linux系统中，一条工作在0级特权级的指令具有了CPU能提供的最高权力，而一条工作在3级特权级的指令具有CPU提供的最低或者说最基本权力。程序运行在3级特权级上时，就可以称之为运行在用户态，因为这是最低特权级，是普通的用户进程运行的特权级，大部分用户直接面对的程序都是运行在用户态；反之，当程序运行在0特权级上时，就可以称之为运行在内核态。运行在用户态下的程序不能直接访问操作系统内核数据结构和程序，比如用户态可以直接调用fork函数但是不能直接调用sys_fork函数。

* 用户态切换到内核态的3种方式：系统调用、异常、外围设备的中断。但从实际完成的操作来看，都相当于执行了一个中断响应的过程，因为系统调用实际上最终是中断机制实现的，而异常和中断的处理机制基本上也是一致的。

* 内核栈和用户栈的切换：从内核栈切换到用户栈,改变段寄存器特权级,并添加ESP和SS；用户态产生中断时自动切换到内核栈,即在内核栈内进行操作,改变段寄存器的特权级,去除ESP和SS。
#### 代码实现
根据上述知识点补充和实验指导书的提示，可以通过实现lab1_switch_to_user函数发出中断信号T_SWITCH_TOU从内核态切换到用户态，通过实现lab1_switch_to_kernel函数发出中断信号T_SWITCH_TOK从用户态转换到内核态。

首先把kern/init/init.c中kern_init函数调用lab1_switch_test函数的语句的注释去掉。在kern/init/init.c中对lab1_switch_test函数有如下定义：
```
static void
lab1_switch_test(void) {
    lab1_print_cur_status();
    cprintf("+++ switch to  user  mode +++\n");
    lab1_switch_to_user();
    lab1_print_cur_status();
    cprintf("+++ switch to kernel mode +++\n");
    lab1_switch_to_kernel();
    lab1_print_cur_status();
}
```
其中lab1_print_cur_status函数在init.c已经实现：
```
static void
lab1_print_cur_status(void) {
    static int round = 0;
    uint16_t reg1, reg2, reg3, reg4;
    asm volatile (
            "mov %%cs, %0;"
            "mov %%ds, %1;"
            "mov %%es, %2;"
            "mov %%ss, %3;"
            : "=m"(reg1), "=m"(reg2), "=m"(reg3), "=m"(reg4));
    cprintf("%d: @ring %d\n", round, reg1 & 3);
    cprintf("%d:  cs = %x\n", round, reg1);
    cprintf("%d:  ds = %x\n", round, reg2);
    cprintf("%d:  es = %x\n", round, reg3);
    cprintf("%d:  ss = %x\n", round, reg4);
    round ++;
}
```
**内核态切换到用户态**

lab1_switch_to_user函数的实现(产生中断T_SWITCH_TOU)：
```
static void
lab1_switch_to_user(void) {
    //LAB1 CHALLENGE 1 : TODO
    asm volatile ("int %0"::"i"(T_SWITCH_TOU));
}
```
在trap.c中定义一个trapframe全局变量trapframetu做临时栈使用(在trap.c第94行),修改kern/trap/trap.c中trap_dispatch函数对中断信号T_SWITCH_TOU的处理：
```
    case T_SWITCH_TOU:
        if(tf->tf_cs!=USER_CS){ //当前已经为用户态时跳过
            trapframetu=*tf; //把中断帧的值赋给临时栈
            trapframetu.tf_cs=USER_CS;//更改代码段
            trapframetu.tf_ds=trapframetu.tf_es=trapframetu.tf_ss=USER_DS;//更改数据段，注意有SS
            trapframetu.tf_esp=(uint32_t)tf+sizeof(struct trapframe)-8;//更改ESP
            trapframetu.tf_eflags|=FL_IOPL_MASK;//更改EFLAGS,使得用户态可以使用 in/out 指令
            *((uint32_t*)tf-1)=&trapframetu;//因为从内核栈切换到用户栈,所以修改栈顶地址
        }
        break;
```
**用户态转换到内核态**

由于在用户态下调用T_SWITCH_TOK部分,所以要在创建IDT里把对应的访问权限设置为USER，即在trap.c的idt_init函数里创建IDT的循环后添加一个语句：
```
SETGATE(idt[T_SWITCH_TOK], 0, GD_KTEXT,__vectors[T_SWITCH_TOK], DPL_USER); 
```
lab1_switch_to_kernel函数的实现(产生中断T_SWITCH_TOK)：
```
static void
lab1_switch_to_kernel(void) {
    //LAB1 CHALLENGE 1 :  TODO
    asm volatile ("int %0"::"i"(T_SWITCH_TOK));
}
```
在trap.c中定义一个trapframe全局变量trapframetk做临时栈使用(在trap.c第94行),修改kern/trap/trap.c中trap_dispatch函数对中断信号T_SWITCH_TOK的处理：
```
    case T_SWITCH_TOK:
        if(tf->tf_cs!=KERNEL_CS){  //当前已经为内核态时跳过
            trapframetk=*tf;  //把中断帧的值赋给临时栈
            trapframetk.tf_cs=KERNEL_CS;  //更改代码段
            trapframetk.tf_ds=trapframetk.tf_es=KERNEL_DS;  //更改数据段,这次没改SS
            trapframetk.tf_eflags&=~FL_IOPL_MASK;  //更改EFLAGS,让用户态不能执行 in/out 指令
            int offset=tf->tf_esp-(sizeof(struct trapframe)-8);  //转换后少了ESP和SS,故需要偏移
            __memmove(offset,&trapframetk,sizeof(struct trapframe)-8);  //把修改好的栈移到目标位置
            *((uint32_t*)tf-1)=offset;  //重设栈顶地址
        }
        break;
```
完成代码以后，执行 make grade，结果如下：

![](assets/7.png)
### 扩展练习 Challenge 2
用键盘实现用户模式内核模式切换。具体目标是：“键盘输入3时切换到用户模式，键盘输入0时切换到内核模式”。 基本思路是借鉴软中断(syscall功能)的代码，并且把trap.c中软中断处理的设置语句拿过来。

使用make qemu命令启动程序，使用键盘尝试输入0和3，发现出现如下结果：

![](assets/8.1.png)

查看trap.c对中断信号处理部分的代码，发现是下面这部分代码导致了上图的结果：
```
    case IRQ_OFFSET + IRQ_KBD:
        c = cons_getc();
        cprintf("kbd [%03d] %c\n", c, c);
        break;
```
将拓展一中对中断信号T_SWITCH_TOU和T_SWITCH_TOK的处理代码稍作修改然后添加到对IRQ_OFFSET + IRQ_KBD的处理代码上即可，修改后对IRQ_OFFSET + IRQ_KBD的处理代码如下：
```
    case IRQ_OFFSET + IRQ_KBD:
        c = cons_getc();
        cprintf("kbd [%03d] %c\n", c, c);
        if(c=='0'){
            if(tf->tf_cs!=KERNEL_CS){  //当前已经为内核态时跳过
                cprintf("+++ switch to  kernel  mode +++\n");
                trapframetk=*tf;  //把中断帧的值赋给临时栈
                trapframetk.tf_cs=KERNEL_CS;  //更改代码段
                trapframetk.tf_ds=trapframetk.tf_es=KERNEL_DS;  //更改数据段,这次没改SS
                trapframetk.tf_eflags&=~FL_IOPL_MASK;  //更改EFLAGS,让用户态不能执行 in/out 指令
                int offset=tf->tf_esp-(sizeof(struct trapframe)-8);  //转换后少了ESP和SS,故需要偏移
                __memmove(offset,&trapframetk,sizeof(struct trapframe)-8);  //把修改好的栈移到目标位置
                *((uint32_t*)tf-1)=offset;  //重设栈顶地址
            }
        }
        else if(c=='3'){
            if(tf->tf_cs!=USER_CS){ //当前已经为用户态时跳过
                cprintf("+++ switch to  user  mode +++\n");
                trapframetu=*tf; //把中断帧的值赋给临时栈
                trapframetu.tf_cs=USER_CS;//更改代码段
                trapframetu.tf_ds=trapframetu.tf_es=trapframetu.tf_ss=USER_DS;//更改数据段，注意有SS
                trapframetu.tf_esp=(uint32_t)tf+sizeof(struct trapframe)-8;//更改ESP
                trapframetu.tf_eflags|=FL_IOPL_MASK;//更改EFLAGS,使得用户态可以使用 in/out 指令
                *((uint32_t*)tf-1)=&trapframetu;//因为从内核栈切换到用户栈,所以修改栈顶地址
            }
        }
        break;
```
使用make qemu命令启动程序，运行结果如下：
![](assets/8.2.png)
## 参考答案分析
* 练习1的参考答案与本实验报告中的解答基本一致，但是有部分区别：在练习1中本实验报告中是根据执行`$ make "V="`查看make执行了哪些命令；参考答案是直接对makefile的代码进行分析。

* 练习2的参考答案与本实验报告中的解答基本一致，但是有部分区别：在练习2的调试中，参考答案将gdb调试结果输出到log文件中，而本实验中的解答只是将调试结果输出到屏幕上。

* 练习3的参考答案与本实验报告中的解答基本一致，但是有部分区别：本实验报告中先通过查阅实验指导书对实模式、保护模式、分段机制三个概念做了较详细的解释，并且先回答了指导书中提出的相关问题然后分析了bootloader进入保护模式的过程。

* 练习4的参考答案与本实验报告中的解答基本一致，都是对相关代码进行分析，只是本实验报告添加了总结。

* 练习5的参考解答与本实验报告中的解答一致，均是利用栈上保存的动态链信息（ebp）来查找栈上所有栈帧的内容；

* 练习6的参考答案解法与本实验报告解法基本一致，主要区别在于第三问本实验报告中采用的是ticks每到达100就归0，而参考答案采用的是在判断时ticks对TICK_NUM(值为100)取余；

* 拓展一的参考答案解法与本实验报告解法部分一致，主要区别在于本实验报告对内核态和用户态的相关知识点做了一些补充，答案在ab1_switch_to_user函数中先需要预留了一段 8 字节空间用来给之后 ss 和 esp 的入栈，而本实验报告中esp和ss的添加和减少是直接在中断处理程序中通过临时栈和地址偏移解决的。

* 所提供参考答案没有关于拓展二的解答，因此无法进行分析对比；
## 本实验中重要的知识点
在本实验设计到的知识点分别有：

* 基于分段的内存管理机制；

* CPU的中断机制；

* x86 CPU的保护模式；

* 计算机系统的启动过程；

* ELF文件格式；

* 读取LBA模式硬盘的方法；

* 编译ucore OS和bootloader的过程；

* GDB的使用方法；

* c函数的函数调用实现机制；

对应到的OS中的知识点分别有：

* 物理内存的管理；

* 外存的访问；

* OS的启动过程；

* OS中对中断机制的支持；

* OS使用保护机制对关键代码和数据的保护；

两者的关系为，前者硬件中的机制为OS中相应功能的实现提供了底层支持；
## 实验中没有对应上的重要知识点
OS原理中很重要，但是本次实验没有涉及到的知识点有：

* 操作系统的线程、进程管理、调度，以及进程间的共享互斥；

* 虚拟内存的管理，页式内存管理机制；

* 文件系统；
