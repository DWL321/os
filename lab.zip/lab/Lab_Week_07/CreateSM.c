#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <fcntl.h>

#define M_SIZE 4017913856  /* 系统一次可以申请的共享内存空间M的最大值 */

#define MAX_NAME_LEN 12 //定义名字的最大长度：11个字节
#define MAX_STUDENT_NUM 200895692
//堆中单元数量(4017913856-4-4-8)/(4+4+12)=200895692
typedef struct Student{
    int flag;//结点的删除标识，删除的结点flag=1
    int id;//学号
    char name[MAX_NAME_LEN];
}student;
struct shared_struct {
    int num;//需要使用这个共享内存空间的进程数，不包括创建M的进程
    int lock;//逻辑值 lock 用来保证同一时间只有一个进程进入M,lock=1表示有进程正在使用M
    long long tail;//堆中最后一个有效单元的位置，-1表示堆为空
    student students[MAX_STUDENT_NUM];//静态链表L
};

#define PERM S_IRUSR|S_IWUSR|IPC_CREAT

#define ERR_EXIT(m) \
    do { \
        perror(m); \
        exit(EXIT_FAILURE); \
    } while(0)

int main(int argc, char *argv[])
{
    struct stat fileattr;
    key_t key; /* of type int */
    int shmid; /* shared memory ID */
    void *shmptr;
    struct shared_struct *shared; /* structured shm */
    char pathname[80], key_str[10], cmd_str[80];
    long long shmsize;
    int ret;

    shmsize = sizeof(struct shared_struct);
    printf("max record number = 1, shm size = %lld\n", shmsize);

    if(argc <2) {
        printf("Usage: ./a.out pathname\n");
        return EXIT_FAILURE;
    }
    strcpy(pathname, argv[1]);
  
    if(stat(pathname, &fileattr) == -1) {
        ret = creat(pathname, O_RDWR);
        if (ret == -1) {
            ERR_EXIT("creat()");
        }
        printf("shared file object created\n");
    }
 
    key = ftok(pathname, 0x27); /* 0x27 a project ID 0x0001 - 0xffff, 8 least bits used */
    if(key == -1) {
        ERR_EXIT("shmcon: ftok()");
    }
    printf("key generated: IPC key = %x\n", key); /* can set any nonzero key without ftok()*/

    shmid = shmget((key_t)key, shmsize, 0666|PERM);
    if(shmid == -1) {
        ERR_EXIT("shmcon: shmget()");
    }
    printf("shmcon: shmid = %d\n", shmid);

    shmptr = shmat(shmid, 0, 0); /* returns the virtual base address mapping to the shared memory, *shmaddr=0 decided by kernel */

    if(shmptr == (void *)-1) {
        ERR_EXIT("shmcon: shmat()");
    }
    printf("shmcon: shared Memory attached at %p\n", shmptr);
    
    shared = (struct shared_struct *)shmptr;

    //初始化共享内存空间M：无进程访问、OP进程数为0、堆为空
    shared->lock=shared->num = 0;
    shared->tail=-1;

    sprintf(cmd_str, "ipcs -m | grep '%d'\n", shmid); 
    int Exit=0;
    while (!Exit){
        while(shared->lock==1||shared->num>0){//有OP进程访问M或存在OP进程时CR进程挂起
            sleep(1);
        }
        shared->lock=1;//CR进程进入M
        printf("是否退出程序？是请输入1，否则输入0：");
        scanf("%d",&Exit);
        shared->lock=0;//CR进程退出M
    }
    
    if (shmctl(shmid, IPC_RMID, 0) == -1) {//断开共享内存连接
        ERR_EXIT("shmcon: shmctl(IPC_RMID)");
    }
    else {
        printf("shmcon: shmid = %d removed \n", shmid);
        printf("\n------ Shared Memory Segments ------\n");
        system(cmd_str);
    }
    exit(EXIT_SUCCESS);
}
