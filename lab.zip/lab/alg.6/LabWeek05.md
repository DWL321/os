# Lab Week 05技术报告
## 实验内容
* 编译运行课件 Lecture 06 例程代码:Algorithms 6-1 ~ 6-6.
## 技术日志
### alg.6-1-fork-demo.c
* 程序分析
```
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int count = 1;//count是main函数中的一个本地变量
    pid_t childpid;
    
    childpid = fork(); /* child duplicates parent’s address space */
    /*fork()函数将父进程的地址空间完全复制得到了一个子进程，这个子进程并不与父进程共用内存空间，而是开辟了一块新的内存。这种机制允许父进程与子进程轻松通信，之后父进程和子进程都继续执行处于系统调用fork()之后的指令。*/
    if (childpid < 0) {//fork()失败
        perror("fork()");
        return EXIT_FAILURE;
    }
    else /* fork() returns 2 values: 0 for child pro and childpid for parent pro */
        if (childpid == 0) { /* This is child pro */
            count++;//子进程继承了父进程的环境变量count，原来值为1，加一后变为2
            printf("Child pro pid = %d, count = %d (addr = %p)\n", getpid(), count, &count); 
            //输出子进程的pid，子进程的count值，子进程的count的虚拟内存地址
        }
        else { /* This is parent pro */
            //输出父进程的pid，父进程的childpid，父进程的count值，父进程的count的虚拟内存地址
            printf("Parent pro pid = %d, child pid = %d, count = %d (addr = %p)\n", getpid(), childpid, count, &count);
            sleep(5);//父进程挂起5秒
            wait(0); /* waiting for all children terminated */
        }
    printf("Testing point by %d\n", getpid()); /* child executed this statement and became defunct before parent wait() */
    return EXIT_SUCCESS;//返回值表示运行成功
}
```
* 运行截图

![](assets/1.png)

* 结果分析

第一行输出是在父进程执行的，输出了父进程的pid(19251)，父进程的child pid(19252)，父进程地址空间的count(1)以及count的虚拟地址(0x7ffdb44faaa0)，子进程修改count但是父进程count不变是因为父子进程使用的是两块不同的内存空间，映射到内存的像不同，count物理地址不同。

第二行输出是在子进程执行的，因为父进程被sleep(5)挂起5秒，输出了子进程的pid(19252，与父进程child pid相同)，子进程地址空间的count(2)以及count的虚拟地址(0x7ffdb44faaa0)，父子进程count的虚拟地址相同是因为子进程复制了父进程的地址空间。

第三行输出是在子进程中执行的，19252是子进程的pid。

第四行输出是在父进程中进行的，父进程醒来后需要等待所有子进程结束才能输出这句话，19251是父进程的pid。
### alg.6-2-vfork-demo.c
* 程序分析
```
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int count = 1;//环境变量
    pid_t childpid;
    
    childpid = vfork(); /* child shares parent’s address space */
    /*使用vfork()函数内核不再给子进程创建虚拟空间，直接让子进程共享父进程的虚拟空间。当父子进程中有更改相应段的行为发生时，再为子进程相应的段创建虚拟空间并分配物理空间。在vfork()函数创建子进程后父进程会阻塞，保证子进程先行运行。子进程在地址空间的操作父进程都能看到但是不能阻止，父进程得等子进程结束后才能继续执行。*/
    if (childpid < 0) {//vfork()失败
        perror("fork()");
        return EXIT_FAILURE;
    }
    else /* vfork() returns 2 values: 0 for child pro and childpid for parent pro */
        if (childpid == 0) { /* This is child pro, parent hung up until child exit ...  */
            count++;//子进程与父进程共享一个环境变量count，原来值为1，加一后变为2
            //输出子进程的pid，子进程的count值，子进程的count的虚拟内存地址
            printf("Child pro pid = %d, count = %d (addr = %p)\n", getpid(), count, &count); 
            printf("Child taking a nap ...\n");
            sleep(5);//子进程挂起5秒
            printf("Child waking up!\n");
            _exit(0); /* or exec(0); "return" will cause stack smashing，return会弹出栈帧 */
            //子进程结束
            /* 如果子进程未调用exec函数族函数或exit()函数，则父子进程会出现死锁现象。*/
        }
        else { /* This is parent pro, start when the vforked child finished */
        //输出父进程的pid，父进程的childpid，父进程的count值，父进程的count的虚拟内存地址
            printf("Parent pro pid = %d, child pid = %d, count = %d (addr = %p)\n", getpid(), childpid, count, &count);
            wait(0); /* not waitting this vforked child terminated*/
        }
    printf("Testing point by %d\n", getpid()); /* executed by parent pro only */
    return EXIT_SUCCESS;
}
```
* 运行截图

![](assets/2.png)

* 结果分析

第一行输出是在子进程执行的，父进程被阻塞，输出了子进程的pid(30471)，子进程地址空间的count(2)以及count的虚拟地址(0x7ffe015bca00)。

第二、三行输出是在子进程中执行的，中间隔了5秒。子进程调用sleep()函数把自己挂起而父进程不会执行是因为在vfork()函数创建子进程后父进程会阻塞，保证子进程先行运行，如果子进程调用exec函数族函数或exit()函数后父进程才能继续执行。

第四行输出是在父进程执行的，输出了父进程的pid(30470)，父进程的child pid(30471，与子进程pid相同)，父进程地址空间的count(2)以及count的虚拟地址(0x7ffe015bca00)，父子进程count的虚拟地址相同是因为子进程与父进程共用地址空间，count改变是因为vfork()函数创建的子进程会与父进程（在调用exec函数族函数或exit()函数前）共用地址空间，此时子进程如果使用变量则会直接修改父进程的变量值。因此，vfork()函数创建的子进程可能会对父进程产生干扰。

第五行输出是在父进程中进行的，父进程继续执行时vfork的子进程已经结束了，父进程不需要等待vfork的子进程结束，30470是父进程的pid。
### alg.6-3-fork-demo-nowait.c
* 程序分析
```
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
// #include <sys/wait.h>

int main(void)
{
    int count = 1;//环境变量
    pid_t childpid;
    
    childpid = fork(); /* child duplicates parent’s address space */
    /*fork()函数将父进程的地址空间完全复制得到了一个子进程，这个子进程并不与父进程共用内存空间，而是开辟了一块新的内存。这种机制允许父进程与子进程轻松通信，之后父进程和子进程都继续执行处于系统调用fork()之后的指令。*/
    if (childpid < 0) {//fork()失败
        perror("fork()");
        return EXIT_FAILURE;
    }
    else
        if (childpid == 0) { /* This is child pro */
            count++;//子进程继承了父进程的环境变量count，原来值为1，加一后变为2
            //输出子进程的pid，子进程的count值，子进程的count的虚拟内存地址
            printf("child pro pid = %d, count = %d (addr = %p)\n", getpid(), count, &count); 
            printf("child sleeping ...\n");
            //子进程挂起10秒
            sleep(10); /* parent exites during this period and child became an orphan */
            printf("\nchild waking up!\n");
        }
        else { /* This is parent pro */
            //输出父进程的pid，父进程的childpid，父进程的count值，父进程的count的虚拟内存地址
            printf("Parent pro pid = %d, child pid = %d, count = %d (addr = %p)\n", getpid(), childpid, count, &count);
        }
    printf("\nTesting point by %d\n", getpid()); /* executed both by parent and child */
    return EXIT_SUCCESS;
}
```
* 运行截图

![](assets/3.png)

一段时间后

![](assets/3.2.png)

* 结果分析

第一行输出是在父进程执行的，输出了父进程的pid(39607)，父进程的child pid(39607)，父进程地址空间的count(1)以及count的虚拟地址(0x7ffe3e4cbd60)，子进程修改count但是父进程count不变是因为父子进程使用的是两块不同的内存空间，映射到内存的像不同，count物理地址不同。

第二、三行输出是在父进程中进行的，父进程直接运行到输出这句话然后结束退出没有等待所有子进程结束，39606是父进程的pid。

第四行输出是在子进程执行的，父进程已经结束并退出，子进程成为了孤儿进程，输出了子进程的pid(39607，与父进程child pid相同)，子进程地址空间的count(2)以及count的虚拟地址(0x7ffe3e4cbd60)，父子进程count的虚拟地址相同是因为子进程复制了父进程的地址空间。

第五行输出是在子进程执行的，之后子进程挂起10秒。

第六、七、八、九、十、十一行输出是在bash进行的，ps命令是输出进程信息(静态显示)，-l是采用详细的格式来显示进程状况，在第九行可以看到子进程的PPID=7735而不是原来父进程的pid(39606)，且进程列表中没有PID=39606的父进程了，这是因为父进程终止后子进程成为孤儿进程，然后这个孤儿进程被pid为7735的进程收养了。这个pid为7735的进程会定期调用wait()，以便收集任何孤儿进程的退出状态，并释放孤儿进程标识符和进程表条目。

第十二行输出是在子进程执行的，子进程醒来并继续执行。

第十三、十四行输出是在子进程执行的，子进程运行结束成为僵尸进程，39607是子进程的pid。

第十五行在子进程刚结束时是如图一的光标，一段时间后变成如图二的bash输出，这是因为这个子进程和bash是异步的。进程运行结束后都会变成僵尸进程等待父进程调用wait()释放僵尸进程的进程标识符和它在进程表中的条目，一般僵尸进程的状态只是短暂存在，而孤儿进程没有父进程来释放资源，它的僵尸状态就比较长，需要系统中其他进程(Linux和UNIX是init进程)收养它成为它的父进程，需要等待这个新的父进程调用wait()，释放它的进程标识符和它在进程表中的条目。
### alg.6-4-fork-demo-wait.c
* 程序分析
```
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int count = 1;//环境变量
    pid_t childpid, terminatedid;
    
    childpid = fork(); /* child duplicates parent’s address space */
    /*fork()函数将父进程的地址空间完全复制得到了一个子进程，这个子进程并不与父进程共用内存空间，而是开辟了一块新的内存。这种机制允许父进程与子进程轻松通信，之后父进程和子进程都继续执行处于系统调用fork()之后的指令。*/
    if (childpid < 0) {//fork()失败
        perror("fork()");
        return EXIT_FAILURE;
    }
    else
        if (childpid == 0) { /* This is child pro */
            count++;//子进程继承了父进程的环境变量count，原来值为1，加一后变为2
            //输出子进程的pid，子进程的count值，子进程的count的虚拟内存地址
            printf("child pro pid = %d, count = %d (addr = %p)\n", getpid(), count, &count); 
            printf("child sleeping ...\n");
            //子进程挂起5秒
            sleep(5); /* parent wait() during this period */
            printf("\nchild waking up!\n");
        }
        else { /* This is parent pro */
            terminatedid = wait(0);//父进程阻塞，等待子进程终止，释放变成僵尸的子进程的资源，返回子进程的pid，然后父进程继续执行
            //输出父进程的pid，被等待结束的子进程的pid，父进程的count值，父进程的count的虚拟内存地址
            printf("Parent pro pid = %d, terminated pid = %d, count = %d (addr = %p)\n", getpid(), terminatedid, count, &count);
        }
    printf("\nTesting point by %d\n", getpid()); /* executed first by child and then parent */
    return EXIT_SUCCESS;
}
```
* 运行截图

![](assets/4.png)

* 结果分析

在fork()结束后，有两种情况：1.父进程先运行；2.子进程先运行。

第一行输出是在子进程执行的，输出了子进程的pid(40824，与父进程child pid相同)，子进程地址空间的count(2)以及count的虚拟地址(0x7ffcfecfe02c)，父子进程count的虚拟地址相同是因为子进程复制了父进程的地址空间。如果是情况一，那么父进程会执行`terminatedid = wait(0);`被阻塞，然后子进程会开始执行，如果是情况二，子进程就会执行第一行输出，所以第一行输出一定是子进程的。

第二行输出是在子进程执行的，之后子进程挂起5秒。

第三、四行输出是在子进程执行的，子进程醒来并继续执行。如果是情况一，则在子进程执行之前父进程就阻塞了，如果是情况二，则在子进程挂起期间，父进程开始执行后会立刻执行`terminatedid = wait(0);`被阻塞，所以在子进程挂起期间父进程无输出。

第五、六行输出是在子进程中执行的，40824是子进程的pid。

第七行输出是在父进程执行的，输出了父进程的pid(40823)，被释放的僵尸进程的pid(40824，与子进程pid相同,子进程已终止)，父进程地址空间的count(1)以及count的虚拟地址(0x7ffcfecfe02c)，子进程修改count但是父进程count不变是因为父子进程使用的是两块不同的内存空间，映射到内存的像不同，count物理地址不同。

第八、九行输出是在父进程中进行的，40823是父进程的pid。

第十行输出是在bash进程执行的，的第十一、十二、十三行输出是在ps进程执行的，ps命令是输出进程信息(静态显示)，可以看到父子进程都已经终止了。
### alg.6-5-0-sleeper.c
* 程序分析
```
/* gcc -o alg.6-5-0-sleeper.o alg.6-5-0-sleeper.c */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char* argv[])
{
    int secnd = 5;//设置睡眠时间为5秒

    if (argc > 1) {//如果有参数
        secnd = atoi(argv[1]);//把秒数改为参数字符串第二个字符对应的数字
        if ( secnd <= 0 || secnd > 10)//如果秒数不合法或过长，改为5秒
            secnd = 5;
    }

    //输出此进程的pid，它的父进程的pid
    printf("\nsleeper pid = %d, ppid = %d\nsleeper is taking a nap for %d seconds\n", getpid(), getppid(), secnd); /* ppid - its parent pro id */

    sleep(secnd);//此进程挂起secnd秒
    printf("\nsleeper wakes up and returns\n");//此进程醒来

    return 0;
}
```
* 运行截图

![](assets/5.png)

* 结果分析

所有输出都在一个进程中，这个进程pid为41904，它的父进程的pid为36450，之后它挂起了5秒又醒来输出最后一行后终止。
### alg.6-5-vfork-execv-wait.c
* 程序分析
```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <wait.h>

int main(int argc, char* argv[])
{
    pid_t childpid;

    childpid = vfork();
        /* child shares parent's address space */
        /*使用vfork()函数内核不再给子进程创建虚拟空间，直接让子进程共享父进程的虚拟空间。当父子进程中有更改相应段的行为发生时，再为子进程相应的段创建虚拟空间并分配物理空间。在vfork()函数创建子进程后父进程会阻塞，保证子进程先行运行。子进程在地址空间的操作父进程都能看到但是不能阻止，父进程得等子进程结束后才能继续执行。*/
    if (childpid < 0) {//vfork()失败
        perror("fork()");
        return EXIT_FAILURE;
    }
    else
        if (childpid == 0) { /* This is child pro */
            //输出子进程pid
            printf("This is child, pid = %d, taking a nap for 2 seconds ...\n", getpid());
            //子进程挂起2秒
            sleep(2); /* parent hung up and do nothing */

            char filename[80];
            struct stat buf;
            strcpy(filename, "./alg.6-5-0-sleeper.o");//把sleeper程序路径复制到filename字符串
            if(stat(filename, &buf) == -1) {//stat函数获取文件信息放到struct stat结构体buf里，成功返回0，失败返回-1
                perror("\nsleeper stat()");
                _exit(0);
            }
            char *argv1[] = {filename, argv[1], NULL};//创建一个字符串指针数组，argv[1]是输入的./a.out后面的那个字符串
            printf("child waking up and again execv() a sleeper: %s %s\n\n", argv1[0], argv1[1]); 
            execv(filename, argv1);//exec函数调用成功后不会再返回
/* parent resume at the point 'execv' called. The vforked pro terminated and alg.6-5-sleeper.o spawned as child in the same childpid but with duplicated address space and returns to parent without any stack smashing. parent and child execute asynchronously */
        }
        else { /* This is parent pro, start when the vforked child terminated */
            //输出父进程pid和父进程的childpid
            printf("This is parent, pid = %d, childpid = %d \n", getpid(), childpid);
                /* parent executed this statement during the EXECV time */
            int retpid = wait(0); 
                /* without wait(), the spawned EXECV may became an orphan */
            //输出wait()返回的子进程pid
            printf("\nwait() returns childpid = %d\n", retpid);
        }
        
    return EXIT_SUCCESS;
}
```
* 运行截图

![](assets/5.1.png)

* 结果分析

第一行输出是在子进程执行的，输出了子进程的pid(44357)，然后子进程挂起2秒，父进程处于阻塞等待状态。

第二、三行输出是在子进程执行的，子进程醒来调用execv函数启动了一个新的程序alg.6-5-0-sleeper.o，加载一个新的代码段、新的数据段与堆栈到一个新的地址空间，生成一个新的进程，旧子进程终止，新进程继承了旧子进程的pid，新进程也是父进程的子进程，但它与父进程是异步的。最后输出的`233`是我在`./a.out`后面输入的参数，即`argv1[1]`和`argv[1]`的内容。

第四行输出是在父进程执行的，输出了父进程的pid(44356)，父进程的child pid(44357)。vfork()的子进程终止了，所以父进程醒来了。之后父进程调用了wait(0)，父进程阻塞，等待新子进程终止，释放变成僵尸的新子进程的资源，返回被释放的子进程的pid，然后父进程继续执行。

第五、六、七、八、九行输出都是在新子进程sleeper中执行的，新子进程的pid是44357，与旧子进程的相同，ppid是44356，与父进程pid相同，新子进程挂起5秒后醒来输出第九行然后终止。

第十、十一行在父进程执行，父进程释放掉新子进程的资源后终止，wait()返回值是新子进程的pid(44357)。

注：使用vfrok()和exec函数族创建加载不同程序的进程树可以提高效率，但是vfork调用后父进程会阻塞到子进程exec被调用，因为共享，子进程对堆栈与数据段的任何改动都会对父进程产生同样影响。所以调用vfork后，要尽快调用exec，以降低风险。
### alg.6-6-vfork-execv-nowait.c
* 程序分析
```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <wait.h>

int main(int argc, char* argv[])
{
    pid_t childpid;

    childpid = vfork();
        /* child shares parent's address space */
        /*使用vfork()函数内核不再给子进程创建虚拟空间，直接让子进程共享父进程的虚拟空间。当父子进程中有更改相应段的行为发生时，再为子进程相应的段创建虚拟空间并分配物理空间。在vfork()函数创建子进程后父进程会阻塞，保证子进程先行运行。子进程在地址空间的操作父进程都能看到但是不能阻止，父进程得等子进程结束后才能继续执行。*/
    if (childpid < 0) {//vfork()失败
        perror("fork()");
        return EXIT_FAILURE;
    }
    else
        if (childpid == 0) { /* This is child pro */
            //输出子进程pid
            printf("This is child, pid = %d, taking a nap for 2 seconds ... \n", getpid());
            //子进程挂起2秒
            sleep(2); /* parent hung up and do nothing */

            char filename[80];
            struct stat buf;
            strcpy(filename, "./alg.6-5-0-sleeper.o");//把sleeper程序路径复制到filename字符串
            if(stat(filename, &buf) == -1) {//stat函数获取文件信息放到struct stat结构体buf里，成功返回0，失败返回-1
                perror("\nsleeper stat()");
                _exit(0);
            }
            char *argv1[] = {filename, argv[1], NULL};//创建一个字符串指针数组，argv[1]是输入的./a.out后面的那个字符串
            printf("child waking up and again execv() a sleeper: %s %s\n\n", argv1[0], argv1[1]);
            execv(filename, argv); /* parent resume at the point 'execv' called */
            //exec函数调用成功后不会再返回
        }
        else { /* This is parent pro, start when the vforked child terminated */
            //输出父进程pid和父进程的childpid
            printf("This is parent, pid = %d, childpid = %d \n",getpid(), childpid);
                /* parent executed this statement during the EXECV time */
            printf("parent calling shell ps\n");
            //系统调用shell命令，ps命令是输出进程信息(静态显示)，-l是采用详细的格式来显示进程状况，system()会调用fork()产生子进程，由子进程来调用/bin/sh-c string来执行参数string字符串所代表的命令，此命令执行完后随即返回原调用的进程。
            system("ps -l");
            sleep(1);//父进程挂起1秒
            return EXIT_SUCCESS;
                /* parent exits without wait() and child may become an orphan */
    }
}
```
* 运行截图

![](assets/6.png)

* 结果分析

第一行输出是在子进程执行的，输出了子进程的pid(45737)，然后子进程挂起2秒，父进程处于阻塞等待状态。

第二、三行输出是在子进程执行的，子进程醒来调用execv函数启动了一个新的程序alg.6-5-0-sleeper.o，加载一个新的代码段、新的数据段与堆栈到一个新的地址空间，生成一个新的进程sleeper，旧子进程终止，新进程继承了旧子进程的pid，新进程也是父进程的子进程，但它与父进程是异步的。最后输出的`233`是我在`./a.out`后面输入的参数，即`argv1[1]`和`argv[1]`的内容。

第四行输出是在父进程a.out执行的，输出了父进程的pid(45736)，父进程的child pid(44737)。vfork()的子进程终止了，所以父进程醒来了。

第五行输出是在父进程执行的，之后父进程调用system函数，系统调用shell命令，system()会调用fork()产生子进程sh，由子进程sh来调用/bin/sh-c ps -l来执行参数ps -l字符串所代表的命令。

第六、七、八行输出是在sleeper进程中执行的，输出sleeper进程的pid=45737(继承子vfork()的子进程)，ppid=45736(是父进程a.out的pid)，然后sleeper进程挂起5秒。然后a.out进程继续执行，挂起一秒，然后sh进程生成ps进程，ps进程开始执行。

第九到十四行输出是在ps进程中执行的，因为sleeper进程和sh进程异步,ps进程是sh进程的子进程，sleeper与ps进程也异步，根据pid和ppid的关系可以看出：bash进程是a.out进程的父进程，a.out进程是sleeper进程和sh进程的父进程，sh进程是ps进程的父进程。sleeper进程的WCHAN值为hrtime是因为sleeper进程处于定时5秒的sleep中。

第十五行是在bash进程中执行的，在第十四行输出结束后ps进程终止，然后sh进程终止，然后a.out进程终止，而sleeper进程与bash进程异步且sleeper进程还在挂起中，所以bash进程开始执行。在bash进程中执行ps -l命令，生成了ps进程。

第十六、十七、十八、十九行输出都是在ps进程中执行的，根据pid和ppid的关系可以看出：bash进程是ps进程的父进程，a.out进程已经终止，sleeper的ppid变成了7735,说明sleeper进程在a.out进程结束后变成了孤儿进程，但是它又被一个pid为7735的进程收养了。sleeper进程的WCHAN值为hrtime是因为sleeper进程仍处于定时5秒的sleep中。然后ps进程终止。

第二十行是在bash进程中执行的，因为sleeper进程与bash进程异步且sleeper进程还在挂起中。

第二十一行输出是在sleeper进程中执行的，sleeper进程醒来并终止，等待pid为7735的父进程调用wait()把变成僵尸的sleeper进程的资源释放。使用`ps -q 7735`命令查询这个父进程的信息，发现它是一个系统进程init的守护进程。