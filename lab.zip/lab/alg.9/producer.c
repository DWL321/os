#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <mqueue.h>
#include <string.h>

#include "alg.9-0-msgdata.h"

int main(int argc, char *argv[])
{
    int ret;
    mqd_t mqid;
    void *shmptr;
    const char *message_0 = "Hello World!优先级：";
    char message[100];
    char priority_str[10];

    mqid = mq_open(argv[1], O_RDWR, 0666); 
    if(mqid == -1) {
        ERR_EXIT("producer: shm_open()");
    } 

    for(int i=0;i<10;i++){
        strcpy(message,message_0);
        int priority=rand()%_SC_MQ_PRIO_MAX;
        sprintf(priority_str,"%d",priority);
        strcat(message,priority_str);
        ret = mq_send(mqid, message, strlen(message)+1, priority);
        if(ret == -1){
            ERR_EXIT("producer: mqueue_send()");
        } 

        printf("produced message: %s\n", message);
        sleep(1);
    }

    ret=mq_close(mqid);
    if(ret == -1) {
        ERR_EXIT("producer: mqueue_close()");
    }
    return EXIT_SUCCESS;
}