# Lab Week 16 实验报告
## 实验内容：CPU调度
+ 讨论课件 Lecture19-20 中 CPU 调度算法的例子,尝试基于 POSIX API 设计一个简单调度器(不考虑资源竞争问题):
    + 创建一些 Pthread 线程任务,建立一个管理链队列,结点内容起码包括到达时间、WCT、优先级、调度状态等调度参数;
    + 每个任务有一个调度信号量,任务启动后在其调度信号量上执行 wait;
    + 调度器按照调度策略对处于运行态的任务(如果有的话)的调度信号量执行 wait,并选取适当任务的调度信号量执行 signal;
    + 实现简单调度策略:FCFS、SJF、Priority。分别计算任务平均等待时间。
## 实验原理
### 课件 Lecture19-20 中 CPU 调度算法的例子相关POSIX API：
+ 对线程属性初始化：int pthread_attr_init(pthread_attr_t *attr);
    + attr:线程属性结构体指针变量;
        ```
        typedef struct
        {
            int detachstate;   // 线程的分离状态
            int schedpolicy;   // 线程调度策略
            structsched_param schedparam;    // 线程的调度参数
            int inheritsched;  // 线程的继承性
            int scope;         // 线程的作用域
            size_t guardsize;     // 线程栈末尾的警戒缓冲区大小
            int stackaddr_set; // 线程的栈设置
            void* stackaddr;     // 线程栈的位置
            size_t stacksize;     // 线程栈的大小
        } pthread_attr_t;
        ```
    + 返回值：若成功返回0，若失败返回-1。
+ 对线程属性去除初始化：int pthread_attr_destroy(pthread_attr_t*attr);
    + attr:线程属性结构体指针变量;
    + 返回值：若成功返回0，若失败返回-1。
+ 得到线程的作用域:int pthread_attr_getscope(const pthread_attr_t * attr, int * scope );
    + attr:线程属性结构体指针变量;
    + scope 线程的作用域;
    + 返回值：若成功返回0，若失败返回-1。
+ 设置线程的作用域：int pthread_attr_setscope(pthread_attr_t * attr, int * scope );
    + attr:线程属性结构体指针变量;
    + scope 线程的作用域，此属性表示线程间竞争CPU的范围，也就是说线程优先级的有效范围。POSIX的标准中定义了两个值：PTHREAD_SCOPE_SYSTEM(表示与系统中所有线程一起竞争CPU时间)和PTHREAD_SCOPE_PROCESS(表示仅与同进程中的线程竞争CPU)。
    + 返回值：若成功返回0，若失败返回-1。
+ 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
    + tidp:指向线程标识符的指针;
    + attr:设置线程属性;
    + start_rtn:线程运行函数的起始地址;
    + arg:运行函数的参数;
    + 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
+ 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
    + thread:被等待的线程ID;
    + retval:存储线程结束状态;
    + 返回值：若成功返回0，若失败返回-1。
+ 退出线程：void  pthread_exit（void  * retval）;
    + retval:把一个空指针类型的值传给pthread_join的第二个参数;
    + 返回值：返回一个空指针类型的值。
+ 获得线程的调度策略:int pthread_attr_getschedpolicy(const pthread_attr_t*attr,int *policy);
    + attr:线程属性结构体指针变量;
    + policy:调度策略,可能的值是先进先出（SCHED_FIFO）、轮转法（SCHED_RR）,或其它（SCHED_OTHER）。SCHED_FIFO策略允许一个线程运行直到有更高优先级的线程准备好，或者直到它自愿阻塞自己。在SCHED_FIFO调度策略下，当有一个线程准备好时，除非有平等或更高优先级的线程已经在运行，否则它会很快开始执行。SCHED_RR(轮循)策略是基本相同的，不同之处在于：如果有一个SCHED_RR策略的线程执行了超过一个固定的时期(时间片间隔)没有阻塞，而另外的SCHED_RR或SCHBD_FIFO策略的相同优先级的线程准备好时，运行的线程将被抢占以便准备好的线程可以执行。当有SCHED_FIFO或SCHED_RR策赂的线程在一个条件变量上等持或等持加锁同一个互斥量时，它们将以优先级顺序被唤醒。即，如果一个低优先级的SCHED_FIFO线程和一个高优先级的SCHED_FIFO线程都在等待锁相同的互斥且，则当互斥量被解锁时，高优先级线程将总是被首先解除阻塞。
    + 返回值：若成功返回0，若失败返回-1。
+ 设置线程的调度策略：int pthread_attr_setschedpolicy(pthread_attr_t *attr,intpolicy);
    + attr:线程属性结构体指针变量;
    + policy:调度策略；
    + 返回值：若成功返回0，若失败返回-1。
+ 获得线程的调度参数：int pthread_attr_getschedparam(const pthread_attr_t*attr,struct sched_param *param);
    + attr:线程属性结构体指针变量;
    + param：sched_param结构体指针，结构sched_param在文件/usr/include/bits/sched.h中定义如下,子成员sched_priority控制一个优先权值，大的优先权值对应高的优先权；
        ```
        struct sched_param
        {
            int sched_priority;
        };
        ```
    + 返回值：若成功返回0，若失败返回-1。
+ 设置线程的调度参数：int pthread_attr_setschedparam(pthread_attr_t *attr,conststruct sched_param *param);
    + attr:线程属性结构体指针变量;
    + param：sched_param结构体指针；
    + 返回值：若成功返回0，若失败返回-1。
+ 获取线程可以设置的最大优先级值：int sched_get_priority_max(int policy);
    + policy:调度策略；
    + 返回值：调用成功就返回可设置的最大优先级值，否则返回－1。
+ 获取线程可以设置的最小优先级值：int sched_get_priority_min(int policy);
    + policy:调度策略；
    + 返回值：调用成功就返回可设置的最小优先级值，否则返回－1。
### 管理链队列结点数据结构
```
typedef struct CONTROLRE
{  
    int id;              //线程编号
    pthread_t threads;   //线程tid
    int arrive;          //到达时间
    int wct;             //完成时间
    int burst;           //占用CPU时间
    int priority;        //优先级
    int state;           //调度状态：0-运行、1-就绪、2-终止
    sem_t control;       //调度信号量
    int wait;            //等待时间
}controler;
```
### 利用调度信号量调度线程
按照实验内容的提示，在本实验中，通过控制管理链队列结点成员调度信号量`control`来实现线程调度。在初始化管理链队列时将每个线程的调度信号量设置为0，线程启动后先调用sem_wait函数阻塞等待调度器调度。当调度器选中一个线程时，调用sem_post函数唤醒要调度的线程，然后挂起100微秒(如果此处调度器不挂起片刻的话可能导致调度器比要调度的线程先获得调度信号量)，然后调用sem_wait函数阻塞等待这个线程运行完。被调度的线程退出前要调用sem_post函数唤醒调度器。待所有未过期线程被调度运行完之后，调度器要对所有线程的调度信号量调用sem_post函数，确保过期线程也能不执行任务(无输出)地退出。
### 调度策略FCFS(先到先服务调度)
根据线程到达时间决定先运行哪一个线程，先到达的线程先运行。FCFS调度算法是非抢占式的，一旦CPU分配给了一个线程，该线程就会使用CPU直到释放为止。在本实验中，第一个到达的线程先运行，之后每终止一个线程就取管理链队列中到达时间最早的就绪线程开始运行，到达时间相同则取编号更小的线程，采用先按到达时间将管理链结点排序再从头开始逐个检查的算法。
### 调度策略SJF(短作业优先调度算法)
根据线程服务时间决定先运行哪一个线程，服务时间最短的先运行。在本实验中实现了非抢占式的SJF，先按到达时间将管理链结点排序，然后循环每次从队列里第一个就绪线程开始检查到达时间小于等于当前时间的就绪线程，取其中服务时间最短的调度，注意在检查的过程中发现过期的线程要将其终止，直到所有线程都终止就跳出循环。
### 调度策略Priority
根据线程优先级决定先运行哪一个线程，优先级最大的先运行。在本实验中实现了非抢占式的Priority调度算法，先按到达时间将管理链结点排序，然后循环每次从队列里第一个就绪线程开始检查到达时间小于等于当前时间的就绪线程，取其中优先级最大的调度，注意在检查的过程中发现过期的线程要将其终止，直到所有线程都终止就跳出循环。
### 代码具体实现
```
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <time.h>
#define NUM_THREADS 20

typedef struct CONTROLRE
{
    int id;              //线程编号
    pthread_t thread;   //线程tid
    int arrive;          //到达时间
    int wct;             //完成时间
    int burst;           //占用CPU时间
    int priority;        //优先级
    int state;           //调度状态：0-运行、1-就绪、2-终止
    sem_t control;       //调度信号量
    int wait;            //等待时间
}controler;

void *run(void *arg);//线程执行的函数
double average_wait_time(controler* con);//计算任务平均等待时间

int main(int argc, char *argv[]){
    controler con[NUM_THREADS];
    controler standand[NUM_THREADS];

    srand((int)time(0));
    //管理链队列初始化
    int i;
    for(i=0;i<NUM_THREADS;i++){
        con[i].id=i+1;
        con[i].arrive=rand()%(100*NUM_THREADS);
        con[i].wct=con[i].arrive+100000;
        con[i].burst=rand()%200;
        con[i].priority=rand()%99+1;
        con[i].state=1;
        standand[i]=con[i];
        sem_init(&(con[i].control), 0, 0);//初始化调度信号量
        sem_init(&(standand[i].control), 0, 0);//初始化调度信号量
    }

    //FCFS
    printf("FCFS\n");
    for(i=0;i<NUM_THREADS;i++){//创建多线程
        pthread_create(&(con[i].thread),NULL,&run,(void*)&con[i]);
    }
    sleep(1);
    
    for(i=0;i<NUM_THREADS-1;i++){//将所有线程按到达时间排序
        int j;
        for(j=1;j<NUM_THREADS-i;j++){
            if(con[j-1].arrive>con[j].arrive){
                controler t=con[j-1];
                con[j-1]=con[j];
                con[j]=t;
            }
        }
    }
    int now=0;
    int select=0;
    while(select<NUM_THREADS){//若还有线程未检查就继续调度
        int arrive=con[select].arrive;
        if(!(con[select].state==1&&con[select].wct>=now+con[select].burst)){//检测当前线程是否是调度状态为就绪且在截至时间前能完成的线程
            if(con[select].state==1){//终止在截至时间之前不能完成的已到达线程
                con[select].state=2;
                if(con[select].arrive<now)con[select].wait=now-con[select].arrive;
                else con[select].wait=0;
            }
            select++;
            continue;
        }

        //更新当前时间并计算此线程的等待时间
        if(now<=arrive){
            now=arrive;
            con[select].wait=0;
        }
        else{
            con[select].wait=now-arrive;
        }
        
        printf("now is %d\n",now);
        sem_post(&(con[select].control));//启动选中的线程
        usleep(100);
        sem_wait(&(con[select].control));//等待此线程运行结束
        
        now+=con[select].burst;//更新当前时间
        select++;
    }

    for(i=0;i<NUM_THREADS;i++){//唤醒所有未运行就被终止的线程
        sem_post(&(con[i].control));
    }
    for(i=0;i<NUM_THREADS;i++){//等待线程终止
        pthread_join(con[i].thread,NULL);
    }
    printf("FCFS average wait time:%lf\n",average_wait_time(con));
    printf("============================================================================\n\n");
    
    //SJF
    printf("SJF\n");
    for(i=0;i<NUM_THREADS;i++){//复原管理链队列
        con[i].id=standand[i].id;
        con[i].arrive=standand[i].arrive;
        con[i].wct=standand[i].wct;
        con[i].burst=standand[i].burst;
        con[i].priority=standand[i].priority;
        con[i].state=1;
        sem_destroy(&(con[i].control));
        sem_init(&(con[i].control), 0, 0);//初始化调度信号量
    }
    for(i=0;i<NUM_THREADS;i++){//创建多线程
        pthread_create(&(con[i].thread),NULL,&run,(void*)&con[i]);
    }
    sleep(1);

    for(i=0;i<NUM_THREADS-1;i++){//将所有线程按到达时间排序
        int j;
        for(j=1;j<NUM_THREADS-i;j++){
            if(con[j-1].arrive>con[j].arrive){
                controler t=con[j-1];
                con[j-1]=con[j];
                con[j]=t;
            }
        }
    }

    now=0;
    int first=0;//当前最早到达的未运行且在截至时间前能完成的线程
    while(first<NUM_THREADS){//若还有调度状态为就绪且在截至时间前能完成的线程就继续调度
        int arrive=con[first].arrive;//本次调度线程的到达时间
        int select=first;//本次要调度的线程
        if(now<con[first].arrive)now=con[first].arrive;//更新当前时间保证有线程就绪

        for(i=first;i<NUM_THREADS;i++){//寻找调度状态为就绪且在截至时间前能完成的已到达线程中占用CPU时间最短的线程
            if(con[i].state==1&&con[i].wct<now+con[i].burst&&con[i].arrive<=now){//终止在截至时间之前不能完成的已到达线程
                con[i].state=2;
                if(con[i].arrive<now)con[i].wait=now-con[i].arrive;
                else con[i].wait=0;
            }
            else if(con[i].state==1&&con[i].burst<con[select].burst&&con[i].arrive<=now&&con[i].wct>=now+con[i].burst){
                arrive=con[i].arrive;
                select=i;
            }
        }

        //计算此线程的等待时间
        if(now==arrive){
            con[select].wait=0;
        }
        else{
            con[select].wait=now-arrive;
        }
        
        printf("now is %d\n",now);
        sem_post(&(con[select].control));//启动选中的线程
        usleep(100);
        sem_wait(&(con[select].control));//等待此线程运行结束
        
        now+=con[select].burst;//更新当前时间

        for(;first<NUM_THREADS;first++){//寻找当前最早到达的就绪线程
            if(con[first].state==1)
                break;
        }
    }

    for(i=0;i<NUM_THREADS;i++){//唤醒所有未运行就被终止的线程
        sem_post(&(con[i].control));
    }
    for(i=0;i<NUM_THREADS;i++){//等待线程终止
        pthread_join(con[i].thread,NULL);
    }
    printf("SJF average wait time:%lf\n\n",average_wait_time(con));
    printf("============================================================================\n\n");

    //Priority
    printf("Priority\n");
    for(i=0;i<NUM_THREADS;i++){//复原管理链队列
        con[i].id=standand[i].id;
        con[i].arrive=standand[i].arrive;
        con[i].wct=standand[i].wct;
        con[i].burst=standand[i].burst;
        con[i].priority=standand[i].priority;
        con[i].state=1;
        sem_destroy(&(con[i].control));
        sem_init(&(con[i].control), 0, 0);//初始化调度信号量
    }
    for(i=0;i<NUM_THREADS;i++){//创建多线程
        pthread_create(&(con[i].thread),NULL,&run,(void*)&con[i]);
    }
    sleep(1);

    for(i=0;i<NUM_THREADS-1;i++){//将所有线程按到达时间排序
        int j;
        for(j=1;j<NUM_THREADS-i;j++){
            if(con[j-1].arrive>con[j].arrive){
                controler t=con[j-1];
                con[j-1]=con[j];
                con[j]=t;
            }
        }
    }

    now=0;
    first=0;//当前最早到达的未运行且在截至时间前能完成的线程
    while(first<NUM_THREADS){//若还有调度状态为就绪且在截至时间前能完成的线程就继续调度
        int arrive=con[first].arrive;//本次调度线程的到达时间
        int select=first;//本次要调度的线程
        if(now<con[first].arrive)now=con[first].arrive;//更新当前时间保证有线程就绪

        for(i=first;i<NUM_THREADS;i++){//寻找调度状态为就绪且在截至时间前能完成的已到达线程中优先级最高的线程
            if(con[i].state==1&&con[i].wct<now+con[i].burst&&con[i].arrive<=now){//终止在截至时间之前不能完成的已到达线程
                con[i].state=2;
                if(con[i].arrive<now)con[i].wait=now-con[i].arrive;
                else con[i].wait=0;
            }
            else if(con[i].state==1&&con[i].priority>con[select].priority&&con[i].arrive<=now&&con[i].wct>=now+con[i].burst){
                arrive=con[i].arrive;
                select=i;
            }
        }

        //计算此线程的等待时间
        if(now==arrive){
            con[select].wait=0;
        }
        else{
            con[select].wait=now-arrive;
        }
        
        printf("now is %d\n",now);
        sem_post(&(con[select].control));//启动选中的线程
        usleep(100);
        sem_wait(&(con[select].control));//等待此线程运行结束
        
        now+=con[select].burst;//更新当前时间

        for(;first<NUM_THREADS;first++){//寻找当前最早到达的就绪线程
            if(con[first].state==1)
                break;
        }
    }

    for(i=0;i<NUM_THREADS;i++){//唤醒所有未运行就被终止的线程
        sem_post(&(con[i].control));
    }

    for(i=0;i<NUM_THREADS;i++){//等待线程终止
        pthread_join(con[i].thread,NULL);
    }
    printf("Priority average wait time:%lf\n\n",average_wait_time(con));
    
    //摧毁互斥信号量
    for(i=0;i<NUM_THREADS;i++){
        sem_destroy(&(con[i].control));
        sem_destroy(&(standand[i].control));
    }
    return 0;
}
void *run(void *arg){
    controler* con=(controler*)arg;
    sem_wait(&(con->control));

    if(con->state==1){//因为截止时间之前无法完成而被终止的线程直接退出
        con->state=0;//线程开始运行
        printf("-----------------------------------------------------\n");
        printf("thread-%d starts!\n",con->id);
        printf("tid of thread-%d :%lx\n",con->id,pthread_self());
        printf("arrive time of thread-%d :%d\n",con->id,con->arrive);
        printf("wct of thread-%d :%d\n",con->id,con->wct);
        printf("cpu burst time of thread-%d :%d\n",con->id,con->burst);
        printf("priority of thread-%d :%d\n",con->id,con->priority);
        printf("wait time of thread-%d :%d\n",con->id,con->wait);
        printf("thread-%d exits!\n",con->id);
        printf("-----------------------------------------------------\n");
        con->state=2;//线程终止
    }
    
    sem_post(&(con->control));
}
double average_wait_time(controler* con){
    int sum=0;
    int i;
    for(i=0;i<NUM_THREADS;i++)
        sum+=con[i].wait;
    return sum*1.0/NUM_THREADS;
}
```
## 运行结果分析
![](1.png)

![](2.png)

![](3.png)

![](4.png)

![](5.png)

![](6.png)

![](7.png)

![](8.png)

![](9.png)

![](10.png)

![](11.png)

+ 由以上运行截图可见：
    + FCFS：非抢占式，先到达的线程先运行，同时到达的线程编号小的先运行，任务平均等待时间为240.8；
    + SJF：非抢占式，已到达的线程中，任务执行时间最短的先运行，任务执行时间相同的先到达的先运行，若这两个参数都相同就编号小的先运行，任务平均等待时间为180.2；
    + Priority:非抢占式，已到达的线程中，优先级最大的先运行，优先级相同的先到达的先运行，若这两个参数都相同就编号小的先运行，任务平均等待时间为230.55；
    + 所有线程执行任务时到已到达，即执行任务的时间大于等于到达时间，实验结果正确。

注：每次运行程序时三种调度算法使用的管理链队列初始状态都是相同的。但由于管理链队列结点的arrive、wct、burst、priority四个参数通过随机数产生，且每次运行程序都会调用srand函数重设随机数种子，故每次程序运行结果可能不同。