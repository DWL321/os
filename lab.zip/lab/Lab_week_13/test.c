#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include "threadpool.h"

int done = 0;
pthread_mutex_t lock;

void run(void *arg){
    int* num=(int*)arg;
    int n=*num;
    int i;
    int result=0;
    for(i=1;i<=n;i++){
        result+=i*i;
    }
    pthread_mutex_lock(&lock);
    done++;
    printf("n=%d,result=%d,%d tasks have done\n",n,result,done);
    pthread_mutex_unlock(&lock);
}

int main()
{
    printf("请输入线程数量：");
    int thread_count;
    scanf("%d",&thread_count);
    printf("请输入任务队列里最多任务数：");
    int queue_size;
    scanf("%d",&queue_size);
    printf("请输入向量的最大维数：");
    int n;
    scanf("%d",&n);
    printf("使用线程数为%d任务队列最大长度为%d的线程池计算从1维到%d维的向量乘以它的转置\n",thread_count,queue_size,n);
    printf("注：第n维的向量为[1,2,3,...,n]\n");

    pthread_mutex_init(&lock, NULL);//初始化互斥锁
    threadpool* pool=threadpool_create(thread_count,queue_size);//创建线程池
    if(pool==0){
        printf("线程池创建失败\n");
        return 0;
    }
    int task[n+1];//防止线程获得向量阶数的时候出现冲突
    int i;
    for(i=1;i<=n;i++){
        task[i]=i;
    }
    i=1;
    while(i<=n){//将所有任务添加到任务队列里
        while(pool->shutdown==0&&threadpool_add(pool,&run,&task[i])!=0){//如果添加失败就等1秒，直到成功添加第i个任务
            sleep(1);
        }
        i++;
    }
    while(done<n){//等待所有任务完成
        sleep(5);
    }
    sleep(1);
    printf("All tasks have done!\n");
    if(threadpool_destroy(pool)!=0){//销毁线程池
        printf("线程池摧毁失败\n");
    }
    return 0;
}