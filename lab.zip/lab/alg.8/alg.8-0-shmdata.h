#define TEXT_SIZE 4*1024  /* = PAGE_SIZE, size of each message */
#define TEXT_NUM 1      /* maximal number of mesages */
    /* total size can not exceed current shmmax,
       or an 'invalid argument' error occurs when shmget */
#define ID_LEN 9 //定义id数字位数
#define MAX_NAME_LEN 11 //定义名字的最大长度
#define MAX_STUDENT_NUM 6//定义学生队列容量实际上只能存5个，有一个空位是留出来判断队列是否存满的
typedef struct Student{
        char id[ID_LEN];//注意id要以非0数字开头
        char name[MAX_NAME_LEN];
}student;
struct shared_struct {
    int written;//输入完成，可以开始读共享内存了
    int head;//队列头
    int tail;//队列尾
    student students[MAX_STUDENT_NUM];//学生队列
};

#define PERM S_IRUSR|S_IWUSR|IPC_CREAT

#define ERR_EXIT(m) \
    do { \
        perror(m); \
        exit(EXIT_FAILURE); \
    } while(0)
