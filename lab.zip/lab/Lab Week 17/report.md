# Lab Week 17 实验报告
## 实验内容:虚拟存储管理
编写一个 C 程序模拟实现课件 Lecture24 中的请求页面置换算法，包括 FIFO 、 LRU (stack and matrix implementation) 、 Second chance ,并设计输入用例验证结果。
## 实验原理
+ 页面置换
    + 缺页中断：在地址映射过程中，若在页表中发现所要访问的页面不在内存，则产生中断，当发生中断时，系统必须在内存选择一个页面移出内存，以便为调入新的页面让出空间。
    + 缺页率的计算：假设一个进程的逻辑空间为n页，系统为其分配的物理块数为m，如果在进程运行的过程当中，访问页面成功（即所访问的页面在内存中）的次数为S，访问页面失败（即所访问的页面不在内存中）的次数为F，则该进程的页面缺失率 f=F/(F+S)
    + 页面置换算法是选择换出页面的算法，直接影响系统的性能。
+ FIFO
    + 算法原理：优先淘汰最早进入内存的页面，亦即在内存中驻留时间最久的页面。该算法实现简单，但该算法与进程实际运行时的规律不适应，因为在进程中，有的页面经常被访问。FIFO算法还会产生当所分配的物理块数增大而缺页数不减反增的异常现象，这是由 Belady于1969年发现，故称为Belady异常，如图3-28所示。只有FIFO算法可能出现Belady 异常，而LRU和OPT算法永远不会出现Belady异常。 
    + 设计思路：使用一个循环队列存储调入内存的页面，每次调用页面就扫描循环队列，如果队列里没有就加到队列尾，如果队列已满就把队列首的page换出。
+ LRU
    + 算法原理：选择最近最长时间未访问过的页面予以淘汰，它认为过去一段时间内未访问过的页面，在最近的将来可能也不会被访问。
    + stack implementation
        + 设计思路：用一个特殊的栈来保存当前正在使用的各个页面的页面号。当一个新的进程访问某页面时，便将该页面号压入栈顶，其他的页面号往栈底移，如果栈已满，则将栈底的页面号移除。这样，栈顶始终是最新被访问的页面的编号，而栈底则是最近最久未访问的页面的页面号。
    + matrix implementation
        + 设计思路：使用一个矩阵来记录页面的使用频率和时间。设矩阵为n×n维，n是frame的数量。在一开始矩阵的初值为0。每次一个页面被访问时，例如第k个虚拟页面被访问时，先将第k行的值全部设置为1，再将第k列的值全部设置为0。在每次需要换出一个页面时，选择矩阵里对应行值最小的页面更换即可。此处的行值是指把该行所有的0和1连起来看做一个二进制数时的取值。寻找对应行值最小的页面的方法是从左到右扫描矩阵每列，1对应的页面之后不再扫描，直到剩下1个页面为止，这个页面行值最小。
+ Second chance
    + 算法原理：给每一个访问的页面关联一个附加位(reference bit)，有些地方也叫做使用位(use bit)，当某一页装入主存时，将use bit置成1；如果该页之后又被访问到，使用位也还是标记成1。对于页面置换算法，候选的帧集合可以看成是一个循环缓冲区，并且有一个指针和缓冲区相关联。遇到页面替换时，指针指向缓冲区的下一帧。如果这页进入主存后发现没有空余的帧(frame)，即所有页面的使用位均为1，那么这时候从指针开始循环一个缓冲区，将之前的使用位都清0，并且留在最初的位置上，换出该桢对应的页。
    + 设计思路：使用一个循环队列存储调入内存的页面，每次调用页面就扫描循环队列，如果这页命中就把这页的使用位置为1；如果这页缺失且队列未满，就把这页放到队尾且使用位置为1；若队列已满就从队首开始扫描，遇到使用位为1的就置0，遇到使用位为0的就把这页换出把要调用的页放到这个位置，然后将这个位置设为队尾，下一个位置设为队首。
## 程序实现
+ 总体设计思路：每个算法具体的设计思路已经在实验原理中说明。首先输入frame的数量和reference string的长度，然后输入1选择手动输入reference string，或输入2使用随机数函数生成reference string中的每次调用的page，使用三种请求页面置换算法在frame数量相同的情况下处理相同的reference string，输出每种算法的page faults。若使用随即生成，由于每次生成reference string前都会用srand函数重设随机数种子，测试样例有很强的随机性，每次随机测试结果可能略有不同。
+ 代码具体实现
    ```
    #include <stdio.h>
    #include <stdlib.h>
    #include <time.h>

    int* use;//page的reference string
    int num_test;//调用次数
    int num_frame;//frame的数量

    void init();//初始化参数并随机生成测试样例
    int FIFO();//FIFO请求页面置换算法，返回page faults
    int LRU_stack();//LRU(stack implementation)请求页面置换算法，返回page faults
    int LRU_matrix();//LRU(matrix implementation)请求页面置换算法，返回page faults
    int Second_chance(); //Second chance请求页面置换算法，返回page faults

    int main()
    {
        init();
        printf("FIFO:%d page faults\n",FIFO());
        printf("LRU(stack implementation):%d page faults\n",LRU_stack());
        printf("LRU(matrix implementation):%d page faults\n",LRU_matrix());
        printf("Second chance:%d page faults\n",Second_chance());
        free(use);
        return 0;
    }
    void init(){
        printf("input the number of frames:");
        scanf("%d",&num_frame);
        printf("input the length of reference string:");
        scanf("%d",&num_test);
        use=(int*)malloc(sizeof(int)*num_test);
        int cho;
        printf("1.input reference string    2.randomly set the reference string:");
        scanf("%d",&cho);
        if(cho==1){
            printf("input reference string:");
            int i;
            for(i=0;i<num_test;i++){
                scanf("%d",&use[i]);
            }
        }
        else{
            srand(time(0));
            printf("randomly set the reference string:");
            int i;
            for(i=0;i<num_test;i++){//每次调用的page是随机选择的
                use[i]=rand()%(num_test*2-num_test/2);
                printf("%d ",use[i]);
            }
            printf("\n");    
        }
    }
    int FIFO(){
        printf("----------------------------------------------------\n");
        int phy_mem[num_frame+1];//采用有一个空位的循环队列，当head=tail时队列为空，当head=(tail+1)%(num_frame+1)时队列为满
        int head=0;
        int tail=0;
        int miss=0;
        int i;
        for(i=0;i<num_test;i++){
            int hit=0;
            if(head!=tail){//若循环队列不为空
                int j;
                for(j=head;j!=tail;j=(j+1)%(num_frame+1)){//扫描循环队列
                    if(phy_mem[j]==use[i]){
                        hit=1;
                        printf("hit page%d\n",use[i]);
                        break;
                    }
                }
            }
            if(hit)continue;//如果这页命中就处理下一页
            miss++;
            if(head!=(tail+1)%(num_frame+1)){//缺失但队列未满，则直接调入
                printf("miss page%d,take in page%d\n",use[i],use[i]);
                phy_mem[tail]=use[i];
                tail=(tail+1)%(num_frame+1);
            }
            else{//缺失但队列已满，则调出队首的page，再把这个page调入队尾
                printf("miss page%d,take out page%d,take in page%d\n",use[i],phy_mem[head],use[i]);
                head=(head+1)%(num_frame+1);
                phy_mem[tail]=use[i];
                tail=(tail+1)%(num_frame+1);
            }
        }
        return miss;
    }
    int LRU_stack(){
        printf("----------------------------------------------------\n");
        int stack[num_frame];
        int top=-1;
        int miss=0;
        int i;
        for(i=0;i<num_test;i++){
            int hit=0;
            if(top>=0){//若栈不为空
                int j;
                for(j=0;j<=top;j++){//扫描循环队列
                    if(stack[j]==use[i]){
                        hit=1;
                        printf("hit page%d\n",use[i]);
                        break;
                    }
                }
                if(j<=top){//若命中将该页面号压入栈顶，其他的页面号往栈底移
                    while(j<top){
                        stack[j]=stack[j+1];
                        j++;
                    }
                    stack[top]=use[i];
                }
            }
            if(hit)continue;//如果这页命中就处理下一页
            miss++;
            if(top<num_frame-1){//缺失但栈未满，则直接调入栈顶
                printf("miss page%d,take in page%d\n",use[i],use[i]);
                top++;
                stack[top]=use[i];
            }
            else{//缺失但栈已满，则调出栈底的page,其他的页面号往栈底移，再把这个page调入栈顶
                printf("miss page%d,take out page%d,take in page%d\n",use[i],stack[0],use[i]);
                int j=0;
                while(j<top){
                    stack[j]=stack[j+1];
                    j++;
                }
                stack[top]=use[i];
            }
        }
        return miss;    
    }
    int LRU_matrix(){
        printf("----------------------------------------------------\n");
        int matrix[num_frame][num_frame];
        int frames[num_frame];//记录矩阵各行对应的页号
        int num=0;//目前内存中已有的页数
        int miss=0;
        int i;
        for(i=0;i<num_frame;i++){//矩阵的初值为0
            int j;
            for(j=0;j<num_frame;j++){
                matrix[i][j]=0;
            }
        }
        for(i=0;i<num_test;i++){
            int hit=0;
            if(num>0){//若矩阵不为空
                int j;
                for(j=0;j<num;j++){//扫描循环队列
                    if(frames[j]==use[i]){
                        hit=1;
                        printf("hit page%d\n",use[i]);
                        break;
                    }
                }
                if(hit){//若命中将该页面号压入栈顶，其他的页面号往栈底移
                    int k;
                    for(k=0;k<num_frame;k++){
                        matrix[j][k]=1;
                        matrix[k][j]=0;
                    }
                    matrix[j][j]=0;
                }
            }
            if(hit)continue;//如果这页命中就处理下一页
            miss++;
            if(num<num_frame){//缺失但矩阵未满，则直接调入矩阵
                printf("miss page%d,take in page%d\n",use[i],use[i]);
                frames[num]=use[i];
                num++;
                int k;
                for(k=0;k<num_frame;k++){
                    matrix[num-1][k]=1;
                    matrix[k][num-1]=0;
                }
                matrix[num-1][num-1]=0;
            }
            else{//缺失但栈已满，则选择矩阵里对应行值最小的页面更换
                int j;
                int tag[num_frame];//继续参与比较行值的对应行号置1，已确定不是最小行值的置0
                for(j=0;j<num_frame;j++){
                    tag[j]=1;
                }
                int k;
                int rest=num_frame;//未确定是否是最小行值的行数
                for(k=0;k<num_frame;k++){
                    int w;
                    for(w=0;w<num_frame;w++){
                        if(rest==1)break;
                        if(tag[w]){
                            if(matrix[w][k]){
                                rest--;
                                tag[w]=0;
                            }
                        }
                    }
                }
                for(k=0;k<num_frame;k++){
                    if(tag[k]){
                        j=k;
                        break;
                    }
                }
                printf("miss page%d,take out page%d,take in page%d\n",use[i],frames[j],use[i]);
                frames[j]=use[i];
                for(k=0;k<num_frame;k++){
                    matrix[j][k]=1;
                    matrix[k][j]=0;
                }
                matrix[j][j]=0;
            }
        }
        return miss; 
    }
    int Second_chance(){
        printf("----------------------------------------------------\n");
        int phy_mem[num_frame];
        int use_bit[num_frame];
        int head=0;
        int tail=-1;
        int size=0;
        int miss=0;
        int i;
        for(i=0;i<num_frame;i++)use_bit[i]=0;
        for(i=0;i<num_test;i++){
            int hit=0;
            if(size){//若循环队列不为空
                int j;
                for(j=head;1;j=(j+1)%(num_frame)){//扫描循环队列
                    if(phy_mem[j]==use[i]){
                        use_bit[j]=1;//将使用位置1
                        hit=1;
                        printf("hit page%d\n",use[i]);
                        break;
                    }
                    if(j==tail)break;
                }
            }
            if(hit)continue;//如果这页命中就处理下一页
            miss++;
            if(size<num_frame){//缺失但队列未满，则直接调入
                printf("miss page%d,take in page%d\n",use[i],use[i]);
                tail=(tail+1)%(num_frame);
                phy_mem[tail]=use[i];
                use_bit[tail]=1;
                size++;
            }
            else{//缺失但队列已满
                //从队首开始扫描，遇到使用位为1的就置0，遇到使用位为0的就把这页换出把要调用的页放到这个位置
                //然后将这个位置设为队尾，下一个位置设为队首
                int j;
                for(j=head;1;j=(j+1)%(num_frame)){
                    if(use_bit[j])use_bit[j]=0;
                    else{
                        printf("miss page%d,take out page%d,take in page%d\n",use[i],phy_mem[j],use[i]);
                        phy_mem[j]=use[i];
                        use_bit[j]=1;
                        head=(j+1)%num_frame;
                        tail=j;
                        break;
                    }
                }
            }
        }
        return miss;
    }
    ```
## 运行结果分析
![](1.png)

![](2.png)

一共有5个frame，reference string为17 8 28 29 9 10 27 14 4 9 16 4 24 24 7 9 13 13 4 11。FIFO有16个page faults,LRU(stack implementation)有14个page faults，LRU(matrix implementation)有14个page faults，Second chance有16个page faults，具体置换过程程序输出表述详细，运行结果正确。