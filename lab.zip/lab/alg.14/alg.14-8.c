#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sched.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#define gettid() syscall(__NR_gettid)
  /* wrap the system call syscall(__NR_gettid), __NR_gettid = 224 */
#define gettidv2() syscall(SYS_gettid) /* a traditional wrapper */

#define STACK_SIZE 1024*1024 /* 1Mib. question: what is the upperbound of STACK_SIZE */

#define ERR_EXIT(m) \
    do { \
        perror(m); \
        exit(EXIT_FAILURE); \
    } while(0)

static int CLONE_PARENT_func(void *arg) {
    printf("I am CLONE_PARENT_func, my tid = %ld, pid = %d, ppid = %d\n", gettid(), getpid(), getppid());
    
    return 0;
}

static int CLONE_VM_func(void *arg) {
    char *chdbuf = (char*)arg;
    printf("CLONE_VM_func read buf: %s\n", chdbuf);
    sleep(1);
    sprintf(chdbuf, "I am CLONE_VM_func, my tid = %ld, pid = %d", gettid(), getpid());
    printf("CLONE_VM_func set buf: %s\n", chdbuf);
    sleep(1);
    printf("CLONE_VM_func sleeping and then exists ...\n");
    sleep(1);

    return 0;
}

static int CLONE_VFORK_func(void *arg) {
    sleep(1);
    printf("I am CLONE_VFORK_func, my tid = %ld, pid = %d\n", gettid(), getpid());
    printf("CLONE_VFORK_func exists ...\n");

    return 0;
}

static int CLONE_FILES_func(void *arg) {
    int *numptr = (int *)arg;
    int fd = *numptr;
    
    fcntl(fd, F_SETFD, 1);
    printf("I am CLONE_FILES_func, my tid = %ld, pid = %d, ppid = %d\n", gettid(), getpid(), getppid());
    printf("CLONE_FILES_func sets the FD_COLEXEC of fd to %d\n", fcntl(fd, F_GETFD));
    
    return 0;
}

void handler(int signo) {
    printf("\nsignal catched: signo = %d,my pid = %d, ppid = %d\n", signo, getpid(), getppid());
    return;
}

static int CLONE_SIGHAND_func(void *arg) {
    printf("I am CLONE_SIGHAND_func, my tid = %ld, pid = %d, ppid = %d\n", gettid(), getpid(), getppid());
    printf("CLONE_SIGHAND_func sleeps and waits signo \n\n");
    printf("now start catching Ctrl+c\n");
    sleep(100);
    return 0;
}

static int CLONE_NEWIPC_func(void *arg) {
    printf("Message Queues in CLONE_NEWIPC_func:\n");
    system("ipcs -q");
    
    return 0;
}

static int CLONE_THREAD_func(void *arg) {
    printf("I am CLONE_THREADs_func, my tid = %ld, pid = %d, ppid = %d\n", gettid(), getpid(), getppid());

    return 0;
}

int main(int argc,char **argv)
{
    // clone的子进程所用到的系统栈区
    char *stack_CLONE_PARENT = malloc(STACK_SIZE*sizeof(char));
    char *stack_CLONE_VM = malloc(STACK_SIZE*sizeof(char));
    char *stack_CLONE_VFORK = malloc(STACK_SIZE*sizeof(char));
    char *stack_CLONE_FILES = malloc(STACK_SIZE*sizeof(char));
    char *stack_CLONE_SIGHAND = malloc(STACK_SIZE*sizeof(char));
    char *stack_CLONE_NEWIPC = malloc(STACK_SIZE*sizeof(char));
    char *stack_CLONE_THREAD = malloc(STACK_SIZE*sizeof(char));

    pid_t chdtid_CLONE_PARENT, chdtid_CLONE_VM, chdtid_CLONE_VFORK, 
            chdtid_CLONE_FILES, chdtid_CLONE_SIGHAND, chdtid_CLONE_NEWIPC, chdtid_CLONE_THREAD;

    int ret;
    unsigned long flags = 0;
    int status = 0;
    char buf[100];

    if(!stack_CLONE_PARENT || !stack_CLONE_VFORK || !stack_CLONE_VFORK ||
            !stack_CLONE_FILES || !stack_CLONE_SIGHAND || !stack_CLONE_NEWIPC || 
                !stack_CLONE_THREAD) {
        perror("malloc()");
        exit(1);
    }

    // 测试参数CLONE_PARENT
    printf("==================================================================\n");
    // 设置参数CLONE_PARENT前
    printf("Before set flags to CLONE_PARENT\n");
    flags = 0;
    chdtid_CLONE_PARENT = clone(CLONE_PARENT_func, stack_CLONE_PARENT + STACK_SIZE, flags | SIGCHLD, NULL);
    if(chdtid_CLONE_PARENT == -1) {
        perror("CLONE_PARENT before:clone()");
        exit(1);
    }
    printf("I am main, my pid = %d, my ppid = %d\n", getpid(), getppid());
    sleep(1);
    printf("\n");

    // 设置参数CLONE_PARENT后
    printf("After set flags to CLONE_PARENT\n");
    flags |= CLONE_PARENT;
    chdtid_CLONE_PARENT = clone(CLONE_PARENT_func, stack_CLONE_PARENT + STACK_SIZE, flags | SIGCHLD, NULL);
    if(chdtid_CLONE_PARENT == -1) {
        perror("CLONE_PARENT aftere:clone()");
        exit(1);
    }
    printf("I am main, my pid = %d, my ppid = %d\n", getpid(), getppid());
    sleep(1);
    printf("==================================================================\n\n");

    // 测试参数CLONE_VM
    printf("==================================================================\n");
    // 设置参数CLONE_VM后
    printf("Before set flags to CLONE_VM\n");
    flags = 0;
    sprintf(buf,"I am parent, my pid = %d", getpid());
    printf("parent set buf: %s\n", buf);
    sleep(1);
    printf("parent clone ...\n");
    chdtid_CLONE_VM = clone(CLONE_VM_func, stack_CLONE_VM + STACK_SIZE, flags | SIGCHLD, buf);
    if(chdtid_CLONE_VM == -1) {
        perror("CLONE_VM before:clone()");
        exit(1);
    }
    waitpid(chdtid_CLONE_VM, &status, 0);
    printf("parent read buf: %s\n", buf);
    printf("\n");

    // 设置参数CLONE_VM后
    printf("After set flags to CLONE_VM\n");
    flags |= CLONE_VM;
    sprintf(buf,"I am parent, my pid = %d", getpid());
    printf("parent set buf: %s\n", buf);
    sleep(1);
    printf("parent clone ...\n");
    chdtid_CLONE_VM = clone(CLONE_VM_func, stack_CLONE_VM + STACK_SIZE, flags | SIGCHLD, buf);
    if(chdtid_CLONE_VM == -1) {
        perror("CLONE_VM after:clone()");
        exit(1);
    }
    waitpid(chdtid_CLONE_VM, &status, 0);
    printf("parent read buf: %s\n", buf);
    printf("==================================================================\n\n");

    // 测试参数CLONE_VFORK
    printf("==================================================================\n");
    //设置参数CLONE_VFORK前
    printf("Before set flags to CLONE_VFORK\n");
    flags = 0;
    chdtid_CLONE_VFORK = clone(CLONE_VFORK_func, stack_CLONE_VFORK + STACK_SIZE, flags | SIGCHLD, buf);
    if(chdtid_CLONE_VFORK == -1) {
        perror("CLONE_VFORK before:clone()");
        exit(1);
    }
    printf("I am parent, my pid = %d\n", getpid());
    waitpid(chdtid_CLONE_VFORK, &status, 0);
    printf("\n");

    //设置参数CLONE_VFORK后
    printf("After set flags to CLONE_VFORK\n");
    flags |= CLONE_VFORK;
    chdtid_CLONE_VFORK = clone(CLONE_VFORK_func, stack_CLONE_VFORK + STACK_SIZE, flags | SIGCHLD, buf);
    if(chdtid_CLONE_VFORK == -1) {
        perror("CLONE_VFORK aftere:clone()");
        exit(1);
    }
    printf("I am parent, my pid = %d\n", getpid());
    waitpid(chdtid_CLONE_VFORK, &status, 0);
    printf("==================================================================\n\n");

    // 测试参数CLONE_FILES
    printf("==================================================================\n");
    //设置参数CLONE_FILES前
    printf("Before set flags to CLONE_FILES\n");
    flags = 0;
    int fd = open("./b.txt", O_RDWR | O_CREAT, 0666);
    fcntl(fd, F_SETFD, 0);
    printf("I am parent, my pid = %d, my ppid = %d\n", getpid(), getppid());
    printf("In the beginning, parent sets the FD_COLEXEC of fd to %d\n\n", fcntl(fd, F_GETFD));

    chdtid_CLONE_FILES = clone(CLONE_FILES_func, stack_CLONE_FILES + STACK_SIZE, flags | SIGCHLD, &fd);
    if(chdtid_CLONE_FILES == -1) {
        perror("CLONE_FILES before:clone()");

        exit(1);
    }

    waitpid(chdtid_CLONE_FILES, &status, 0);
    printf("\nIn the last, the FD_COLEXEC of fd in parent is %d\n\n\n", fcntl(fd, F_GETFD));

    //设置参数CLONE_FILES后
    printf("After set flags to CLONE_FILES\n");
    flags |= CLONE_FILES;
    printf("I am parent, my pid = %d, my ppid = %d\n", getpid(), getppid());
    printf("In the beginning,parent sets the FD_COLEXEC of fd to %d\n\n", fcntl(fd, F_GETFD));

    chdtid_CLONE_FILES = clone(CLONE_FILES_func, stack_CLONE_FILES + STACK_SIZE, flags | SIGCHLD, &fd);
    if(chdtid_CLONE_FILES == -1) {
        perror("CLONE_FILES after:clone()");
        exit(1);
    }

    waitpid(chdtid_CLONE_FILES, &status, 0);
    printf("\nIn the last, the FD_COLEXEC of fd in parent is %d\n", fcntl(fd, F_GETFD));
    printf("==================================================================\n\n");
    
    // 测试参数CLONE_SIGHAND
    printf("==================================================================\n");
    struct sigaction newact;
    newact.sa_sigaction = &handler; /* set the user handler */
    sigemptyset(&newact.sa_mask); /* clear the mask */
    sigaddset(&newact.sa_mask, SIGINT); /* sa_mask, set signo=3 (SIGQUIT:Ctrl+C) */
    newact.sa_flags = 0; /* default */

    //设置参数CLONE_SIGHAND前
    printf("Before set flags to CLONE_SIGHAND\n");
    flags = 0;

    printf("I am parent, my pid = %d, my ppid = %d\n", getpid(), getppid());
    printf("parent waits signo\n\n");
    chdtid_CLONE_SIGHAND = clone(CLONE_SIGHAND_func, stack_CLONE_SIGHAND + STACK_SIZE, flags | CLONE_VM | SIGCHLD, NULL);

    sigaction(SIGINT, &newact, NULL);

    wait(0);
    sleep(100);

    sleep(1);
    printf("chdtid_CLONE_SIGHAND terminated\n");

    //设置参数CLONE_SIGHAND后
    printf("After set flags to CLONE_SIGHAND\n");
    flags |= CLONE_SIGHAND;

    printf("I am parent, my pid = %d, my ppid = %d\n", getpid(), getppid());
    printf("parent waits signo\n\n");
    chdtid_CLONE_SIGHAND = clone(CLONE_SIGHAND_func, stack_CLONE_SIGHAND + STACK_SIZE, flags | CLONE_VM | SIGCHLD, NULL);

    sigaction(SIGINT, &newact, NULL);

    wait(0);
    sleep(100);

    sleep(1);
    printf("chdtid_CLONE_SIGHAND terminated\n");
    printf("==================================================================\n\n");

    // 测试参数CLONE_NEWIPC
    printf("==================================================================\n");
    printf("First create a message queue in parent\n\n");
    char pathname[10] = {"./c"};
    struct stat fileattr;
    key_t key;
    int msqid;
    if(stat(pathname, &fileattr) == -1) {
        ret = creat(pathname, O_RDWR);
        if (ret == -1) {
            ERR_EXIT("CLONE_NEWIPC:creat()");
        }
        printf("shared file object created\n");
    }
    
    key = ftok(pathname, 0x27);
    if(key < 0) {
        ERR_EXIT("ftok()");
    }
    
    msqid = msgget((key_t)key, 0666 | IPC_CREAT);
    if(msqid == -1) {
        ERR_EXIT("msgget()");
    }

    //设置参数CLONE_NEWIPC前
    printf("Before set flags to CLONE_NEWIPC\n");
    flags = 0;
    printf("Command: ipcs -q\n\n");
    printf("Message Queues in parent:\n");
    system("ipcs -q");
    chdtid_CLONE_NEWIPC = clone(CLONE_NEWIPC_func, stack_CLONE_NEWIPC + STACK_SIZE, flags | SIGCHLD, NULL);
    if(chdtid_CLONE_NEWIPC == -1) {
        perror("CLONE_NEWIPC before:clone()");
        exit(1);
    }
    wait(0);
    printf("\n");

    //设置参数CLONE_NEWIPC后
    printf("After set flags to CLONE_NEWIPC\n");
    flags |= CLONE_NEWIPC;
    printf("Command: ipcs -q\n\n");
    printf("Message Queues in parent:\n");
    system("ipcs -q");
    chdtid_CLONE_NEWIPC = clone(CLONE_NEWIPC_func, stack_CLONE_NEWIPC + STACK_SIZE, flags | SIGCHLD, NULL);
    if(chdtid_CLONE_NEWIPC == -1) {
        perror("CLONE_NEWIPC after:clone()");
        exit(1);
    }
    wait(0);
    
    sleep(5);
    sprintf(buf, "ipcrm -q %d",msqid);
    printf("Command: %s\n", buf);
    system(buf);
    system("ipcs -q");
    printf("==================================================================\n\n");

    // 测试参数CLONE_THREAD
    printf("==================================================================\n");
    printf("Before set flags to CLONE_THREAD\n");
    flags = 0;
    //设置参数CLONE_THREAD前
    chdtid_CLONE_THREAD = clone(CLONE_THREAD_func, stack_CLONE_THREAD + STACK_SIZE, flags | CLONE_VM | CLONE_SIGHAND | SIGCHLD, NULL);
    if(chdtid_CLONE_THREAD == -1) {
        perror("CLONE_THREAD before:clone()");
        exit(1);
    }
    printf("I am parent, my pid = %d, my ppid = %d\n", getpid(), getppid());
    sleep(1);
    printf("\n");
    //设置参数CLONE_THREAD后
    printf("After set flags to CLONE_THREAD\n");
    flags |= CLONE_THREAD;
    chdtid_CLONE_THREAD = clone(CLONE_THREAD_func, stack_CLONE_THREAD + STACK_SIZE, flags | CLONE_VM | CLONE_SIGHAND | SIGCHLD, NULL);
    if(chdtid_CLONE_THREAD == -1) {
        perror("CLONE_THREAD after:clone()");
        exit(1);
    }
    printf("I am parent, my pid = %d, my ppid = %d\n", getpid(), getppid());
    sleep(1);
    printf("==================================================================\n\n");

    free(stack_CLONE_PARENT);
    free(stack_CLONE_VM);
    free(stack_CLONE_VFORK);
    free(stack_CLONE_FILES);
    free(stack_CLONE_SIGHAND);
    free(stack_CLONE_NEWIPC);
    free(stack_CLONE_THREAD);

    stack_CLONE_PARENT = NULL;
    stack_CLONE_VM = NULL;
    stack_CLONE_VFORK = NULL;
    stack_CLONE_FILES = NULL;
    stack_CLONE_SIGHAND = NULL;
    stack_CLONE_NEWIPC = NULL;
    stack_CLONE_THREAD = NULL;

    return 0;
}

