#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int* numbers;//磁盘访问序列
int start;//磁头起始位置
int length;//磁盘访问序列长度

void init();//初始化参数
//分别执行六种硬盘柱面访问调度算法，输出每种算法的磁头服务序列并返回磁头移动平均距离
double FCFS();
double SSTF();
double SCAN();
double C_SCAN(); 
double LOOK();
double C_LOOK();

int main()
{
    init();
    printf("FCFS 磁头移动平均距离:%lf\n",FCFS());
    printf("SSTF 磁头移动平均距离:%lf\n",SSTF());
    printf("SCAN 磁头移动平均距离:%lf\n",SCAN());
    printf("C_SCAN 磁头移动平均距离:%lf\n",C_SCAN());
    printf("LOOK 磁头移动平均距离:%lf\n",LOOK());
    printf("C_LOOK 磁头移动平均距离:%lf\n",C_LOOK());
    free(numbers);
    return 0;
}
void init(){
    printf("输入磁盘访问序列长度:");
    scanf("%d",&length);
    numbers=(int*)malloc(sizeof(int)*length);
    printf("输入磁盘访问序列(0～199):");
    int i;
    for(i=0;i<length;i++){
        scanf("%d",&numbers[i]);
    }
    printf("输入磁头起始位置:");
    scanf("%d",&start);
}
double FCFS(){
    printf("----------------------------------------------------\n");
    printf("FCFS 磁头服务序列：\n");
    //先来先服务
    int i;
    int sum=0;
    int pre=start;
    for(i=0;i<length;i++){
        if(numbers[i]>pre)sum+=numbers[i]-pre;
        else sum+=pre-numbers[i];
        pre=numbers[i];
        printf("%d ",numbers[i]);
    }
    printf("\n");
    return sum*1.0/length;
}
double SSTF(){
    printf("----------------------------------------------------\n");
    printf("SSTF 磁头服务序列：\n");
    int num1[length];
    int num2[length];
    int i;
    for(i=0;i<length;i++){
        num1[i]=numbers[i];
    }
    //将磁头访问序列按磁道号从小到大排序
    for(i=1;i<length-1;i++){
        int j;
        for(j=0;j<length-i;j++){
            if(num1[j]>num1[j+1]){
                int t=num1[j];
                num1[j]=num1[j+1];
                num1[j+1]=t;
            }
        }
    }
    for(i=0;i<length;i++){
        num2[i]=num1[i];
    }
    //最短寻道时间优先
    int sum=0;
    int pre=start;
    for(i=0;i<length;i++){
        if(num1[i]>=start)break;
    }
    if(i==0||(i<length&&num1[i]-start<start-num1[i-1])){
        sum+=num2[i]-start;
        pre=i;
        printf("%d ",num1[i]);
        num1[i]=-1;
    }
    else{
        i--;
        sum+=start-num2[i];
        pre=i;
        printf("%d ",num1[i]);
        num1[i]=-1;
    }
    int rest=length-1;
    while(rest){
        for(i=pre-1;i>=0;i--){
            if(num1[i]!=-1)break;
        }
        int j;
        for(j=pre+1;j<length;j++){
            if(num1[j]!=-1)break;
        }
        if(i>=0&&(j==length||num2[j]-num2[pre]>num2[pre]-num2[i])){
            printf("%d ",num2[i]);
            num1[i]=-1;
            sum+=num2[pre]-num2[i];
            pre=i;
        }
        else{
            printf("%d ",num2[j]);
            num1[j]=-1;
            sum+=num2[j]-num2[pre];
            pre=j;
        }
        rest--;
    }
    printf("\n");
    return sum*1.0/length;
}
double SCAN(){
    printf("----------------------------------------------------\n");
    printf("SCAN(假设在起始位置时磁头朝0方向移动) 磁头服务序列：\n");
    int num[length];
    int i;
    for(i=0;i<length;i++){
        num[i]=numbers[i];
    }
    //将磁头访问序列按磁道号从小到大排序
    for(i=1;i<length-1;i++){
        int j;
        for(j=0;j<length-i;j++){
            if(num[j]>num[j+1]){
                int t=num[j];
                num[j]=num[j+1];
                num[j+1]=t;
            }
        }
    }
    //扫描算法
    int sum=start+num[length-1];
    int pre=start;
    for(i=0;i<length;i++){
        if(num[i]>=start)break;
    }
    if(i==0){
        printf("%d ",num[i]);
        num[i]=-1;
    }
    else{
        i--;
        printf("%d ",num[i]);
        num[i]=-1;
    }
    pre=i;
    int rest=length-1;
    while(i){
        i--;
        printf("%d ",num[i]);
        num[i]=-1;
        rest--;
    }
    i=pre;
    while(rest){
        i++;
        printf("%d ",num[i]);
        num[i]=-1;
        rest--;
    }
    printf("\n");
    return sum*1.0/length;
}
double C_SCAN(){
    printf("----------------------------------------------------\n");
    printf("C-SCAN(假设在起始位置时磁头朝199方向移动) 磁头服务序列：\n");
    int num[length];
    int i;
    for(i=0;i<length;i++){
        num[i]=numbers[i];
    }
    //将磁头访问序列按磁道号从小到大排序
    for(i=1;i<length-1;i++){
        int j;
        for(j=0;j<length-i;j++){
            if(num[j]>num[j+1]){
                int t=num[j];
                num[j]=num[j+1];
                num[j+1]=t;
            }
        }
    }
    //扫描算法
    int sum=0;
    for(i=0;i<length;i++){
        if(num[i]>=start)break;
    }
    if(i==0)sum=num[length-1]-start;
    else sum=199-start+199+num[i-1];
    if(i<length){
        for(;i<length;i++){
            printf("%d ",num[i]);
            num[i]=-1;
        }  
    }
    for(i=0;i<length&&num[i]!=-1;i++){
        printf("%d ",num[i]);
        num[i]=-1;
    }
    printf("\n");
    return sum*1.0/length;
}
double LOOK(){
    printf("----------------------------------------------------\n");
    printf("LOOK(假设在起始位置时磁头朝0方向移动) 磁头服务序列：\n");
    int num[length];
    int i;
    for(i=0;i<length;i++){
        num[i]=numbers[i];
    }
    //将磁头访问序列按磁道号从小到大排序
    for(i=1;i<length-1;i++){
        int j;
        for(j=0;j<length-i;j++){
            if(num[j]>num[j+1]){
                int t=num[j];
                num[j]=num[j+1];
                num[j+1]=t;
            }
        }
    }
    //扫描算法
    int sum;
    if(start>num[0])sum=start-num[0]+num[length-1]-num[0];
    else sum=num[length-1]-start;
    int pre=start;
    for(i=0;i<length;i++){
        if(num[i]>=start)break;
    }
    if(i>0){
        i--;
        printf("%d ",num[i]);
        num[i]=-1;
    }
    pre=i;
    int rest=length-1;
    while(i){
        i--;
        printf("%d ",num[i]);
        num[i]=-1;
        rest--;
    }
    i=pre;
    while(rest){
        i++;
        printf("%d ",num[i]);
        num[i]=-1;
        rest--;
    }
    printf("\n");
    return sum*1.0/length;
}
double C_LOOK(){
    printf("----------------------------------------------------\n");
    printf("C-LOOK(假设在起始位置时磁头朝199方向移动) 磁头服务序列：\n");
    int num[length];
    int i;
    for(i=0;i<length;i++){
        num[i]=numbers[i];
    }
    //将磁头访问序列按磁道号从小到大排序
    for(i=1;i<length-1;i++){
        int j;
        for(j=0;j<length-i;j++){
            if(num[j]>num[j+1]){
                int t=num[j];
                num[j]=num[j+1];
                num[j+1]=t;
            }
        }
    }
    int max=num[length-1];
    if(max<start)max=start;
    int min=num[0];
    int sum;
    //扫描算法
    for(i=0;i<length;i++){
        if(num[i]>=start)break;
    }
    if(i<length){
        for(;i<length;i++){
            printf("%d ",num[i]);
            num[i]=-1;
        }  
    }
    for(i=0;i<length&&num[i]!=-1;i++){
        printf("%d ",num[i]);
        if((i<length-1&&num[i+1]==-1)||i==length-1)sum=max-start+199-(199-max+min)+num[i]-min;
        num[i]=-1;
    }
    printf("\n");
    return sum*1.0/length;
}