#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <mqueue.h>

#include "alg.9-0-msgdata.h"

int main(int argc, char *argv[])
{
    int ret;
    mqd_t mqid;
    void *shmptr;
    char message_0[TEXT_SIZE];
    
    mqid = mq_open(argv[1], O_RDWR, 0444); 
    if(mqid == -1) {
        ERR_EXIT("consumer: mqueue_open()");
    } 

    struct mq_attr mqAttr;
    mq_getattr(mqid, &mqAttr);
    int count = 0;
    sleep(10);
    while(count<5){        
        ret = mq_receive(mqid, message_0, mqAttr.mq_msgsize, NULL);
        if(ret == -1){
            ERR_EXIT("consumer: mqueue_receive()");
        } 

        printf("consumed message: %s\n", message_0); 
        count++;
        sleep(1);
    }

    mq_getattr(mqid, &mqAttr);
    printf("消息队列中还剩%ld条消息.\n",mqAttr.mq_curmsgs);

    while(mqAttr.mq_curmsgs){        
        ret = mq_receive(mqid, message_0, mqAttr.mq_msgsize, NULL);
        if(ret == -1){
            ERR_EXIT("consumer: mqueue_receive()");
        } 

        printf("consumed message: %s\n", message_0); 
        count++;
        sleep(1);
        mq_getattr(mqid, &mqAttr);
    }
    printf("消息队列中还剩%ld条消息.\n",mqAttr.mq_curmsgs);
    
    ret=mq_close(mqid);
    if(ret == -1) {
        ERR_EXIT("producer: mqueue_close()");
    }
    return EXIT_SUCCESS;
}