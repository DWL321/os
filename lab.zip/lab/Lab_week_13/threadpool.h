#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>

typedef struct Threadpool_task{
	void (*function)(void *);
	void *argument;
} threadpool_task;

typedef struct Threadpool {
	pthread_mutex_t lock;     //互斥锁
	pthread_cond_t notify;    //条件变量
	pthread_t *threads;       //线程数组的起始指针
	threadpool_task *queue;   //任务队列数组的起始指针
	int thread_count;         //线程数量
	int task_count;			  //任务队列中任务数量
	int task_head;			  //任务循环队列里的第一个任务
	int task_tail;			  //任务循环队列下次添加任务的位置
	int queue_size;           //任务队列长度
	int shutdown;             //线程池当前状态是否关闭
	int started;              //正在运行的线程数
} threadpool;

static void *threadpool_run(void *thread_pool); //线程池每个线程所执行的函数
threadpool* threadpool_create(int thread_count, int queue_size);//创建线程池
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);//添加需要执行的任务
int threadpool_destroy(threadpool* pool);//销毁存在的线程池并释放线程池所申请的内存资源

static void *threadpool_run(void *thread_pool){
	printf("A thread in pool starts.\n");
	threadpool* pool = (threadpool*)thread_pool;
	while(!pool->shutdown){
		pthread_mutex_lock(&(pool->lock));//取得互斥锁
		while((!pool->shutdown)&&(pool->task_count==0)) {//若线程池没有关闭且任务队列为空则阻塞
            pthread_cond_wait(&(pool->notify),&(pool->lock));
        }

		if(pool->shutdown){//如果线程池关闭就退出
			break;
		}

		//取出任务队列里最先进入的任务
		threadpool_task task;
		task.function=pool->queue[pool->task_head].function;
		task.argument=pool->queue[pool->task_head].argument;
		pool->task_head=(pool->task_head+1)%pool->queue_size;
		pool->task_count--;

		pthread_mutex_unlock(&(pool->lock));//释放互斥锁

		(*(task.function))(task.argument);//执行任务
	}
	pool->started--;
	printf("A thread in pool exits.\n");
	pthread_mutex_unlock(&(pool->lock));
    pthread_exit(NULL);
}
threadpool* threadpool_create(int thread_count, int queue_size){
	if(thread_count <= 0|| queue_size <= 0) {
        return 0;
    }
	threadpool* pool=(threadpool*)malloc(sizeof(threadpool));
	if(pool==0){
		return 0;
	}
	pthread_mutex_init(&(pool->lock), NULL);//初始化互斥锁
	pthread_cond_init(&(pool->notify), NULL);//初始化条件变量
	pool->threads = (pthread_t*)malloc(sizeof(pthread_t)*thread_count);//申请线程数组所需的内存
	pool->queue = (threadpool_task*)malloc(sizeof(threadpool_task)*queue_size);//申请任务队列所需的内存
	if(pool->threads==0||pool->queue==0){
		return 0;
	}
	//初始化其他参数
	pool->thread_count=0;
	pool->task_head=0;
	pool->task_tail=0;
	pool->task_count=0;
    pool->queue_size=queue_size;
    pool->shutdown=0;
	pool->started = 0;
	int i;
	for(i=0;i<thread_count;i++) {//创建thread_count个线程并开始运行
        if(pthread_create(&(pool->threads[i]),NULL,threadpool_run,(void*)pool)!=0){
            threadpool_destroy(pool);
            return 0;
        }
        pool->thread_count++;
        pool->started++;
    }

    return pool;
}
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg){
	if(pthread_mutex_lock(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool->task_count==pool->queue_size||pool->shutdown==1){//判断任务队列满没满或线程池是否关闭
		pthread_mutex_unlock(&pool->lock);
		return -1;
	}
	//向任务循环队列里添加一个新任务
	pool->queue[pool->task_tail].function=fun;
	pool->queue[pool->task_tail].argument=arg;
	pool->task_tail=(pool->task_tail+1)%pool->queue_size;
	pool->task_count++;
	if(pthread_mutex_unlock(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	pthread_cond_signal(&(pool->notify));//发出有任务添加进来的信号，若存在因为任务队列空阻塞的线程就唤醒一个
	return 0;
}
int threadpool_destroy(threadpool* pool){
	if(pthread_mutex_lock(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool==0){//判断这个线程池是否已经摧毁过了
		return 0;
	}
	if(pool->shutdown){//判断线程池是否关闭
		return -1;
	}
	pool->shutdown=1;//关闭线程池
	pthread_cond_broadcast(&(pool->notify));//唤醒线程池里所有因条件变量阻塞的线程
	if(pthread_mutex_unlock(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	int i;
	for(i=0; i<pool->thread_count;i++) {//等待所有线程结束
		pthread_join(pool->threads[i], NULL);
	}

	while(pool->started)sleep(5);
	free(pool->threads);//释放线程数组
	free(pool->queue);//释放任务队列
	pthread_mutex_lock(&(pool->lock));//取得互斥锁所有权
	pthread_mutex_destroy(&(pool->lock));//摧毁互斥锁
	pthread_cond_destroy(&(pool->notify));//摧毁条件变量
    free(pool);//释放线程池
	pool=0;
	return 0;
}