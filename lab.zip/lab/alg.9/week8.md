# 第八周实验报告
[toc] 
## 实验一：编译运行例程代码
按照规定的命令行参数编译、运行**msgsnd.c**，得到的结果如下：  
![1.PNG](https://pic.gksec.com/2021/04/08/c001d38efd638/1.png)
分析：
1. 首先包含了头文件，头文件中包含了消息的数据结构：
    ```
    struct msg_struct {
        long int msg_type;
        char mtext[TEXT_SIZE]; /* binary data */
    };
    ```
2. 和之前一样，用`stat()`函数判断设置为消息传递队列的文件是否存在，不存在就创建一个。之后用`ftok()`函数把这个文件转化为key。
3. 调用了`msgget()`函数并设置权限为0666（读写），得到msqid。之后打开要发送的文件内容，准备读文件。之后用`msgctl()`函数和将消息队列的信息装入到`msqattr`中，从而打印出队列中的消息数目和还剩多少消息可供放入。  
**注意：这里的`msgctl()`函数采用的参数是IPC-STAT，即获取队列信息。此外还有IPC-SET用于设置队列信息，IPC-RMID来删除消息队列。**
4. 之后是从文件中读消息类型和消息信息，直到文件结尾，并存在data中。由于消息队列是定长的，故应当通过阻塞发送的方式，调用`msgsnd()`函数将消息发送出去。如果队列满了，发送就需要等待。
5. 最后统计发送的数目，并显示消息队列的信息。找对应的IPC-key一行，发现发送了10个消息，每个消息512字节。

之后按照规定的命令行参数编译运行**msgrcv.c**，得到的结果如下：
![2.PNG](https://pic.gksec.com/2021/04/08/05fe08114bdeb/2.png)
分析：
1. 前面的操作是生成key，不再赘述。  
2. 这里的`msgget()`函数的参数并没有IPC_CREAT，只是0666，说明这里不可以重新创建消息队列，需要注意。得到了msqid后，根据不同的命令行参数来决定，是只接受某个type的消息，还是全部接受（type = 0）。
3. 之后调用`msgrcv()`函数不断接收指定类型的消息，赋值给data并打印，直到接收完消息队列中的这种消息为止。
4. 调用`msgctl()`函数来获取队列信息，并打印出队列中还剩多少消息未接收。由于第一次只接受类型2，故读出两条，还剩8条；第二次全接受了，故消息队列空了。
5. 最后询问是否删除这个消息队列，再次调用`msgctl()`函数删除，此时查看消息队列，发现找不到这个IPC-key了。

## 实验一：修改代码，观察在 msgsnd 和 msgrcv 并发执行情况下消息队列的变化情况。
这里并不需要修改代码，我首先编译好**msgsnd.c**生成**a.out**，之后编译**msgrcv.c**生成**b.out**。之后在终端1、2运行发送端，终端3、4运行接收端，调试并观察结果：  
1. 在终端1运行两次**a.out**，发送20条信息：（图示为第二次了）
![3.1-1.PNG](https://pic.gksec.com/2021/04/08/64a8e5e4f8ccc/3.1-1.png)
2. 在终端2运行依次**a.out**，发送10条信息：
![3.2-2.PNG](https://pic.gksec.com/2021/04/08/868ad819bd0b4/3.2-2.png)
3. 在终端3只接收类型1的信息，共9条：
![3.3-3.PNG](https://pic.gksec.com/2021/04/08/0723a75d0c150/3.3-3.png)
4. 在终端4只接受类型1的信息，由于已经被接收过，故队列里不再有了：
![3.4-4.PNG](https://pic.gksec.com/2021/04/08/7d2e2f416242f/3.4-4.png)
5. 在终端4只接收类型2的信息，共6条：
![3.5-4.PNG](https://pic.gksec.com/2021/04/08/194f5e6f604a8/3.5-4.png)
6. 在终端3接收全部信息：
![3.6-3.PNG](https://pic.gksec.com/2021/04/08/fa56c281181e1/3.6-3.png)
7. 在终端2再发送10条信息：
![3.7-2.PNG](https://pic.gksec.com/2021/04/08/9a2cac7bd91b5/3.7-2.png)
8. 在终端4全部接收，并删除消息队列：
![3.8-4.PNG](https://pic.gksec.com/2021/04/08/25a2a63c9d40d/3.8-4.png)
9. 在终端3请求接收消息队列，失败：
![3.9-3.PNG](https://pic.gksec.com/2021/04/08/4d6b0a11db2ee/3.9-3.png)

可以看出，发送和接收都是基于队列的。队列中有就可以接收，队列没有就接收不到。一个进程将队列删除后，其他进程就无法访问这个队列了。

## 实验二：编制基于 POSIX API 的进程间消息发送和消息接收例程。
### 接口说明
1. 打开消息队列  
`mqd_t mq_open(const char *name, int oflag, mode_t mode, struct mq_attr *attr);`  
`name`为消息队列文件的路径名，`oflag`表示权限（O_RDONLY，O_WRONLY，O_RDWR），`mode`可以用0666/0444等，`attr`为配置消息队列信息，返回值是一个消息队列描述符。这里的`attr`只有在`oflag`选中了O_CREATE的时候才需要添加这个参数，如果使用默认参数，则这里为NULL。
2. 关闭消息队列  
`mqd_t mq_close(mqd_t mqdes);`  
程序结束后消息队列会自动关闭，因此不需要主动调用。
3. 删除消息队列  
`mqd_t mq_unlink(const char *name);`  
注意这里的参数是文件名，不是描述符。
4. 发送消息  
`mqd_t mq_send(mqd_t mqdes, const char *msg_ptr, size_t msg_len, unsigned msg_prio);`  
参数分别为描述符、信息字符串、消息长度、优先级。这里的实验不需要设置优先级。  
5. 接收消息  
`mqd_t mq_receive(mqd_t mqdes, char *msg_ptr, size_t msg_len, unsigned *msg_prio);`  
注意这里的指针类型，说明可以返回字符串和优先级。但是这里的msg_len要自行设置的，一般设置为`mqAttr.mq_msgsize`。
6. 数据结构  
    ```
    struct mq_attr
    {
        long int mq_flags;      /* Message queue flags.  */
        long int mq_maxmsg;   /* Maximum number of messages.  */
        long int mq_msgsize;   /* Maximum message size.  */
        long int mq_curmsgs;   /* Number of messages currently queued.  */
        long int __pad[4];
    };
    ```
    可以用来查看当前消息队列的信息。
7. 这里需要设置挂载信息，使用以下指令来获取消息队列：
    ```
    #mkdir /dev/mqueue
    #mount -t mqueue none /dev/mqueue
    ```

### 设计思路
1. 在**pos_msgcon.c**中，申请一个消息队列，新生成两个进程，分别进入**pos_msgproducer.c**和**pos_msgconsumer.c**。待两个进程终止后，回收消息队列。
2. 在**pos_msgproducer.c**中，注意这里的`mq_open()`函数中，权限中没有设置O_CREAT，这里不需要创建新的消息队列。之后发送10条消息，隔1s发一次。注意消息长度，由于这里的类型是`const char*`而不是`const char[]`，因此只能用`strlen(msg)+1`而不能用`sizeof()`。
3. 在**pos_msgconsumer.c**中，只接收八条消息。最后调用数据结构，来获得消息队列中剩余的消息数量，应当为2条。

### 实验结果
经过编译运行后查看结果如下，符合预期：
![4.PNG](https://pic.gksec.com/2021/04/11/f4617dd00b1e9/4.png)

### 实验代码
matrix上交代码可能无法编译，这里将代码全部贴在这里：
编译参数如下：
```
gcc pos_msgproducer.c -o pos_msgproducer.o -lrt
gcc pos_msgconsumer.c -o pos_msgconsumer.o -lrt
gcc pos_msgcon.c -o pos_msgcon -lrt
./pos_msgcon /myqueue
```
pos_msgcon.c:
```
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <mqueue.h>

#include "alg.9-0-msgdata.h"

int main(int argc, char *argv[])
{
    struct stat fileattr;
    int ret;
    mqd_t mqid;
    pid_t childpid1, childpid2;

    if(argc < 2) {
        printf("Usage: ./a.out filename\n");
        return EXIT_FAILURE;
    }

    mqid = mq_open(argv[1], O_CREAT|O_RDWR, 0666, NULL); 
    if(mqid == -1) {
        ERR_EXIT("con: mq_open()");
    } 
    system("ls -l /dev/mqueue/");   
    
    char *argv1[] = {" ", argv[1], 0};
    childpid1 = vfork();
    if(childpid1 < 0) {
        ERR_EXIT("pos_msgcon: 1st vfork()");
    } 
    else if(childpid1 == 0) {
        execv("./pos_msgproducer.o", argv1); 
    }
    else {
        childpid2 = vfork();
        if(childpid2 < 0) {
            ERR_EXIT("pos_msgcon: 2nd vfork()");
        }
        else if (childpid2 == 0) {
            execv("./pos_msgconsumer.o", argv1); 
        }
        else {
            wait(&childpid1);
            wait(&childpid2);
            ret = mq_unlink(argv[1]); 
            if(ret == -1) {
                ERR_EXIT("con: mq_unlink()");
            }
            system("ls -l /dev/mqueue/");   
        }
    }
    exit(EXIT_SUCCESS);
}
```
pos_consumer.c:
```
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <mqueue.h>

#include "alg.9-0-msgdata.h"

int main(int argc, char *argv[])
{
    int ret;
    mqd_t fd;
    void *shmptr;
    char message_0[TEXT_SIZE];
    
    fd = mq_open(argv[1], O_RDWR, 0444); 
    if(fd == -1) {
        ERR_EXIT("consumer: shm_open()");
    } 

    struct mq_attr mqAttr;
    mq_getattr(fd, &mqAttr);
    int count = 0;
    while(count<8){        
        ret = mq_receive(fd, message_0, mqAttr.mq_msgsize, NULL);
        if(ret == -1){
            ERR_EXIT("consumer: mq_receive()");
        } 

        printf("consumed message: %s\n", message_0); 
        count++;
        sleep(1);
    }

    sleep(5);
    mq_getattr(fd, &mqAttr);
    printf("There are %ld messages remained in the queue.\n",mqAttr.mq_curmsgs);
    return EXIT_SUCCESS;
}
```
pos_producer.c:
```
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <mqueue.h>
#include <string.h>

#include "alg.9-0-msgdata.h"

int main(int argc, char *argv[])
{
    int ret;
    mqd_t fd;
    void *shmptr;
    const char *message_0 = "Hello World!";
    
    fd = mq_open(argv[1], O_RDWR, 0666); 
    if(fd == -1) {
        ERR_EXIT("producer: shm_open()");
    } 

    for(int i=0;i<10;i++){
        ret = mq_send(fd, message_0, strlen(message_0)+1, 0);
        if(ret == -1){
            ERR_EXIT("producer: mq_send()");
        } 

        printf("produced message: %s\n", message_0);
        sleep(1);
    }


    return EXIT_SUCCESS;
}
```
alg.9-0-msgdata.h:
```
#define TEXT_SIZE 512

struct msg_struct {

    long int msg_type;

    char mtext[TEXT_SIZE]; /* binary data */

};

#define PERM S_IRUSR|S_IWUSR|IPC_CREAT

#define ERR_EXIT(m) \

    do { \

        perror(m); \

        exit(EXIT_FAILURE); \

    } while(0)
```
