#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <stdio.h>

typedef struct Threadpool_task{
	void (*function)(void *);
	void *argument;
} threadpool_task;

typedef struct Threadpool {
	sem_t lock;     		  //确保线程池分配互斥的内存信号量，起到互斥锁的作用
	sem_t remain;    		  //通知执行任务的线程任务队列中剩余任务数的内存信号量
	pthread_t *threads;       //线程数组的起始指针
	threadpool_task *queue;   //任务队列数组的起始指针
	int thread_count;         //线程数量
	int task_count;			  //任务队列中任务数量
	int task_head;			  //任务循环队列里的第一个任务
	int task_tail;			  //任务循环队列下次添加任务的位置
	int queue_size;           //任务队列长度
	int shutdown;             //线程池当前状态是否关闭
	int started;              //正在运行的线程数
} threadpool;

static void *threadpool_run(void *thread_pool); //线程池每个线程所执行的函数
threadpool* threadpool_create(int thread_count, int queue_size);//创建线程池
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);//添加需要执行的任务
int threadpool_destroy(threadpool* pool);//销毁存在的线程池并释放线程池所申请的内存资源

static void *threadpool_run(void *thread_pool){
	printf("A thread in pool starts.\n");
	threadpool* pool = (threadpool*)thread_pool;
	while(!pool->shutdown){
		sem_wait(&(pool->lock));//取得互斥锁
		while((!pool->shutdown)&&(pool->task_count==0)) {//若线程池没有关闭且任务队列为空则阻塞
            sem_post(&pool->lock);
			sem_wait(&pool->remain);
			sem_wait(&pool->lock);
        }

		if(pool->shutdown){//如果线程池关闭就退出
			break;
		}

		//取出任务队列里最先进入的任务
		threadpool_task task;
		task.function=pool->queue[pool->task_head].function;
		task.argument=pool->queue[pool->task_head].argument;
		pool->task_head=(pool->task_head+1)%pool->queue_size;
		pool->task_count--;

		sem_post(&(pool->lock));//释放互斥锁

		(*(task.function))(task.argument);//执行任务
	}
	pool->started--;
	printf("A thread in pool exits.\n");
	sem_post(&(pool->lock));
    pthread_exit(NULL);
}
threadpool* threadpool_create(int thread_count, int queue_size){
	if(thread_count <= 0|| queue_size <= 0) {
        return 0;
    }
	threadpool* pool=(threadpool*)malloc(sizeof(threadpool));
	if(pool==0){
		return 0;
	}
	sem_init(&pool->lock, 0, 1);//初始化互斥信号量
	sem_init(&pool->remain, 0, 0);//初始化队列剩余任务数信号量
	pool->threads = (pthread_t*)malloc(sizeof(pthread_t)*thread_count);//申请线程数组所需的内存
	pool->queue = (threadpool_task*)malloc(sizeof(threadpool_task)*queue_size);//申请任务队列所需的内存
	if(pool->threads==0||pool->queue==0){
		return 0;
	}
	//初始化其他参数
	pool->thread_count=0;
	pool->task_head=0;
	pool->task_tail=0;
	pool->task_count=0;
    pool->queue_size=queue_size;
    pool->shutdown=0;
	pool->started = 0;
	int i;
	for(i=0;i<thread_count;i++) {//创建thread_count个线程并开始运行
        if(pthread_create(&(pool->threads[i]),NULL,threadpool_run,(void*)pool)!=0){
            threadpool_destroy(pool);
            return 0;
        }
        pool->thread_count++;
        pool->started++;
    }

    return pool;
}
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg){
	if(sem_wait(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool->task_count==pool->queue_size||pool->shutdown==1){//判断任务队列满没满或线程池是否关闭
		sem_post(&pool->lock);
		return -1;
	}
	//向任务循环队列里添加一个新任务
	pool->queue[pool->task_tail].function=fun;
	pool->queue[pool->task_tail].argument=arg;
	pool->task_tail=(pool->task_tail+1)%pool->queue_size;
	pool->task_count++;
	if(sem_post(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	sem_post(&(pool->remain));//发出有任务添加进来的信号，若存在因为任务队列空阻塞的线程就唤醒一个
	return 0;
}
int threadpool_destroy(threadpool* pool){
	if(sem_wait(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool==0){//判断这个线程池是否已经摧毁过了
		return 0;
	}
	if(pool->shutdown){//判断线程池是否关闭
		return -1;
	}
	pool->shutdown=1;//关闭线程池
	int i;
	for(i=0;i<pool->started;i++){//唤醒所有因为任务队列为空而阻塞的线程
		sem_post(&pool->remain);
	}
	if(sem_post(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	for(i=0; i<pool->thread_count;i++) {//等待所有线程结束
		pthread_join(pool->threads[i], NULL);
	}

	while(pool->started)sleep(5);
	free(pool->threads);//释放线程数组
	free(pool->queue);//释放任务队列
	sem_destroy(&(pool->lock));//摧毁互斥信号量
	sem_destroy(&(pool->remain));//摧毁剩余任务信号量
    free(pool);//释放线程池
	pool=0;
	return 0;
}