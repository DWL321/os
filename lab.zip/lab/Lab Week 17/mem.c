#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int* use;//page的reference string
int num_test;//调用次数
int num_frame;//frame的数量

void init();//初始化参数并随机生成测试样例
int FIFO();//FIFO请求页面置换算法，返回page faults
int LRU_stack();//LRU(stack implementation)请求页面置换算法，返回page faults
int LRU_matrix();//LRU(matrix implementation)请求页面置换算法，返回page faults
int Second_chance(); //Second chance请求页面置换算法，返回page faults

int main()
{
    init();
    printf("FIFO:%d page faults\n",FIFO());
    printf("LRU(stack implementation):%d page faults\n",LRU_stack());
    printf("LRU(matrix implementation):%d page faults\n",LRU_matrix());
    printf("Second chance:%d page faults\n",Second_chance());
    free(use);
    return 0;
}
void init(){
    printf("input the number of frames:");
    scanf("%d",&num_frame);
    printf("input the length of reference string:");
    scanf("%d",&num_test);
    use=(int*)malloc(sizeof(int)*num_test);
    int cho;
    printf("1.input reference string    2.randomly set the reference string:");
    scanf("%d",&cho);
    if(cho==1){
        printf("input reference string:");
        int i;
        for(i=0;i<num_test;i++){
            scanf("%d",&use[i]);
        }
    }
    else{
        srand(time(0));
        printf("randomly set the reference string:");
        int i;
        for(i=0;i<num_test;i++){//每次调用的page是随机选择的
            use[i]=rand()%(num_test*2-num_test/2);
            printf("%d ",use[i]);
        }
        printf("\n");    
    }
}
int FIFO(){
    printf("----------------------------------------------------\n");
    int phy_mem[num_frame+1];//采用有一个空位的循环队列，当head=tail时队列为空，当head=(tail+1)%(num_frame+1)时队列为满
    int head=0;
    int tail=0;
    int miss=0;
    int i;
    for(i=0;i<num_test;i++){
        int hit=0;
        if(head!=tail){//若循环队列不为空
            int j;
            for(j=head;j!=tail;j=(j+1)%(num_frame+1)){//扫描循环队列
                if(phy_mem[j]==use[i]){
                    hit=1;
                    printf("hit page%d\n",use[i]);
                    break;
                }
            }
        }
        if(hit)continue;//如果这页命中就处理下一页
        miss++;
        if(head!=(tail+1)%(num_frame+1)){//缺失但队列未满，则直接调入
            printf("miss page%d,take in page%d\n",use[i],use[i]);
            phy_mem[tail]=use[i];
            tail=(tail+1)%(num_frame+1);
        }
        else{//缺失但队列已满，则调出队首的page，再把这个page调入队尾
            printf("miss page%d,take out page%d,take in page%d\n",use[i],phy_mem[head],use[i]);
            head=(head+1)%(num_frame+1);
            phy_mem[tail]=use[i];
            tail=(tail+1)%(num_frame+1);
        }
    }
    return miss;
}
int LRU_stack(){
    printf("----------------------------------------------------\n");
    int stack[num_frame];
    int top=-1;
    int miss=0;
    int i;
    for(i=0;i<num_test;i++){
        int hit=0;
        if(top>=0){//若栈不为空
            int j;
            for(j=0;j<=top;j++){//扫描循环队列
                if(stack[j]==use[i]){
                    hit=1;
                    printf("hit page%d\n",use[i]);
                    break;
                }
            }
            if(j<=top){//若命中将该页面号压入栈顶，其他的页面号往栈底移
                while(j<top){
                    stack[j]=stack[j+1];
                    j++;
                }
                stack[top]=use[i];
            }
        }
        if(hit)continue;//如果这页命中就处理下一页
        miss++;
        if(top<num_frame-1){//缺失但栈未满，则直接调入栈顶
            printf("miss page%d,take in page%d\n",use[i],use[i]);
            top++;
            stack[top]=use[i];
        }
        else{//缺失但栈已满，则调出栈底的page,其他的页面号往栈底移，再把这个page调入栈顶
            printf("miss page%d,take out page%d,take in page%d\n",use[i],stack[0],use[i]);
            int j=0;
            while(j<top){
                stack[j]=stack[j+1];
                j++;
            }
            stack[top]=use[i];
        }
    }
    return miss;    
}
int LRU_matrix(){
    printf("----------------------------------------------------\n");
    int matrix[num_frame][num_frame];
    int frames[num_frame];//记录矩阵各行对应的页号
    int num=0;//目前内存中已有的页数
    int miss=0;
    int i;
    for(i=0;i<num_frame;i++){//矩阵的初值为0
        int j;
        for(j=0;j<num_frame;j++){
            matrix[i][j]=0;
        }
    }
    for(i=0;i<num_test;i++){
        int hit=0;
        if(num>0){//若矩阵不为空
            int j;
            for(j=0;j<num;j++){//扫描循环队列
                if(frames[j]==use[i]){
                    hit=1;
                    printf("hit page%d\n",use[i]);
                    break;
                }
            }
            if(hit){//若命中将该页面号压入栈顶，其他的页面号往栈底移
                int k;
                for(k=0;k<num_frame;k++){
                    matrix[j][k]=1;
                    matrix[k][j]=0;
                }
                matrix[j][j]=0;
            }
        }
        if(hit)continue;//如果这页命中就处理下一页
        miss++;
        if(num<num_frame){//缺失但矩阵未满，则直接调入矩阵
            printf("miss page%d,take in page%d\n",use[i],use[i]);
            frames[num]=use[i];
            num++;
            int k;
            for(k=0;k<num_frame;k++){
                matrix[num-1][k]=1;
                matrix[k][num-1]=0;
            }
            matrix[num-1][num-1]=0;
        }
        else{//缺失但栈已满，则选择矩阵里对应行值最小的页面更换
            int j;
            int tag[num_frame];//继续参与比较行值的对应行号置1，已确定不是最小行值的置0
            for(j=0;j<num_frame;j++){
                tag[j]=1;
            }
            int k;
            int rest=num_frame;//未确定是否是最小行值的行数
            for(k=0;k<num_frame;k++){
                int w;
                for(w=0;w<num_frame;w++){
                    if(rest==1)break;
                    if(tag[w]){
                        if(matrix[w][k]){
                            rest--;
                            tag[w]=0;
                        }
                    }
                }
            }
            for(k=0;k<num_frame;k++){
                if(tag[k]){
                    j=k;
                    break;
                }
            }
            printf("miss page%d,take out page%d,take in page%d\n",use[i],frames[j],use[i]);
            frames[j]=use[i];
            for(k=0;k<num_frame;k++){
                matrix[j][k]=1;
                matrix[k][j]=0;
            }
            matrix[j][j]=0;
        }
    }
    return miss; 
}
int Second_chance(){
    printf("----------------------------------------------------\n");
    int phy_mem[num_frame];
    int use_bit[num_frame];
    int head=0;
    int tail=-1;
    int size=0;
    int miss=0;
    int i;
    for(i=0;i<num_frame;i++)use_bit[i]=0;
    for(i=0;i<num_test;i++){
        int hit=0;
        if(size){//若循环队列不为空
            int j;
            for(j=head;1;j=(j+1)%(num_frame)){//扫描循环队列
                if(phy_mem[j]==use[i]){
                    use_bit[j]=1;//将使用位置1
                    hit=1;
                    printf("hit page%d\n",use[i]);
                    break;
                }
                if(j==tail)break;
            }
        }
        if(hit)continue;//如果这页命中就处理下一页
        miss++;
        if(size<num_frame){//缺失但队列未满，则直接调入
            printf("miss page%d,take in page%d\n",use[i],use[i]);
            tail=(tail+1)%(num_frame);
            phy_mem[tail]=use[i];
            use_bit[tail]=1;
            size++;
        }
        else{//缺失但队列已满
            //从队首开始扫描，遇到使用位为1的就置0，遇到使用位为0的就把这页换出把要调用的页放到这个位置
            //然后将这个位置设为队尾，下一个位置设为队首
            int j;
            for(j=head;1;j=(j+1)%(num_frame)){
                if(use_bit[j])use_bit[j]=0;
                else{
                    printf("miss page%d,take out page%d,take in page%d\n",use[i],phy_mem[j],use[i]);
                    phy_mem[j]=use[i];
                    use_bit[j]=1;
                    head=(j+1)%num_frame;
                    tail=j;
                    break;
                }
            }
        }
    }
    return miss;
}