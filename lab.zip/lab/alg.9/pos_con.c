/* gcc -lrt */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h> 
#include <sys/wait.h>
#include <fcntl.h>
#include <mqueue.h>

#include "alg.9-0-msgdata.h"

int main(int argc, char *argv[])
{
    struct stat fileattr;
    int ret;
    pid_t childpid1, childpid2;
    mqd_t mqid;

    if(argc < 2) {
        printf("Usage: ./a.out filename\n");
        return EXIT_FAILURE;
    }

    mqid = mq_open(argv[1], O_CREAT|O_RDWR, 0666, NULL);
        
    if(mqid == -1) {
        ERR_EXIT("pos_con: mqueue_open()");
    } 
    printf("--------消息队列--------\n");
    system("ls -l /dev/mqueue/");   
    
    char *argv1[] = {" ", argv[1], 0};
    childpid1 = vfork();
    if(childpid1 < 0) {
        ERR_EXIT("pos_con: 1st vfork()");
    } 
    else if(childpid1 == 0) {
        execv("./producer.o", argv1); /* call producer with filename */
    }
    else {
        childpid2 = vfork();
        if(childpid2 < 0) {
            ERR_EXIT("pos_con: 2nd vfork()");
        }
        else if (childpid2 == 0) {
            execv("./consumer.o", argv1); /* call consumer with filename */
        }
        else {
            wait(&childpid1);
            wait(&childpid2);
            sleep(10);
            ret=mq_close(mqid);
            if(ret == -1) {
                ERR_EXIT("pos_con: mqueue_close()");
            }
            ret = mq_unlink(argv[1]); 
            if(ret == -1) {
                ERR_EXIT("pos_con: mqueue_unlink()");
            }
            printf("--------消息队列--------\n");
            system("ls -l /dev/mqueue/");   
        }
    }
    exit(EXIT_SUCCESS);
}

