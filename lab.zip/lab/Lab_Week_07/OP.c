#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/shm.h>

#define M_SIZE 4017913856  /* 系统一次可以申请的共享内存空间M的最大值 */

#define MAX_NAME_LEN 12 //定义名字的最大长度：11个字节
#define MAX_STUDENT_NUM 200895692
//堆中单元数量(4017913856-4-4-8)/(4+4+12)=200895692
typedef struct Student{
    int flag;//结点的删除标识，删除的结点flag=1
    int id;//学号
    char name[MAX_NAME_LEN];
}student;
struct shared_struct {
    int num;//需要使用这个共享内存空间的进程数，不包括创建M的进程
    int lock;//逻辑值 lock 用来保证同一时间只有一个进程进入M,lock=1表示有进程正在使用M
    long long tail;//堆中最后一个有效单元的位置，-1表示堆为空
    student students[MAX_STUDENT_NUM];//静态链表L
};

#define PERM S_IRUSR|S_IWUSR|IPC_CREAT

#define ERR_EXIT(m) \
    do { \
        perror(m); \
        exit(EXIT_FAILURE); \
    } while(0)


struct shared_struct * insert(struct shared_struct * shared);
struct shared_struct * delete(struct shared_struct * shared);
struct shared_struct * change(struct shared_struct * shared);
void search(struct shared_struct * shared);
struct shared_struct * reset(struct shared_struct * shared);

int main(int argc, char *argv[])
{
    void *shmptr = NULL;
    struct shared_struct *shared;
    int shmid;
    key_t key;
 
    sscanf(argv[1], "%x", &key);
    printf("shmread: IPC key = %x\n", key);
    
    shmid = shmget((key_t)key, sizeof(struct shared_struct), 0666|PERM);
    if (shmid == -1) {
        ERR_EXIT("shread: shmget()");
    }

    shmptr = shmat(shmid, 0, 0);
    if(shmptr == (void *)-1) {
        ERR_EXIT("shread: shmat()");
    }
    printf("shmread: shmid = %d\n", shmid);    
    printf("shmread: shared memory attached at %p\n", shmptr);
    printf("shmread process ready ...\n");
    
    shared = (struct shared_struct *)shmptr;
    
    shared->num++;//连接M的OP进程数加一
    int op=1;
    while (op) {
        int ju=1;
        while(shared->lock==1) {
            if(ju)printf("其他进程正在访问共享内存M, waiting\n");
            sleep(1); /*挂起1秒*/
            ju=0;
        }
        shared->lock=1;
        printf("请输入操作编号(1.插入 2.删除 3.修改 4.查找 5.重排 0.退出):");
        scanf("%d",&op);
        if(op==1)shared=insert(shared);
        else if(op==2)shared=delete(shared);
        else if(op==3)shared=change(shared);
        else if(op==4)search(shared);
        else if(op==5)shared=reset(shared);
        shared->lock=0;
        sleep(1);
    } 
    shared->num--;//连接M的OP进程数减一
   if (shmdt(shmptr) == -1) {//断开共享内存连接
        ERR_EXIT("shmread: shmdt()");
   }
    exit(EXIT_SUCCESS);
}
struct shared_struct * insert(struct shared_struct * shared){
    long long i;
    int id;
    printf("请输入学生的id：");
    scanf("%d",&id);
    for(i=0;i<=shared->tail;i++){//查找是否有重复结点
        if(shared->students[i].flag==0&&shared->students[i].id==id){
            printf("此学生已存在\n");
            return shared;
        }
    }
    for(i=0;i<=shared->tail;i++){//如果有被删除的结点就替换第一个被删除的结点
        if(shared->students[i].flag==1){
            shared->students[i].flag=0;
            shared->students[i].id=id;
            printf("请输入学生的姓名：");
            scanf("%s",shared->students[i].name);
            printf("插入成功\n");
            return shared;
        }
    }
    if(shared->tail+1==MAX_STUDENT_NUM){//如果没有被删除的结点且堆的最后一个结点填有有效信息，则堆已满，打印错误信息并返回
        printf("堆已满，需要删除一些学生\n");
        return shared;
    }
    //插到堆尾
    shared->tail++;
    shared->students[shared->tail].flag=0;
    printf("请输入学生的id：");
    scanf("%d",&shared->students[shared->tail].id);
    printf("请输入学生的姓名：");
    scanf("%s",shared->students[shared->tail].name);
    printf("插入成功\n");
    return shared;
}
struct shared_struct * delete(struct shared_struct * shared){
    printf("请输入要删除的学生的id：");
    int id;
    scanf("%d",&id);
    long long i;
    for(i=0;i<=shared->tail;i++){//找到要删除的结点将flag置为1
        if(shared->students[i].id==id&&shared->students[i].flag==0){
            shared->students[i].flag=1;
            printf("这个学生是%s，删除成功\n",shared->students[i].name);
            break;
        }
    }
    if(i>shared->tail)printf("这个学生不存在\n");
    return shared;
}
struct shared_struct * change(struct shared_struct * shared){
    printf("请输入要修改的学生的id：");
    int id;
    scanf("%d",&id);
    long long i;
    for(i=0;i<=shared->tail;i++){
        if(shared->students[i].id==id&&shared->students[i].flag==0){
            printf("这个学生是%s，请输入修改后的id：",shared->students[i].name);
            scanf("%d",&shared->students[i].id);
            printf("请输入修改后的姓名：");
            scanf("%s",shared->students[i].name);
            printf("修改成功\n");
            break;
        }
    }
    if(i>shared->tail)printf("这个学生不存在\n");
    return shared;
}
void search(struct shared_struct * shared){
    printf("请输入要查找的学生的id：");
    int id;
    scanf("%d",&id);
    long long i;
    for(i=0;i<=shared->tail;i++){
        if(shared->students[i].id==id&&shared->students[i].flag==0){
            printf("这个学生是%s，在静态链表L里下标为%lld\n",shared->students[i].name,i);
            break;
        }
    }
    if(i>shared->tail)printf("这个学生不存在\n");
}
struct shared_struct * reset(struct shared_struct * shared){
    long long i,j;
    for(i=0;i<=shared->tail;i++){//将所有有效结点移到前面覆盖删除的结点
        if(shared->students[i].flag==1){//找到最后一个有效结点并覆盖当前结点
            for(j=shared->tail;j>i;j--){
                shared->tail--;
                if(shared->students[j].flag==0)break;
            }
            if(j>i)shared->students[i]=shared->students[j];
            else{
                shared->tail--;
                break;
            }
        }
    }
    for(i=(shared->tail+1)/2;i>0;i--){//从最后一个有儿子结点的结点开始重排
        long long index=i;
        while(index*2<=shared->tail+1){//如果这个结点有左儿子
            if(index*2<=shared->tail){//如果这个结点有右儿子
                if(shared->students[index*2-1].id<shared->students[index*2].id){//如果左儿子的id小于右儿子
                    if(shared->students[index-1].id>shared->students[index*2-1].id){//如果这个结点的id大于左儿子就交换
                        student q=shared->students[index-1];
                        shared->students[index-1]=shared->students[index*2-1];
                        shared->students[index*2-1]=q;
                        index=index*2;
                    }
                    else break;
                }
                else{//如果左儿子的id大于等于于右儿子
                    if(shared->students[index-1].id>shared->students[index*2].id){//如果这个结点的id大于右儿子就交换
                        student q=shared->students[index-1];
                        shared->students[index-1]=shared->students[index*2];
                        shared->students[index*2]=q;
                        index=index*2+1;
                    }
                    else break;
                }
            }
            else if(shared->students[index-1].id>shared->students[index*2-1].id){//如果这个结点没有右儿子，若这个的id大于左儿子则交换
                student q=shared->students[index-1];
                shared->students[index-1]=shared->students[index*2-1];
                shared->students[index*2-1]=q;
                index=index*2;
            }
            else break;
        }
    }
    printf("重排完成\n");
    return shared;
}