# Lab Week 15 实验报告
## 实验内容：进程同步。
* 内容1:编译运行课件 Lecture18 例程代码。
    * Algorithms 18-1 ~ 18-9.
* 内容2:在 Lab Week 13 的基础上用信号量解决线程池分配的互斥问题。
    * 编译、运行、测试用例。
    * 提交新的设计报告。
## 编译运行课件 Lecture18 例程代码
### alg.18-1-syn-fetch-1.c 运行及分析
**运行结果：**

![](15.1.1.png)

**程序分析：**
* 设计思路：
    比较原子操作__sync_fetch_and_add和__sync_add_and_fetch效果的不同。
* 用到的重要函数：
    * 先返回原数值再做加法：type __sync_fetch_and_add(type *ptr, type value);
        * ptr:指向被加数的指针;
        * value:加数;
        * 返回值：ptr指向数字原来的值。 
    * 先做加法再返回原数值：type __sync_add_and_fetch(type *ptr, type value);
        * ptr:指向被加数的指针;
        * value:加数;
        * 返回值：ptr指向数字做加法后的值。
### alg.18-1-syn-fetch-2.c 运行及分析
**运行结果：**

![](15.1.2.png)

**程序分析：**
* 设计思路：
    生成40个线程使用原子操作__sync_fetch_and_add使全局变量count做自增。结果正确。
* 用到的重要函数：
    * 先返回原数值再做加法：type __sync_fetch_and_add(type *ptr, type value);
        * ptr:指向被加数的指针;
        * value:加数;
        * 返回值：ptr指向数字原来的值。
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
### alg.18-1-syn-fetch-3.c 运行及分析
**运行结果：**

![](15.1.3.png)

**程序分析：**
* 设计思路：
    生成40个线程使用counr++语句使全局变量count做自增。结果错误，因为count++语句相当于三条原子操作。
* 用到的重要函数：
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
### alg.18-2-syn-compare-test.c 运行及分析
**运行结果：**

![](15.2.png)

**程序分析：**
* 设计思路：
    测试__sync_bool_compare_and_swap、__sync_val_compare_and_swap、__sync_lock_test_and_set、__sync_lock_release四个原子操作的效果。
* 用到的重要函数：
    * 在写入新值前读出存储的值，当且仅当旧值与存储的值相同时才把新值写如存储：bool __sync_bool_compare_and_swap(type *ptr, type old, type new);
        * ptr:指向原来存储的值；
        * old:旧值；
        * new:新值；
        * 返回值：原来存储的值与旧值相等则返回1，不等则返回0。
    * 在写入新值前读出存储的值，当且仅当旧值与存储的值相同时才把新值写如存储：type __sync_val_compare_and_swap(type *ptr, type old, type new);
        * ptr:指向原来存储的值；
        * old:旧值；
        * new:新值；
        * 返回值：返回原来存储的值。
    * 将ptr设为new并返回ptr操作之前的值：type __sync_lock_test_and_set(type *ptrptr, type new)；
        * ptr:指向原来存储的值；
        * new:新值；
        * 返回值：返回原来存储的值。
    * 将ptr指向的值置0:void __sync_lock_release(type *ptr);
        * ptr:指向原来存储的值；
### alg.18-3-syn-pthread-mutex.c 运行及分析
**运行结果：**

![](15.3.png)

**程序分析：**
* 设计思路：
    如果启动程序时未输入参数`syn`，就生成40个线程直接使用`count++`语句使全局变量count做自增，结果错误，因为count++语句相当于三条原子操作。如果启动程序时输入参数`syn`，就生成40个线程，就使用互斥锁mutex保证各线程访问共享内存互斥，使全局变量count做自增，结果正确。
* 用到的重要函数：
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
    * 退出线程：void  pthread_exit（void  * retval）;
        * retval:把一个空指针类型的值传给pthread_join的第二个参数;
        * 返回值：返回一个空指针类型的值。 
    * 以动态方式创建互斥锁: int pthread_mutex_init(pthread_mutex_t * &mutex,const pthread_mutexattr_t * &attr);
        * mutex:要创建的互斥锁；
        * attr:互斥锁属性
        * 成功返回0。
    * 互斥锁上锁：int pthread_mutex_lock(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0,锁住由mutex指定的互斥锁。如果mutex已经被锁住，调用这个函数的线程阻塞直到mutex可用为止，函数返回的时候参数mutex指定的互斥锁变成锁住状态， 同时该函数的调用线程成为该互斥锁的拥有者。
    * 互斥锁解锁:int pthread_mutex_unlock(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0。
    * 摧毁互斥锁：int pthread_mutex_destroy(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0。
### alg.18-4-syn-pthread-sem-unnamed.c 运行及分析
**运行结果：**

![](15.4.png)

**程序分析：**
* 设计思路：
    如果启动程序时未输入参数`syn`，就生成40个线程直接使用`count++`语句使全局变量count做自增，结果错误，因为count++语句相当于三条原子操作。如果启动程序时输入参数`syn`，就生成40个线程，就使用内存信号量unnamed_sem保证各线程访问共享内存互斥，使全局变量count做自增，结果正确。
* 用到的重要函数：
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
    * 退出线程：void  pthread_exit（void  * retval）;
        * retval:把一个空指针类型的值传给pthread_join的第二个参数;
        * 返回值：返回一个空指针类型的值。 
    * 创建内存信号量：int sem_init(sem_t *sem,int pshared,unsigned int value);
        * sem:指向初始化的信号对象；
        * pshared:控制信号量的类型，如果其值为0，就表示这个信号量是当前进程的局部信号量，否则信号量就可以在多个进程之间共享;
        * value：信号对象的初始值；
        * 返回值：成功返回0，失败返回-1。
    * 以原子操作的方式将信号量的值减1，若操作前信号量值小于等于0，就会阻塞这个线程，等待信号量增加到大于0时再减1并唤醒线程：int sem_wait(sem_t *sem); 
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
    * 以原子操作的方式将信号量的值加1：int sem_post(sem_t *sem);  
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
    * 摧毁用完的信号量：int sem_destroy(sem_t *sem); 
        *  sem:信号量；
        * 返回值：成功返回0，失败返回-1。
### alg.18-5-syn-pthread-sem-named.c 运行及分析
**运行结果：**

![](15.5.png)

**程序分析：**
* 设计思路：
    如果启动程序时未输入参数`syn`，就生成40个线程直接使用`count++`语句使全局变量count做自增，结果错误，因为count++语句相当于三条原子操作。如果启动程序时输入参数`syn`，就生成40个线程，就使用有名信号量unnamed_sem保证各线程访问共享内存互斥，使全局变量count做自增，结果正确。
* 用到的重要函数：
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
    * 退出线程：void  pthread_exit（void  * retval）;
        * retval:把一个空指针类型的值传给pthread_join的第二个参数;
        * 返回值：返回一个空指针类型的值。 
    * 创建并初始化有名信号量：sem_t * sem_open(const char * name,int oflag,mode_t mode,unsigned int value);
        * name:信号量的外部文件名；
        * oflag:选择创建或打开一个现有的信号量；
        * mode:权限位；
        * value:信号量初始值；
        * 返回值：成功时返回指向信号量的指针，出错时为SEM_FAILED。
    * 关闭有名信号灯：int sem_close(sem_t *sem);
        * sem：指向信号量的指针
        * 返回值：若成功则返回0，否则返回-1。
    * 以原子操作的方式将信号量的值减1，若操作前信号量值小于等于0，就会阻塞这个线程，等待信号量增加到大于0时再减1并唤醒线程：int sem_wait(sem_t *sem); 
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
    * 以原子操作的方式将信号量的值加1：int sem_post(sem_t *sem);  
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
        * 一个进程终止时，内核还对其上仍然打开着的所有有名信号量自动执行这样的信号量关闭操作。不论该进程是自愿终止的还是非自愿终止的，这种自动关闭都会发生。但应注意的是关闭一个信号量并没有将它从系统中删除。这就是说，Posix有名信号量至少是随内核持续的：即使当前没有进程打开着某个信号量，它的值仍然保持。
    * 从系统中删除信号量：int sem_unlink(count char *name);
        * name:信号量的外部文件名；
        * 返回值：若成功则返回0，否则返回-1。
        * 每个信号量有一个引用计数器记录当前的打开次数，sem_unlink必须等待这个数为0时才能把name所指的信号量从文件系统中删除。也就是要等待最后一个sem_close发生。
* 有名信号量和内存信号量的区别：
    * 创建有名信号量必须指定一个与信号量相关链的文件名称，这个name通常是文件系统中的某个文件。基于内存的信号量不需要指定名称。
    * 有名信号量sem 是由sem_open分配内存并初始化成value值。基于内存的信号量是由应用程序分配内存，有sem_init初始化成为value值。如果sem_init第二个参数为1，则分配的信号量应该在共享内存中。
    * sem_open不需要类似shared的参数，因为有名信号量总是可以在不同进程间共享的。而基于内存的信号量通过sem_init第二个参数来决定是进程内还是进程间共享，并且必须指定相应的内存。
    * 基于内存的信号量不使用任何类似于O_CREAT标志的东西，也就是说，sem_init总是初始化信号量的值，因此，对于一个给定的信号量，我们必须小心保证只调用sem_init一次，对于一个已经初始化过的信号量调用sem_init,结果是未定义的。
    * 内存信号量通过sem_destroy删除信号量，有名信号量通过sem_unlink删除。 
### alg.18-6～alg.18-8 运行及分析
**运行结果：**

![](15.6.png)

**程序分析：**
* 设计思路：
    这是一个多生产者多消费者程序，首先用户输入缓存区大小、货物数量、生产者数量、消费者数量，然后创建共享内存并初始化控制参数。然后创建3个内存信号量：第一个初始化为1，用作共享内存访问互斥；第二个初始化为0，用来通知消费者生产者停止工作；第三个初始化为缓存区大小，用作通知生产者线程缓存区还能装多少货物；然后用vfork+execv创建生产者子进程和消费者子进程，父进程阻塞等待两个子进程结束后销毁三个信号量并删除共享内存。在生产者子进程中，首先连接共享内存，然后生成多个生产者线程，等待所有生产者线程终止后，给消费者个数减1个消费者发送生产者结束工作的信号量，然后断开共享内存连接并退出。在生产者线程中，若货物还没生产完就进入while循环，根据信号量emptyslot判断缓存区剩余容量，若缓存区已满就阻塞等待，若缓存区还有空间就把emptyslot减1，然后阻塞等待互斥锁信号量变为1，然后如果货物还没生产完，就把已生产的货物数加1并将缓存区循环队列尾后移一个单位并标注这个货物是由这个tid的生产者生产并输出提示信息然后通知消费者一个生产者工作完了，若此时所有货物生产完成就要把结束标志设为1，若取得互斥锁后所有货物已经生产完，则仅将emptyslot加1，在循环最后释放互斥锁并挂起一秒，若没有进入循环则线程直接终止。在消费者子进程中，首先连接共享内存，然后生成多个消费者线程，等待所有消费者线程终止后，断开共享内存连接并退出。在消费者线程中，若生产的货物未全部取出或结束标志为0则进入while循环，首先等待至少一个生产者工作完成，然后取得互斥锁，若此时仍有已生产的货物未被取出，则把缓存区循环队列头后移一个单位并输出提示信息并将已取出的货物数加1然后通知生产者缓存区空间+1，否则通知其他消费者一个生产者工作完了，在循环最后释放互斥锁，若没有进入循环则线程直接终止。
* 用到的重要函数：
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
    * 退出线程：void  pthread_exit（void  * retval）;
        * retval:把一个空指针类型的值传给pthread_join的第二个参数;
        * 返回值：返回一个空指针类型的值。 
    * 创建内存信号量：int sem_init(sem_t *sem,int pshared,unsigned int value);
        * sem:指向初始化的信号对象；
        * pshared:控制信号量的类型，如果其值为0，就表示这个信号量是当前进程的局部信号量，否则信号量就可以在多个进程之间共享;
        * value：信号对象的初始值；
        * 返回值：成功返回0，失败返回-1。
    * 以原子操作的方式将信号量的值减1，若操作前信号量值小于等于0，就会阻塞这个线程，等待信号量增加到大于0时再减1并唤醒线程：int sem_wait(sem_t *sem); 
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
    * 以原子操作的方式将信号量的值加1：int sem_post(sem_t *sem);  
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
    * 摧毁用完的信号量：int sem_destroy(sem_t *sem); 
        *  sem:信号量；
        * 返回值：成功返回0，失败返回-1。
### alg.18-9-pthread-cond-wait.c 运行及分析
**运行结果：**

![](15.9.png)

**程序分析：**
* 设计思路：
    生成两个线程线程decrement和increment，increment使全局变量count每次自增1，decrement使环境变量count每次自减1，使用互斥锁确保两线程访问count互斥，使用条件变量确保count为非负数。
* 用到的重要函数：
    *  创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
    * 互斥锁上锁：int pthread_mutex_lock(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0,锁住由mutex指定的互斥锁。如果mutex已经被锁住，调用这个函数的线程阻塞直到mutex可用为止，函数返回的时候参数mutex指定的互斥锁变成锁住状态， 同时该函数的调用线程成为该互斥锁的拥有者。
    * 互斥锁解锁:int pthread_mutex_unlock(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0。
    * 线程无条件挂起等待条件变量成立：int pthread_cond_wait(pthread_cond_t * &cond,pthread_mutex_t * &mutex)   
        * cond:条件变量；
        * mutex:互斥锁；
        * 成功返回0,在更新条件等待队列以前，mutex保持锁定状态，并在线程挂起进入等待前解锁,在条件满足从而离开pthread_cond_wait()之前，mutex将被重新加锁，以与进入pthread_cond_wait()前的加锁动作对应。   
    * 激活一个等待该条件的线程，存在多个等待线程时按入队顺序激活其中一个：int pthread_cond_signal(pthread_cond_t * &cond);
        * cond:条件变量；
        * 成功返回0。
    * 摧毁互斥锁：int pthread_mutex_destroy(pthread_mutex_t * &mutex);
        * mutex:互斥锁；
        * 成功返回0。
    * 摧毁条件变量：int pthread_cond_destroy(pthread_cond_t * &cond);
        * cond:条件变量；
        * 成功返回0。
## 在 Lab Week 13 的基础上用信号量解决线程池分配的互斥问题
### 实验原理
**线程池**由管理者线程、线程数组、任务队列组成，允许一个线程可以多次复用，且每次复用的线程内部的处理的任务可以不相同，将创建与销毁的开销省去而不必来一个请求开一个线程。

**管理者线程**负责创建并管理线程池，包括创建新线程、销毁线程池、添加任务。

**线程数组**实际上是在线程池初始化时开辟的一段存放一堆线程tid的空间，在逻辑上形成一个池，里面放置着提前创建的线程，这段空间中包含了正在工作的线程和等待工作的线程(空闲线程)。

**任务队列**的存在形式与线程数组相似，在线程池初始化时根据传入的任务队列长度开辟空间；当main函数添加新任务时，将任务放入任务队列并通知空闲线程来取。不同之处在于任务队列有明显的先后顺序，先进先出；而线程数组中的线程则是一个竞争关系去拿到互斥锁争取任务。
### 设计思路
实验中设计了两个结构体分别定义了任务和线程池，其中任务队列由循环队列构建
```
typedef struct Threadpool_task{
	void (*function)(void *);
	void *argument;
} threadpool_task;

typedef struct Threadpool {
	sem_t lock;     		  //确保线程池分配互斥的内存信号量，起到互斥锁的作用
	sem_t remain;    		  //通知执行任务的线程任务队列中剩余任务数的内存信号量
	pthread_t *threads;       //线程数组的起始指针
	threadpool_task *queue;   //任务队列数组的起始指针
	int thread_count;         //线程数量
	int task_count;			  //任务队列中任务数量
	int task_head;			  //任务循环队列里的第一个任务
	int task_tail;			  //任务循环队列下次添加任务的位置
	int queue_size;           //任务队列长度
	int shutdown;             //线程池当前状态是否关闭
	int started;              //正在运行的线程数
} threadpool;
```
设计以下三个函数为线程池的对外接口，主线程通过在main函数调用这三个函数成为管理者线程
```
threadpool* threadpool_create(int thread_count, int queue_size);//创建线程池
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);//添加需要执行的任务
int threadpool_destroy(threadpool* pool);//销毁存在的线程池并释放线程池所申请的内存资源
```
以下为线程池内部辅助函数
```
static void *threadpool_run(void *thread_pool); //线程池每个线程所执行的函数
```
编写测试程序，首先按输入的参数创建线程池，然后依次添加n个分别计算从1维到n维的向量(第n维的向量为[1,2,3,...,n])乘以它自身的转置的任务到任务队列中，等待所有计算任务完成且结果输出后摧毁线程池。

在整个程序中，通过结构体threadpool中的成员内存信号量lock解决线程池中各线程竞争任务的互斥问题，通过成员内存信号量remain确保线程在任务队列为空但线程池未关闭时阻塞等待，通过全局变量内存信号量lock确保线程池各线程对全局变量done访问互斥。
### 重要函数
* Pthread API：
    * 创建线程：int  pthread_create(pthread_t * tidp, const  pthread_attr_t * attr,( void * )( * start_rtn)( void * ), void  * arg);
        * tidp:指向线程标识符的指针;
        * attr:设置线程属性;
        * start_rtn:线程运行函数的起始地址;
        * arg:运行函数的参数;
        * 返回值：若线程创建成功，则返回0。若线程创建失败，则返回出错编号，并且*thread中的内容是未定义的。 
    * 阻塞等待线程退出，获取线程退出状态：int pthread_join(pthread_t thread, void ** retval);
        * thread:被等待的线程ID;
        * retval:存储线程结束状态;
        * 返回值：若成功返回0，若失败返回-1。
    * 退出线程：void  pthread_exit（void  * retval）;
        * retval:把一个空指针类型的值传给pthread_join的第二个参数;
        * 返回值：返回一个空指针类型的值。 
    * 创建内存信号量：int sem_init(sem_t *sem,int pshared,unsigned int value);
        * sem:指向初始化的信号对象；
        * pshared:控制信号量的类型，如果其值为0，就表示这个信号量是当前进程的局部信号量，否则信号量就可以在多个进程之间共享;
        * value：信号对象的初始值；
        * 返回值：成功返回0，失败返回-1。
    * 以原子操作的方式将信号量的值减1，若操作前信号量值小于等于0，就会阻塞这个线程，等待信号量增加到大于0时再减1并唤醒线程：int sem_wait(sem_t *sem); 
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
    * 以原子操作的方式将信号量的值加1：int sem_post(sem_t *sem);  
        * sem:信号量；
        * 返回值：成功返回0，失败返回-1。
    * 摧毁用完的信号量：int sem_destroy(sem_t *sem); 
        *  sem:信号量；
        * 返回值：成功返回0，失败返回-1。
* 自定义线程池对外接口及内部函数：
    * 创建线程池：threadpool* threadpool_create(int thread_count, int queue_size);
        * thread_count:线程池中用来执行任务的线程数；
        * queue_size：任务队列最大长度；
        * 返回值：成功返回线程池结构体地址，失败返回0。
    * 添加需要执行的任务：int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);
        * pool:线程池指针
        * fun:要执行的任务函数
        * arg:任务函数的参数
        * 返回值：成功返回0，失败返回-1。
    * 销毁存在的线程池并释放线程池所申请的内存资源：int threadpool_destroy(threadpool* pool);
        * pool:线程池指针
        * 返回值：成功返回0，失败返回-1。
    * 线程池每个线程所执行的函数：static void *threadpool_run(void *thread_pool); 
        * pool:线程池指针
        * 返回值：成功返回0，失败返回-1。
### 具体实现
注：由于matrix只能提交一个文件所以`threadpool.h`和`test.c`合并提交了。
线程池的结构体定义及功能函数写在`threadpool.h`文件中
```
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <stdio.h>

typedef struct Threadpool_task{
	void (*function)(void *);
	void *argument;
} threadpool_task;

typedef struct Threadpool {
	sem_t lock;     		  //确保线程池分配互斥的内存信号量，起到互斥锁的作用
	sem_t remain;    		  //通知执行任务的线程任务队列中剩余任务数的内存信号量
	pthread_t *threads;       //线程数组的起始指针
	threadpool_task *queue;   //任务队列数组的起始指针
	int thread_count;         //线程数量
	int task_count;			  //任务队列中任务数量
	int task_head;			  //任务循环队列里的第一个任务
	int task_tail;			  //任务循环队列下次添加任务的位置
	int queue_size;           //任务队列长度
	int shutdown;             //线程池当前状态是否关闭
	int started;              //正在运行的线程数
} threadpool;

static void *threadpool_run(void *thread_pool); //线程池每个线程所执行的函数
threadpool* threadpool_create(int thread_count, int queue_size);//创建线程池
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg);//添加需要执行的任务
int threadpool_destroy(threadpool* pool);//销毁存在的线程池并释放线程池所申请的内存资源

static void *threadpool_run(void *thread_pool){
	printf("A thread in pool starts.\n");
	threadpool* pool = (threadpool*)thread_pool;
	while(!pool->shutdown){
		sem_wait(&(pool->lock));//取得互斥锁
		while((!pool->shutdown)&&(pool->task_count==0)) {//若线程池没有关闭且任务队列为空则阻塞
            sem_post(&pool->lock);
			sem_wait(&pool->remain);
			sem_wait(&pool->lock);
        }

		if(pool->shutdown){//如果线程池关闭就退出
			break;
		}

		//取出任务队列里最先进入的任务
		threadpool_task task;
		task.function=pool->queue[pool->task_head].function;
		task.argument=pool->queue[pool->task_head].argument;
		pool->task_head=(pool->task_head+1)%pool->queue_size;
		pool->task_count--;

		sem_post(&(pool->lock));//释放互斥锁

		(*(task.function))(task.argument);//执行任务
	}
	pool->started--;
	printf("A thread in pool exits.\n");
	sem_post(&(pool->lock));
    pthread_exit(NULL);
}
threadpool* threadpool_create(int thread_count, int queue_size){
	if(thread_count <= 0|| queue_size <= 0) {
        return 0;
    }
	threadpool* pool=(threadpool*)malloc(sizeof(threadpool));
	if(pool==0){
		return 0;
	}
	sem_init(&pool->lock, 0, 1);//初始化互斥信号量
	sem_init(&pool->remain, 0, 0);//初始化队列剩余任务数信号量
	pool->threads = (pthread_t*)malloc(sizeof(pthread_t)*thread_count);//申请线程数组所需的内存
	pool->queue = (threadpool_task*)malloc(sizeof(threadpool_task)*queue_size);//申请任务队列所需的内存
	if(pool->threads==0||pool->queue==0){
		return 0;
	}
	//初始化其他参数
	pool->thread_count=0;
	pool->task_head=0;
	pool->task_tail=0;
	pool->task_count=0;
    pool->queue_size=queue_size;
    pool->shutdown=0;
	pool->started = 0;
	int i;
	for(i=0;i<thread_count;i++) {//创建thread_count个线程并开始运行
        if(pthread_create(&(pool->threads[i]),NULL,threadpool_run,(void*)pool)!=0){
            threadpool_destroy(pool);
            return 0;
        }
        pool->thread_count++;
        pool->started++;
    }

    return pool;
}
int threadpool_add(threadpool* pool, void (*fun)(void *),void *arg){
	if(sem_wait(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool->task_count==pool->queue_size||pool->shutdown==1){//判断任务队列满没满或线程池是否关闭
		sem_post(&pool->lock);
		return -1;
	}
	//向任务循环队列里添加一个新任务
	pool->queue[pool->task_tail].function=fun;
	pool->queue[pool->task_tail].argument=arg;
	pool->task_tail=(pool->task_tail+1)%pool->queue_size;
	pool->task_count++;
	if(sem_post(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	sem_post(&(pool->remain));//发出有任务添加进来的信号，若存在因为任务队列空阻塞的线程就唤醒一个
	return 0;
}
int threadpool_destroy(threadpool* pool){
	if(sem_wait(&(pool->lock))!=0){//取得互斥锁所有权
        return -1;
    }
	if(pool==0){//判断这个线程池是否已经摧毁过了
		return 0;
	}
	if(pool->shutdown){//判断线程池是否关闭
		return -1;
	}
	pool->shutdown=1;//关闭线程池
	int i;
	for(i=0;i<pool->started;i++){//唤醒所有因为任务队列为空而阻塞的线程
		sem_post(&pool->remain);
	}
	if(sem_post(&pool->lock)!=0) {//释放互斥锁
        return -1;
    }
	for(i=0; i<pool->thread_count;i++) {//等待所有线程结束
		pthread_join(pool->threads[i], NULL);
	}

	while(pool->started)sleep(5);
	free(pool->threads);//释放线程数组
	free(pool->queue);//释放任务队列
	sem_destroy(&(pool->lock));//摧毁互斥信号量
	sem_destroy(&(pool->remain));//摧毁剩余任务信号量
    free(pool);//释放线程池
	pool=0;
	return 0;
}
```
测试程序及其对线程池接口的调用写在`test.c`文件中
```
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <semaphore.h>
#include "threadpool.h"

int done = 0;
sem_t lock;

void run(void *arg){
    int* num=(int*)arg;
    int n=*num;
    int i;
    int result=0;
    for(i=1;i<=n;i++){
        result+=i*i;
    }
    sem_wait(&lock);
    done++;
    printf("n=%d,result=%d,%d tasks have done\n",n,result,done);
    sem_post(&lock);
}

int main()
{
    printf("请输入线程数量：");
    int thread_count;
    scanf("%d",&thread_count);
    printf("请输入任务队列里最多任务数：");
    int queue_size;
    scanf("%d",&queue_size);
    printf("请输入向量的最大维数：");
    int n;
    scanf("%d",&n);
    printf("使用线程数为%d任务队列最大长度为%d的线程池计算从1维到%d维的向量乘以它的转置\n",thread_count,queue_size,n);
    printf("注：第n维的向量为[1,2,3,...,n]\n");

    sem_init(&lock, 0, 1);//初始化实现线程互斥的内存信号量
    threadpool* pool=threadpool_create(thread_count,queue_size);//创建线程池
    if(pool==0){
        printf("线程池创建失败\n");
        return 0;
    }
    int task[n+1];//防止线程获得向量阶数的时候出现冲突
    int i;
    for(i=1;i<=n;i++){
        task[i]=i;
    }
    i=1;
    while(i<=n){//将所有任务添加到任务队列里
        while(pool->shutdown==0&&threadpool_add(pool,&run,&task[i])!=0){//如果添加失败就等1秒，直到成功添加第i个任务
            sleep(1);
        }
        i++;
    }
    while(done<n){//等待所有任务完成
        sleep(5);
    }
    sleep(1);
    printf("All tasks have done!\n");
    sem_destroy(&lock);//摧毁内存信号量
    if(threadpool_destroy(pool)!=0){//销毁线程池
        printf("线程池摧毁失败\n");
    }
    return 0;
}
```
### 测试用例
编译运行

![](1.png)

**样例一**：使用线程数为3任务队列最大长度为5的线程池计算从1维到10维的向量乘以它的转置

![](2.png)

**样例二**：使用线程数为5任务队列最大长度为8的线程池计算从1维到15维的向量乘以它的转置

![](3.png)

**样例三**：使用线程数为6任务队列最大长度为9的线程池计算从1维到20维的向量乘以它的转置

![](4.png)