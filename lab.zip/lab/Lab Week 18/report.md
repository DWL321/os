# Lab Week 18 实验报告
## 实验内容:硬盘调度。
编写 C 程序模拟实现课件 Lecture25 中的硬盘柱面访问调度算法包括 FCFS、SSTF、SCAN、C-SCAN、LOOK、C-LOOK,并设计输入用例验证结果。
## 实验原理
+ 硬盘柱面访问调度算法
    + 一次磁盘读写操作的时间由寻找(寻道)时间、延迟时间和传输时间决定
        +  寻找时间Ts:活动头磁盘在读写信息前，将磁头移动到指定磁道所需要的时间。这个时间除跨越n条磁道的时间外，还包括启动磁臂的时间s，即:Ts = m * n + s。式中，m是与磁盘驱动器速度有关的常数，约为0.2ms，磁臂的启动时间约为2ms。
        + 延迟时间Tr:磁头定位到某一磁道的扇区(块号)所需要的时间，设磁盘的旋转速度为r，则:Tr = 1 / (2 * r)。对于硬盘，典型的旋转速度为5400r/m，相当于一周11.1ms，则Tr为5.55ms;对于软盘，其旋转速度在300~600r/m之间，则Tr为50~100ms。
        + 传输时间Tt:从磁盘读出或向磁盘写入数据所经历的时间，这个时间取决于每次所读/写的字节数b和磁盘的旋转速度:Tt = b / (r * N)。式中，r为磁盘每秒钟的转数;N为一个磁道上的字节数。
    + 在磁盘存取时间的计算中，寻道时间与磁盘调度算法相关，而延迟时间和传输时间都与磁盘旋转速度相关，且为线性相关，所以在硬件上，转速是磁盘性能的一个非常重要的参数。磁盘调度的目标是使磁盘的平均寻道时间最少。 
    + 总平均存取时间Ta可以表示为:Ta = Ts + Tr + Tt。
+ FCFS(先来先服务)
    + 算法原理：按访问请求到达的先后次序服务，简单，公平，每个进程请求都能依次得到处理，不会出现某一进程的请求长期得不到满足，但是效率不高，相邻两次请求可能会造成最内到最外的柱面寻道，使磁头反复移动，增加了服务时间，对机械也不利。
    + 设计思路：按磁头访问序列依次访问各各磁道即可。
+ SSTF(最短寻道时间优先)
    + 算法原理：优先选择距当前磁头最近的访问请求进行服务，主要考虑寻道优先，以使每次的寻找时间最短。但是总是选择最小寻找时间并不能保证平均寻找时间最小，而且这种算法会产生“饥饿”现象。 
    + 设计思路：将磁头访问序列按磁道号从小到大排序，访问过的磁道号置为-1，每次移动磁头前比较序列中当前磁道号左右最近的非负磁道号与当前磁道的距离，哪个距离更近就移动到哪个磁道。
+ SCAN(扫描算法)
    + 算法原理：在磁头当前移动方向上选择与当前磁头所在磁道距离最近的请求作为下一次服务的对象。当设备无访问请求时，磁头不动；当有访问请求时，磁头按一个方向移动，在移动过程中对遇到的访问请求进行服务，然后判断该方向上是否还有访问请求，如果有则继续扫描；否则改变移动方向，并为经过的访问请求服务，如此反复。由于磁头移动规律与电梯运行相似，故又称为电梯调度算法。SCAN算法对最近扫描过的区域不公平，存在一个请求刚好被错过而需要等待较长时间的问题，因此，它在访问局部性方面不如FCFS算法和SSTF算法好。 
    + 设计思路：将磁头访问序列按磁道号从小到大排序，假设在起始位置时磁头朝0方向移动，然后磁头沿这个方向一直移动到磁盘上的最小磁道号0，访问过的磁道号置为-1，然后沿另一个方向访问序列中剩余的非负磁道号。
+ C-SCAN(循环扫描算法)
    + 算法原理：循环扫描调度算法是在扫描算法的基础上改进的，为了减少延迟，规定磁头单向移动，例如，只是自里向外移动，从当前位置开始沿磁头的移动方向去选择离当前磁头最近的那个柱面访问，如果沿磁头的方向无请求时，磁头立即返回到最里面的欲访问的柱面，再亦即将最小柱面号紧接着最大柱面号构成循环。优点是兼顾较好的寻道性能和防止饥饿现象，同时减少一个请求可能等待的最长时间。缺点是可能出现磁头停留在某处不动的情况（磁臂黏着）。
    + 设计思路：将磁头访问序列按磁道号从小到大排序，假设在起始位置时磁头朝磁盘上的最大磁道号199方向移动 ，然后磁头沿这个方向一直移动到磁盘上的最大磁道号199，访问过的磁道号置为-1，然后磁头移动到0再向199方向移动访问序列中剩余的非负磁道号。
+ LOOK(SCAN改进版)
    + 算法原理：类似SCAN调度算法, 不同之处在于, 在该调度算法中, 当在该方向上不再有请求时, 磁盘的臂停止向内(或向外)移动。该算法试图克服SCAN算法的开销, 该开销迫使磁盘臂沿一个方向移动到最后, 而不管是否知道该方向上是否存在任何请求。
    + 设计思路：将磁头访问序列按磁道号从小到达排序，假设在起始位置时磁头朝0方向移动 ，然后磁头沿这个方向一直移动到访问序列中的最小磁道号，访问过的磁道号置为-1，然后沿另一个方向访问序列中剩余的非负磁道号。
+ C-LOOK(C-SCAN改进版)
    + 算法原理：类似于C-SCAN算法。在这种算法中, 磁盘的臂向外移动以服务请求, 直到到达最高请求柱面为止, 然后在不满足任何请求的情况下跳到最低请求柱面, 然后再次开始向外移动以服务其余请求。它与C-SCAN算法的不同之处在于, C-SCAN强制磁盘臂移动到最后一个柱面, 而不管是否知道对该柱面是否有任何请求。
    + 设计思路：将磁头访问序列按磁道号从小到大排序，假设在起始位置时磁头朝磁盘上的最大磁道号199方向移动 ，然后磁头沿这个方向一直移动到磁盘上的访问序列中的最大磁道号，访问过的磁道号置为-1，然后磁头移动到访问序列中的最小非负磁道号再向199方向移动访问序列中剩余的非负磁道号。
## 程序实现
+ 总体设计思路：每个算法具体的设计思路已经在实验原理中说明。首先先输入磁盘访问序列长度、磁盘访问序列、磁头起始位置，然后依次使用六种算法进行调度，输出每种算法的磁头服务序列和磁头移动平均距离。
+ 代码具体实现
    ```
    #include <stdio.h>
    #include <stdlib.h>
    #include <time.h>

    int* numbers;//磁盘访问序列
    int start;//磁头起始位置
    int length;//磁盘访问序列长度

    void init();//初始化参数
    //分别执行六种硬盘柱面访问调度算法，输出每种算法的磁头服务序列并返回磁头移动平均距离
    double FCFS();
    double SSTF();
    double SCAN();
    double C_SCAN(); 
    double LOOK();
    double C_LOOK();

    int main()
    {
        init();
        printf("FCFS 磁头移动平均距离:%lf\n",FCFS());
        printf("SSTF 磁头移动平均距离:%lf\n",SSTF());
        printf("SCAN 磁头移动平均距离:%lf\n",SCAN());
        printf("C_SCAN 磁头移动平均距离:%lf\n",C_SCAN());
        printf("LOOK 磁头移动平均距离:%lf\n",LOOK());
        printf("C_LOOK 磁头移动平均距离:%lf\n",C_LOOK());
        free(numbers);
        return 0;
    }
    void init(){
        printf("输入磁盘访问序列长度:");
        scanf("%d",&length);
        numbers=(int*)malloc(sizeof(int)*length);
        printf("输入磁盘访问序列(0～199):");
        int i;
        for(i=0;i<length;i++){
            scanf("%d",&numbers[i]);
        }
        printf("输入磁头起始位置:");
        scanf("%d",&start);
    }
    double FCFS(){
        printf("----------------------------------------------------\n");
        printf("FCFS 磁头服务序列：\n");
        //先来先服务
        int i;
        int sum=0;
        int pre=start;
        for(i=0;i<length;i++){
            if(numbers[i]>pre)sum+=numbers[i]-pre;
            else sum+=pre-numbers[i];
            pre=numbers[i];
            printf("%d ",numbers[i]);
        }
        printf("\n");
        return sum*1.0/length;
    }
    double SSTF(){
        printf("----------------------------------------------------\n");
        printf("SSTF 磁头服务序列：\n");
        int num1[length];
        int num2[length];
        int i;
        for(i=0;i<length;i++){
            num1[i]=numbers[i];
        }
        //将磁头访问序列按磁道号从小到大排序
        for(i=1;i<length-1;i++){
            int j;
            for(j=0;j<length-i;j++){
                if(num1[j]>num1[j+1]){
                    int t=num1[j];
                    num1[j]=num1[j+1];
                    num1[j+1]=t;
                }
            }
        }
        for(i=0;i<length;i++){
            num2[i]=num1[i];
        }
        //最短寻道时间优先
        int sum=0;
        int pre=start;
        for(i=0;i<length;i++){
            if(num1[i]>=start)break;
        }
        if(i==0||(i<length&&num1[i]-start<start-num1[i-1])){
            sum+=num2[i]-start;
            pre=i;
            printf("%d ",num1[i]);
            num1[i]=-1;
        }
        else{
            i--;
            sum+=start-num2[i];
            pre=i;
            printf("%d ",num1[i]);
            num1[i]=-1;
        }
        int rest=length-1;
        while(rest){
            for(i=pre-1;i>=0;i--){
                if(num1[i]!=-1)break;
            }
            int j;
            for(j=pre+1;j<length;j++){
                if(num1[j]!=-1)break;
            }
            if(i>=0&&(j==length||num2[j]-num2[pre]>num2[pre]-num2[i])){
                printf("%d ",num2[i]);
                num1[i]=-1;
                sum+=num2[pre]-num2[i];
                pre=i;
            }
            else{
                printf("%d ",num2[j]);
                num1[j]=-1;
                sum+=num2[j]-num2[pre];
                pre=j;
            }
            rest--;
        }
        printf("\n");
        return sum*1.0/length;
    }
    double SCAN(){
        printf("----------------------------------------------------\n");
        printf("SCAN(假设在起始位置时磁头朝0方向移动) 磁头服务序列：\n");
        int num[length];
        int i;
        for(i=0;i<length;i++){
            num[i]=numbers[i];
        }
        //将磁头访问序列按磁道号从小到大排序
        for(i=1;i<length-1;i++){
            int j;
            for(j=0;j<length-i;j++){
                if(num[j]>num[j+1]){
                    int t=num[j];
                    num[j]=num[j+1];
                    num[j+1]=t;
                }
            }
        }
        //扫描算法
        int sum=start+num[length-1];
        int pre=start;
        for(i=0;i<length;i++){
            if(num[i]>=start)break;
        }
        if(i==0){
            printf("%d ",num[i]);
            num[i]=-1;
        }
        else{
            i--;
            printf("%d ",num[i]);
            num[i]=-1;
        }
        pre=i;
        int rest=length-1;
        while(i){
            i--;
            printf("%d ",num[i]);
            num[i]=-1;
            rest--;
        }
        i=pre;
        while(rest){
            i++;
            printf("%d ",num[i]);
            num[i]=-1;
            rest--;
        }
        printf("\n");
        return sum*1.0/length;
    }
    double C_SCAN(){
        printf("----------------------------------------------------\n");
        printf("C-SCAN(假设在起始位置时磁头朝199方向移动) 磁头服务序列：\n");
        int num[length];
        int i;
        for(i=0;i<length;i++){
            num[i]=numbers[i];
        }
        //将磁头访问序列按磁道号从小到大排序
        for(i=1;i<length-1;i++){
            int j;
            for(j=0;j<length-i;j++){
                if(num[j]>num[j+1]){
                    int t=num[j];
                    num[j]=num[j+1];
                    num[j+1]=t;
                }
            }
        }
        //扫描算法
        int sum=0;
        for(i=0;i<length;i++){
            if(num[i]>=start)break;
        }
        if(i==0)sum=num[length-1]-start;
        else sum=199-start+199+num[i-1];
        if(i<length){
            for(;i<length;i++){
                printf("%d ",num[i]);
                num[i]=-1;
            }  
        }
        for(i=0;i<length&&num[i]!=-1;i++){
            printf("%d ",num[i]);
            num[i]=-1;
        }
        printf("\n");
        return sum*1.0/length;
    }
    double LOOK(){
        printf("----------------------------------------------------\n");
        printf("LOOK(假设在起始位置时磁头朝0方向移动) 磁头服务序列：\n");
        int num[length];
        int i;
        for(i=0;i<length;i++){
            num[i]=numbers[i];
        }
        //将磁头访问序列按磁道号从小到大排序
        for(i=1;i<length-1;i++){
            int j;
            for(j=0;j<length-i;j++){
                if(num[j]>num[j+1]){
                    int t=num[j];
                    num[j]=num[j+1];
                    num[j+1]=t;
                }
            }
        }
        //扫描算法
        int sum;
        if(start>num[0])sum=start-num[0]+num[length-1]-num[0];
        else sum=num[length-1]-start;
        int pre=start;
        for(i=0;i<length;i++){
            if(num[i]>=start)break;
        }
        if(i>0){
            i--;
            printf("%d ",num[i]);
            num[i]=-1;
        }
        pre=i;
        int rest=length-1;
        while(i){
            i--;
            printf("%d ",num[i]);
            num[i]=-1;
            rest--;
        }
        i=pre;
        while(rest){
            i++;
            printf("%d ",num[i]);
            num[i]=-1;
            rest--;
        }
        printf("\n");
        return sum*1.0/length;
    }
    double C_LOOK(){
        printf("----------------------------------------------------\n");
        printf("C-LOOK(假设在起始位置时磁头朝199方向移动) 磁头服务序列：\n");
        int num[length];
        int i;
        for(i=0;i<length;i++){
            num[i]=numbers[i];
        }
        //将磁头访问序列按磁道号从小到大排序
        for(i=1;i<length-1;i++){
            int j;
            for(j=0;j<length-i;j++){
                if(num[j]>num[j+1]){
                    int t=num[j];
                    num[j]=num[j+1];
                    num[j+1]=t;
                }
            }
        }
        int max=num[length-1];
        if(max<start)max=start;
        int min=num[0];
        int sum;
        //扫描算法
        for(i=0;i<length;i++){
            if(num[i]>=start)break;
        }
        if(i<length){
            for(;i<length;i++){
                printf("%d ",num[i]);
                num[i]=-1;
            }  
        }
        for(i=0;i<length&&num[i]!=-1;i++){
            printf("%d ",num[i]);
            if((i<length-1&&num[i+1]==-1)||i==length-1)sum=max-start+199-(199-max+min)+num[i]-min;
            num[i]=-1;
        }
        printf("\n");
        return sum*1.0/length;
    }
    ```
## 运行结果分析
![](1.png)

+ 如图测试样例中：
    + 磁盘访问序列：98，183，37，122，14，124，65，67；
    + 磁头起始位置：53；
    + 各算法运行结果如下：
        + FCFS：
            + 磁头服务序列：98，183，37，122，14，124，65，67 
            + 磁头移动平均距离：(45+85+146+85+108+110+59+2)/8=80
        + SSTF：
            + 磁头服务序列：65，67，37，14，98，122，124，183 
            + 磁头移动平均距离：(12+2+30+23+84+24+2+59)/8=29.5
        + SCAN：
            + 磁头服务序列：37，14，65，67，98，122，124，183 
            + 磁头移动平均距离：(16+23+14+65+2+31+24+2+59)/8=29.5
        + C-SCAN：
            + 磁头服务序列：65，67，98，122，124，183，14，37 
            + 磁头移动平均距离：(12+2+31+24+2+59+16+199+14+23)/8=47.75
        + LOOK：
            + 磁头服务序列：37，14，65，67，98，122，124，183 
            + 磁头移动平均距离：(16+23+51+2+31+24+2+59)/8=26
        + C-LOOK：
            + 磁头服务序列：65，67，98，122，124，183，14，37
            + 磁头移动平均距离：(12+2+31+24+2+59+169+23)/8=40.25