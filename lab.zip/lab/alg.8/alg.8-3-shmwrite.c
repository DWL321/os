#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/shm.h>

#include "alg.8-0-shmdata.h"
 
int main(int argc, char *argv[])
{ 
    void *shmptr = NULL;
    struct shared_struct *shared = NULL;
    int shmid;
    key_t key;

    char buffer[BUFSIZ + 1]; /* 8192bytes, saved from stdin */
    
    sscanf(argv[1], "%x", &key);

    printf("shmwrite: IPC key = %x\n", key);

    shmid = shmget((key_t)key, TEXT_NUM*sizeof(struct shared_struct), 0666|PERM);
    if (shmid == -1) {
        ERR_EXIT("shmwite: shmget()");
    }

    shmptr = shmat(shmid, 0, 0);
    if(shmptr == (void *)-1) {
        ERR_EXIT("shmwrite: shmat()");
    }
    printf("shmwrite: shmid = %d\n", shmid);
    printf("shmwrite: shared memory attached at %p\n", shmptr);
    printf("shmwrite precess ready ...\n");
    
    shared = (struct shared_struct *)shmptr;
    
    while (1) {
        while ((shared->tail+1)%MAX_STUDENT_NUM == shared->head) {
            shared->written=1;
            sleep(1); /* 队列存满了, waiting ... */ 
        }
 
        printf("输入一个学生的id: ");
        scanf("%s",buffer);
 
        if(strncmp(buffer, "0", 1) == 0) {
            shared->written=1;
            sleep(1);//本次学生输入完成
        }
        else if(strncmp(buffer, "-1", 2) == 0) {
            strncpy(shared->students[shared->tail].id, buffer, ID_LEN+1);
            shared->tail = (shared->tail+1)%MAX_STUDENT_NUM;
            shared->written=1;
            break;//所有学生输入完成，退出程序
        }
        else{
            strncpy(shared->students[shared->tail].id, buffer, ID_LEN+1);
            printf("输入一个学生的姓名: ");
            scanf("%s",buffer);
            strncpy(shared->students[shared->tail].name, buffer, MAX_NAME_LEN+1);
            shared->tail = (shared->tail+1)%MAX_STUDENT_NUM;  
        }
    }
       /* detach the shared memory */
    if(shmdt(shmptr) == -1) {
        ERR_EXIT("shmwrite: shmdt()");
    }

//    sleep(1);
    exit(EXIT_SUCCESS);
}
